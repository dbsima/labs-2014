/**
 * SO, 2011
 * Lab #1, Introduction
 *
 * Task #3, Linux 
 * 
 * Multiple source files compiling
 * add.h - addition header file 
 */

#ifndef _ADD_H
#define _ADD_H

int add(int a, int b);

#endif
