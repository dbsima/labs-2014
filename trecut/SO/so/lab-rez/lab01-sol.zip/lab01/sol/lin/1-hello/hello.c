/**
 * SO, 2011
 * Lab #1, Introducere
 *
 * Task #1, Linux
 *
 * Welcome to SO, simple greeting program.
 */

#include <stdio.h>

int main(void)
{
	printf("SO, ... Hello World!\n");
	
	return 0;
}


