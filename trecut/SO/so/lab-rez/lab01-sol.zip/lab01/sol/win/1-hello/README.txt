#README, 01-hello

Exercitiu rezolvat. Comenzile trebuie rulate
in Visual Studio Command prompt.

In masina virtuala pe Desktop exista un shortcut pentru
Visual Studio Command Prompt (vezi si 01-hello.bmp)

