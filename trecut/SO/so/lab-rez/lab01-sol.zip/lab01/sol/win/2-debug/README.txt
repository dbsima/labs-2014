#README, 02-debug

Trebuie definit simbolul DEBUG__, folosind optiunea
/D a compilatorului cl.

Astfel daca adaugam variabilei CFLAGS
CFLAGS = /nologo /W3 /DDEBUG__ totul este rezolvat.

Specificarea unui nume de  fisier makefile se face cu /F
