/**
  * SO, 2011
  * Lab #3
  *
  * Task #4, lin
  *
  * Common defines
  */
#ifndef LIN_LAB03_COMMON_H_
#define LIN_LAB03_COMMON_H_	1

#define PIPE_NAME	"myfifo"
#define BUFSIZE		256

#endif

