/**
  * SO, 2011
  * Lab #4
  *
  * Task #10, lin
  *
  * Dumb implementation of malloc that only allocates space
  */
#include <unistd.h>
#include <sys/types.h>

#include "my_malloc.h"


void * my_malloc(size_t size)
{
	void *current = NULL;
	void *rc = NULL;

	/* TODO - find the current location of the program program break */
	current = sbrk(0);
	if (current == NULL)
		return NULL;

	/* TODO - user sbrk to alloc at least size bytes */
	rc = sbrk(size);
	if (rc == (void *)-1){
		/* no more memory */
		return NULL;
	}

	/* return the start of the new allocated area */
	return current;
}
