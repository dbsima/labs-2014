/**
  * SO, 2011
  * Lab #4
  *
  * Task #6, lin
  *
  * Use of mcheck
  */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char first_name[] = "  Harry";
char last_name[]  = "    Potter";

static char *trim(char *s)
{
	/* we correct trim by using an auxiliary variable aux to save p
	   free is issued on aux to free the exact allocated memory */
	char *p = malloc(strlen(s)+1);
	strcpy(p, s);

	char *aux = p;
	
	while( *p == ' ' ) p++;

	strcpy(s, p);
	free(aux);
	
	return s;
}

int main(void)
{
	printf("%s %s is learning SO!\n",
			trim(first_name), trim(last_name));
	return 0;
}
