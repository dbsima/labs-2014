/**
  * SO, 2011
  * Lab #4
  *
  * Task #10, lin
  *
  */
#ifndef MY_MALLOC__
#define MY_MALLOC__

#include <sys/types.h>

void * my_malloc(size_t size);

#endif
