cp ../AndreiGliga_SasuRobert_332CA_Tema5_SO/aws .
ls -l
./run_all.sh
