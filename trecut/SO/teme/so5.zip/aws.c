/* SIMA Dragos-Bogdan, 332CA */

#include <stdio.h>
#include <stdlib.h>
#include <libaio.h>
#include <string.h>
#include <assert.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <linux/types.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/epoll.h>
#include <sys/socket.h>
#include <sys/eventfd.h>
#include <sys/syscall.h>

#include <sys/sendfile.h>

#include "sock_util.h"
#include "debug.h"
#include "w_epoll.h"
#include "aws.h"
#include "util.h"
#include "http_parser.h"

#ifndef BUFSIZ
	#define BUFSIZ		4096
#endif

#define PACKSIZE 1024

#define STATIC  0
#define DYNAMIC 1

/*file descriptors*/
int fd[256];

/*event file descriptors*/
int efd[256];

/*file type (static/dynamic)*/
int file_type[256];

/* server socket file descriptor */
static int listenfd;

/* epoll file descriptor */
static int epollfd;

/*
 * write data asynchronously (using io_setup(2), io_sumbit(2),
 * 	io_getevents(2), io_destroy(2))
 */

int do_io_async(int sock_fd)
{
	io_context_t ctx = 0;
   
    struct iocb cb;
	struct iocb *pcb[1];
   
    int filepos = 0, buflen = PACKSIZE;
    char* buffer = (char*)calloc(PACKSIZE,sizeof(char));

	/*file size*/
    int file_size = lseek(fd[sock_fd], 0, SEEK_END);
	lseek(fd[sock_fd], 0, SEEK_SET);
	
	memset(&cb,0,sizeof(struct iocb));

    int i = 0;
    int tmp = file_size / PACKSIZE;

    if (file_size % PACKSIZE != 0) tmp+=1;

	/*send file in packages*/
    for (i = 0;i < tmp;i++)
	{
        filepos = i * PACKSIZE;
        pcb[0] = &cb;

        memset(&cb,0,sizeof(struct iocb));
        buffer = (char*)calloc(PACKSIZE,sizeof(char));

        if (filepos + PACKSIZE > file_size)
            buflen = file_size - filepos;

		/* read from file*/
		io_prep_pread(&cb, fd[sock_fd], buffer, buflen, filepos);

		/* set eventfd */
        io_set_eventfd(&cb, efd[sock_fd]);
     
        int tmp_setup = (file_size / PACKSIZE) > 0 ? file_size / PACKSIZE : 1;
        
        /* setup context */
        io_setup(tmp_setup, &ctx);

		/* submit package*/
        io_submit(ctx, tmp_setup, pcb);

        send(sock_fd, buffer, buflen, 0);
	}

	/* destroy context */
	io_destroy(ctx);
	return 0;
}


enum connection_state {
	STATE_DATA_RECEIVED,
	STATE_DATA_SENT,
	STATE_CONNECTION_CLOSED
};

/* structure acting as a connection handler */
struct connection {
	int sockfd;
	/* buffers used for receiving messages and then echoing them back */
	char recv_buffer[BUFSIZ];
	size_t recv_len;
	char send_buffer[BUFSIZ];
	size_t send_len;
	enum connection_state state;
};

/*
 * Initialize connection structure on given socket.
 */
static struct connection *connection_create(int sockfd)
{
	struct connection *conn = malloc(sizeof(*conn));
	DIE(conn == NULL, "malloc");

	conn->sockfd = sockfd;
	memset(conn->recv_buffer, 0, BUFSIZ);
	memset(conn->send_buffer, 0, BUFSIZ);

	return conn;
}

/*
 * Copy receive buffer to send buffer (echo).
 */

static void connection_copy_buffers(struct connection *conn)
{
	conn->send_len = conn->recv_len;
	memcpy(conn->send_buffer, conn->recv_buffer, conn->send_len);
}

/*
 * Remove connection handler.
 */

static void connection_remove(struct connection *conn)
{
	close(conn->sockfd);
	conn->state = STATE_CONNECTION_CLOSED;
	free(conn);
}

/*
 * Handle a new connection request on the server socket.
 */

static void handle_new_connection(void)
{
	static int sockfd;
	socklen_t addrlen = sizeof(struct sockaddr_in);
	struct sockaddr_in addr;
	struct connection *conn;
	int rc;

	/* accept new connection */
	sockfd = accept(listenfd, (SSA *) &addr, &addrlen);
	DIE(sockfd < 0, "accept");

	/* instantiate new connection handler */
	conn = connection_create(sockfd);

	/* add socket to epoll */
	rc = w_epoll_add_ptr_in(epollfd, sockfd, conn);
	DIE(rc < 0, "w_epoll_add_in");
}

/*
 * Receive message on socket.
 * Store message in recv_buffer in struct connection.
 */

static enum connection_state receive_message(struct connection *conn)
{
	ssize_t bytes_recv;
	int rc;
	char abuffer[64];

	rc = get_peer_address(conn->sockfd, abuffer, 64);
	if (rc < 0) {
		ERR("get_peer_address");
		goto remove_connection;
	}

	bytes_recv = recv(conn->sockfd, conn->recv_buffer, BUFSIZ, 0);
	if (bytes_recv < 0) {		/* error in communication */
		dlog(LOG_ERR, "Error in communication from: %s\n", abuffer);
		goto remove_connection;
	}
	if (bytes_recv == 0) {		/* connection closed */
		dlog(LOG_INFO, "Connection closed from: %s\n", abuffer);
		goto remove_connection;
	}
	
	/* init the http parser*/
	http_parser *parser = malloc(sizeof(http_parser));
	http_parser_init(parser, HTTP_REQUEST);
	
	parser->data = conn->recv_buffer;
	struct http_parser_url *url = malloc(sizeof(struct http_parser_url));
	
	/*the the url */
	http_parser_parse_url(conn->recv_buffer, strlen(conn->recv_buffer), 0, url);
	
	/* get the path of the requested file */
	char *path = strtok(conn->recv_buffer + url->field_data[0].len," \n");

	/*set flag if static or dynamic*/
	if (strstr(path, "/static/")) {
		file_type[conn->sockfd] = STATIC;
	} else if (strstr(path, "/dynamic/"))
		file_type[conn->sockfd] = DYNAMIC;
	
	/* try to open the requested file*/
	fd[conn->sockfd] = open(path + 1, O_RDONLY, 0666);

	conn->recv_len = bytes_recv;
	conn->state = STATE_DATA_RECEIVED;

	return STATE_DATA_RECEIVED;

remove_connection:
	rc = w_epoll_remove_ptr(epollfd, conn->sockfd, conn);
	DIE(rc < 0, "w_epoll_remove_ptr");

	/* remove current connection */
	connection_remove(conn);

	return STATE_CONNECTION_CLOSED;
}

/*
 * Send message on socket.
 * Store message in send_buffer in struct connection.
 */

static enum connection_state send_message(struct connection *conn)
{
	ssize_t bytes_sent;
	int rc;
	char abuffer[64];
	
	char header[BUFSIZ];

	/* HTTP header */
	if (fd[conn->sockfd] < 0)
		strcpy(header, "HTTP/1.0 404 Not Found\r\n\r\n");
	else
		strcpy(header, "HTTP/1.0 200 OK\r\n\r\n");


	rc = get_peer_address(conn->sockfd, abuffer, 64);
	if (rc < 0) {
		ERR("get_peer_address");
		goto remove_connection;
	}

	bytes_sent = send(conn->sockfd, header, strlen(header), 0);
	if (bytes_sent < 0) {		/* error in communication */
		dlog(LOG_ERR, "Error in communication to %s\n", abuffer);
		goto remove_connection;
	}
	if (bytes_sent == 0) {		/* connection closed */
		dlog(LOG_INFO, "Connection closed to %s\n", abuffer);
		goto remove_connection;
	}
	
	dlog(LOG_DEBUG, "Sending message to %s\n", abuffer);
	
	struct stat stat_buf;
	fstat(fd[conn->sockfd], &stat_buf);
	
	/*if the requested file is in the static folder, send it with sendfile */
	if (file_type[conn->sockfd] == STATIC)
		sendfile(conn->sockfd, fd[conn->sockfd], NULL, stat_buf.st_size);
	
	/* if the requested file is in the dynamic folder, process it and send it 
	** with non-blocking sockets */
	else if (file_type[conn->sockfd] == DYNAMIC)
	{
		efd[conn->sockfd] = eventfd(0, 0);

		fcntl(efd[conn->sockfd], F_SETFL, fcntl(efd[conn->sockfd], F_GETFL, 0) | O_NONBLOCK);

		do_io_async(conn->sockfd);

		/* close event file descriptor */
		close(efd[conn->sockfd]);
	}
	/* close file descriptor */
	close(fd[conn->sockfd]);

	/* all done - remove out notification */
	rc = w_epoll_update_ptr_in(epollfd, conn->sockfd, conn);
	DIE(rc < 0, "w_epoll_update_ptr_in");

	conn->state = STATE_DATA_SENT;

remove_connection:
	rc = w_epoll_remove_ptr(epollfd, conn->sockfd, conn);
	DIE(rc < 0, "w_epoll_remove_ptr");

	/* remove current connection */
	connection_remove(conn);

	return STATE_CONNECTION_CLOSED;
}

/*
 * Handle a client request on a client connection.
 */

static void handle_client_request(struct connection *conn)
{
	int rc;
	enum connection_state ret_state;

	ret_state = receive_message(conn);
	if (ret_state == STATE_CONNECTION_CLOSED)
		return;

	connection_copy_buffers(conn);

	/* add socket to epoll for out events */
	rc = w_epoll_update_ptr_inout(epollfd, conn->sockfd, conn);
	DIE(rc < 0, "w_epoll_add_ptr_inout");
}

int main(int argc, char **argv)
{
	/* init multiplexing */
	epollfd = w_epoll_create();
	DIE(epollfd < 0, "w_epoll_create");

	/* create server socket */
	listenfd = tcp_create_listener(AWS_LISTEN_PORT, 999);
	DIE(listenfd < 0, "tcp_create_listener");

	/*add listener to epoll*/
	int rc = w_epoll_add_fd_in(epollfd, listenfd);
	DIE(rc < 0, "w_epoll_add_fd_in");
	
	dlog(LOG_INFO, "Server waiting for connections on port %d\n", ECHO_LISTEN_PORT);

	/* server main loop */
	while (1) {
		struct epoll_event rev;

		/* wait for events */
		w_epoll_wait_infinite(epollfd, &rev);
		
		/*
		 * switch event types; consider
		 *   - new connection requests (on server socket)
		 *   - socket communication (on connection sockets)
		 */
		if (rev.data.fd == listenfd) {
			dlog(LOG_DEBUG, "New connection\n");
			if (rev.events & EPOLLIN)
				handle_new_connection();
		} 
		else {
			if (rev.events & EPOLLIN) {
				dlog(LOG_DEBUG, "New message\n");
				handle_client_request(rev.data.ptr);
			}
			 if (rev.events & EPOLLOUT) {
				dlog(LOG_DEBUG, "Ready to send message\n");
			 	send_message(rev.data.ptr);
			}
		}
	}

	return 0;
}
