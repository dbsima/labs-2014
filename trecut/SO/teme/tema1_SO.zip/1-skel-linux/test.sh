make clean
make
cp mini-shell ../tema1-checker-lin
cd ../tema1-checker-lin
./run_all.sh
ls -l mini-shell
