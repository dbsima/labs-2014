/**
 * Operating Sytems 2013 - Assignment 1
 * Sima Dragos-Bogdan, 332CA
 */

#include <assert.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/wait.h>

#include <fcntl.h>
#include <unistd.h>

#include "utils.h"

#define READ		0
#define WRITE		1

/**
 * Internal change-directory command.
 */
static bool shell_cd(word_t *dir)
{
	/* Execute cd */
	return chdir(dir->string);
}

/**
 * Internal exit/quit command.
 */
static int shell_exit()
{
	/* Execute exit/quit */
	exit(EXIT_SUCCESS);
	return EXIT_SUCCESS;
}

/**
 * Concatenate parts of the word to obtain the command
 */
static char *get_word(word_t *s)
{
	int string_length = 0;
	int substring_length = 0;

	char *string = NULL;
	char *substring = NULL;

	while (s != NULL) {
		substring = strdup(s->string);

		if (substring == NULL) {
			return NULL;
		}

		if (s->expand == true) {
			/* if to expand is true, perform environment variable expansion */
			char *aux = substring;
			substring = getenv(substring);

			/* prevents strlen from failing */
			if (substring == NULL) {
				substring = calloc(1, sizeof(char));
				if (substring == NULL) {
					free(aux);
					return NULL;
				}
			}

			free(aux);
		}

		substring_length = strlen(substring);

		string = realloc(string, string_length + substring_length + 1);
		if (string == NULL) {
			if (substring != NULL)
				free(substring);
			return NULL;
		}

		memset(string + string_length, 0, substring_length + 1);

		strcat(string, substring);
		string_length += substring_length;

		if (s->expand == false) {
			free(substring);
		}

		s = s->next_part;
	}

	return string;
}

/**
 * Concatenate command arguments in a NULL terminated list in order to pass
 * them directly to execv.
 */
static char **get_argv(simple_command_t *command, int *size)
{
	char **argv;
	word_t *param;

	int argc = 0;
	argv = calloc(argc + 1, sizeof(char *));
	assert(argv != NULL);

	argv[argc] = get_word(command->verb);
	assert(argv[argc] != NULL);

	argc++;

	param = command->params;
	while (param != NULL) {
		argv = realloc(argv, (argc + 1) * sizeof(char *));
		assert(argv != NULL);

		argv[argc] = get_word(param);
		assert(argv[argc] != NULL);

		param = param->next_word;
		argc++;
	}
	
	argv = realloc(argv, (argc + 1) * sizeof(char *));
	assert(argv != NULL);

	argv[argc] = NULL;
	*size = argc;

	return argv;
}

/*
 * Perform redirections
 */
void redirect(simple_command_t * s)
{
	int out_flag;
	if (s->io_flags & IO_OUT_APPEND) out_flag = O_APPEND;
		/* open output file for append */
	else out_flag = O_TRUNC;
		/* open output file for creation & overwrite */

	int err_flag;
	if (s->io_flags & IO_ERR_APPEND) err_flag = O_APPEND;
		/* open error file for append */
	else err_flag = O_TRUNC;
		/* open error file for creation & overwrite */

	if (s->in != NULL)
	{
		/* redirect input to s->in file */
		char* in_string  = get_word(s->in);
		int fd_in = open(in_string, O_RDONLY);
		DIE(fd_in < 0, "open");

		dup2(fd_in, STDIN_FILENO);
	}

	if (s->out != NULL && s->err != NULL)
	{
		char* out_string = get_word(s->out);
		char* err_string = get_word(s->err);

		if (strcmp(out_string, err_string) == 0)
		{
			int fd = open(out_string, O_CREAT | O_WRONLY | out_flag, 0644);
			DIE(fd < 0, "open");

			dup2(fd, STDOUT_FILENO);
			dup2(fd, STDERR_FILENO);
		}
		else
		{
			int fd_out = open(out_string, O_CREAT | O_WRONLY | out_flag, 0644);
			DIE(fd_out < 0, "open");

			dup2(fd_out, STDOUT_FILENO);

			int fd_err = open(err_string, O_CREAT | O_WRONLY | err_flag, 0644);
			DIE(fd_err < 0, "open");

			dup2(fd_err, STDERR_FILENO);
		}
	}
	else
	{
		if (s->out != NULL) 
		{
			/* redirect output to s->out file */
			char* out_string = get_word(s->out);
			int fd_out = open(out_string, O_CREAT | O_WRONLY | out_flag, 0644);
			DIE(fd_out < 0, "open");

			dup2(fd_out, STDOUT_FILENO);
		}
		if (s->err != NULL)
		{
			/* redirect errors to s->err file */
			char* err_string = get_word(s->err);
			int fd_err = open(err_string, O_CREAT | O_WRONLY | err_flag, 0644);
			DIE(fd_err < 0, "open");

			dup2(fd_err, STDERR_FILENO);
		}
	}
}

/**
 * Parse a simple command (internal, environment variable assignment,
 * external command).
 */
static int parse_simple(simple_command_t *s, int level, command_t *father)
{
	/* Sanity checks */
	if (strcmp(s->verb->string, "exit") == 0 || strcmp(s->verb->string, "quit") == 0)
		shell_exit();
		
	if (strcmp(s->verb->string, "cd") == 0)
		shell_cd(s->params);

	int size;
	char** argv = get_argv(s, &size);

	/* fork new process */
	pid_t child_pid = fork();
	DIE(child_pid < 0, "fork");
	
	switch(child_pid)
	{
		case 0: /* child process */
			/* perform redirections */
			redirect(s);
			/* load executable */
			execvp(s->verb->string, argv);
			fprintf(stderr, "Execution failed for '%s'\n", s->verb->string);
			exit(EXIT_FAILURE);
		pid_t pid;
		int status;
		default:
			/* wait for child to exit in parent*/
			pid = waitpid(child_pid, &status, 0);
			DIE(pid < 0, "waitpid");

			if (WIFEXITED(status))
				/* the child terminated normally,
				** return the exit status of the child */
				return WEXITSTATUS(status);
	}
	return 0;
}

/**
 * Process two commands in parallel, by creating two children.
 */
static bool do_in_parallel(command_t *cmd1, command_t *cmd2, int level, command_t *father)
{
	/* Execute cmd1 and cmd2 simultaneously */

	/* fork new process */
	pid_t child_pid = fork();
	DIE(child_pid < 0, "fork");

	switch (child_pid) {
		case 0:/* child process */
			return parse_command(cmd1, level, father);
		default:/* parent process */
			return parse_command(cmd2, level, father);
	}
	return true;
}

/**
 * Run commands by creating an anonymous pipe (cmd1 | cmd2)
 */
static bool do_on_pipe(command_t *cmd1, command_t *cmd2, int level, command_t *father)
{
	/* Redirect the output of cmd1 to the input of cmd2 */
	int pipefd[2];
	/* open pipe */
	DIE(pipe(pipefd) < 0, "pipe");

	/* fork new process */
	pid_t child_pid = fork();
	DIE(child_pid < 0, "fork");
	
	switch(child_pid)
	{
		pid_t grandchild_pid;
		case 0:/* child process */
			/* fork new process */
			grandchild_pid = fork();
			DIE(grandchild_pid < 0, "fork");

			switch(grandchild_pid)
			{
				case 0:/* grand child process */
					close(pipefd[0]);
					dup2(pipefd[1], STDOUT_FILENO);
					close(pipefd[1]);

					/* run cmd1 in grandchild */
					parse_command(cmd1, 0, NULL);
					exit(EXIT_SUCCESS);
					break;
				default:/* child process */
					exit(EXIT_SUCCESS);
					break;
			}
			break;
		pid_t pipe_pid, pid;
		int status;
		default:/* parent process */
			/* wait for child to exit in parent*/
			pid = waitpid(child_pid, &status, 0);
			DIE(pid < 0, "fork");
			
			/* fork new process */
			pipe_pid = fork();
			DIE(pipe_pid < 0, "fork");

			switch(pipe_pid)
			{
				case 0:/* child process */
					close(pipefd[1]);
					dup2(pipefd[0], STDIN_FILENO);
					close(pipefd[0]);

					/* run cmd2 in grandchild */
					parse_command(cmd2, 0, NULL);
					exit(EXIT_SUCCESS);
					break;
				default:
					close(pipefd[1]);
					close(pipefd[0]);

					/* wait for child to exit in parent*/
					pid = waitpid(pipe_pid, &status, 0);
					DIE(pid < 0, "fork");

					if (WIFEXITED(status))
						/* the child terminated normally,
						** return the exit status of the child */
						return WEXITSTATUS(status);
					return 0; 
			}
		}
	return true;
}

/**
 * Parse and execute a command.
 */
int parse_command(command_t *c, int level, command_t *father)
{
	/* Sanity checks */
	if(c->scmd != NULL)
	{	/* if there is '=', treat it like an environment variable assignment */
		if(c->scmd->verb->next_part)
			if(!strcmp(c->scmd->verb->next_part->string,"=")) {
				 /* set environment variable */
				setenv(c->scmd->verb->string,c->scmd->verb->next_part->next_part->string,1);
				return 0;
		}
	}

	if (c->op == OP_NONE) {
		/* Execute a simple command */
		return parse_simple(c->scmd, 0, NULL);
	}

	switch (c->op) {
		case OP_SEQUENTIAL:
			/* Execute the commands one after the other */
			parse_command(c->cmd1, 0, NULL);
			return parse_command(c->cmd2, 0, NULL);

		case OP_PARALLEL:
			/* Execute the commands simultaneously */
			return do_in_parallel(c->cmd1, c->cmd2, 0, NULL);

		case OP_CONDITIONAL_NZERO:
		/* Execute the second command only if the first one 
		** returns non zero */
			if (parse_command(c->cmd1, 0, NULL) != 0)
				return parse_command(c->cmd2, 0, NULL);
			break;
		case OP_CONDITIONAL_ZERO:
			/* Execute the second command only if the first one
			** returns zero */
			if (parse_command(c->cmd1, 0, NULL) == 0)
				return parse_command(c->cmd2, 0, NULL);
			break;

		case OP_PIPE:
			/* Redirect the output of the first command to the
			 * input of the second */
			return do_on_pipe(c->cmd1, c->cmd2, 0, NULL);

		default:
			assert(false);
		}
	return 1;
}

/**
 * Readline from mini-shell.
 */
char *read_line()
{
	char *instr;
	char *chunk;
	char *ret;

	int instr_length;
	int chunk_length;

	int endline = 0;

	instr = NULL;
	instr_length = 0;

	chunk = calloc(CHUNK_SIZE, sizeof(char));
	if (chunk == NULL) {
		fprintf(stderr, ERR_ALLOCATION);
		return instr;
	}

	while (!endline) {
		ret = fgets(chunk, CHUNK_SIZE, stdin);
		if (ret == NULL) {
			break;
		}

		chunk_length = strlen(chunk);
		if (chunk[chunk_length - 1] == '\n') {
			chunk[chunk_length - 1] = 0;
			endline = 1;
		}

		ret = instr;
		instr = realloc(instr, instr_length + CHUNK_SIZE + 1);
		if (instr == NULL) {
			free(ret);
			return instr;
		}
		memset(instr + instr_length, 0, CHUNK_SIZE);
		strcat(instr, chunk);
		instr_length += chunk_length;
	}

	free(chunk);

	return instr;
}

