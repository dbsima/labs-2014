Proiect PM

Student: Nicuta Laura
Grupa: 332CB



	Arhiva contine urmatoarele: arhiva surse_program_microcontroller, arhiva aplicatie_Java, 
arhiva JDK118-javax.comm si documentul WORD "Proiect PM".


     Arhiva surse_program_microcontroller contine toate fisierele ce au rezultat in urma programarii
microcontrollerului in CODE VISION AVR. 
     Arhiva aplicatie_Java contine proiectul in NetBeans ce cuprinde aplicatia prin care se transmit
comenzi catre microcontroller. 
     Arhiva JDK118-javax.comm contine pachetul javax folosit pentru comunicatia cu portul serial.
Pentru instalarea pachetului, trebuie sa se urmeze instructiunile prezente in arhiva si copiate 
fisierele "comm.jar", "javax.comm.proprieties" si "win32.comm.dll" in folderele: 
C:/Windows/System32, in folderele de bin, lib din Jre si Jdk ale versiunii Java instalate in sistem.
     Documentul WORD "Proiect PM" contine documentatia proiectului si descrierea acestuia, atat pe 
parte hardware, cat si pe parte software. 