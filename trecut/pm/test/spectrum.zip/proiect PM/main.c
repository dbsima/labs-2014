
#define F_CPU 16000000UL
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <avr/pgmspace.h>
#include <stdio.h>
#include "lcd.h"
#include "ffft.h"
#include "adc.h"

int16_t capture[FFT_N];			/* Wave captureing buffer */
complex_t bfly_buff[FFT_N];		/* FFT buffer */
uint16_t spektrum[FFT_N/2];		/* Spectrum output buffer */

//volatile int a=0;
volatile uint16_t milisec = 0;
volatile uint8_t click = 0; //1 or 0 counts if a click was performed in the last 500ms
volatile uint8_t ch = PA0; 
volatile Direction dir = UPWARDS;
void init_timer2(void)
{
#define TIME_LIMIT 20 //one millisecond (aprox...)
	OCR2=TIME_LIMIT;
	TCCR2=_BV(WGM21) | _BV(CS22) | _BV(CS21) | _BV(CS20);
	TIMSK=_BV(OCIE2);

}
void init_int1()
{
	PORTD|=_BV(PD3); //activate pull-up on INT1(PD3)
	MCUCR=_BV(ISC11);//falling edge
	GICR=_BV(INT1);	//activate INT1;
	}
//routine for timer interrupt 
SIGNAL(SIG_OUTPUT_COMPARE2){

		if(++milisec==500){
			milisec = 0;
			if(click){ //if a click was performed and the 500ms interval has exipired then this is definetly a single click
				if (ch==PA0){
					ch=PA1;
				}
				else{
					ch=PA0;
				}
			}
			click=0; //if the 500ms interval has expired then we reset the click count
		}

}
//routine for external interrupt INT1 (button)
ISR(INT1_vect) 
{
	if(click){ //this means that this is the second click in the 500ms interval definetly double click
		if (dir==UPWARDS)
			dir=DOWNWARDS;
		else
			dir=UPWARDS;

	click=0; //no triple click-ing :)
	}
	else {
	click=1;  //we will not exectue the single click code here, we wait for the 500ms interval to expire
	}

milisec=0; //we reset the timer for the 500ms interval

}
int main(void)
{	
	unsigned int i;
	Direction direction;
	uint8_t channel=PA0;
	init_timer2();
	init_int1();
	sei();
	_delay_ms(1000); //give the user one second to press the button
		if (ch==PA1){
				graphics_init(INVERTED_MODE,0x40); //This is an easter-egg, if the user presses 
				//the button imediatly after restart, the LCD will be in inverted mode
				//this has no practical advantage on the contrary it will slow the drawing procedures, but it's fun :)
				ch=PA0;	//do not affect the rest of the code
		}
		else
			graphics_init(NORMAL_MODE,0x40);
	InitADC(); //initialise the adc
	while(1){
		channel=ch;
		SET_ADC_CH(channel);
		lcd_move_base_addr(0,5);
		if (channel==PA0)
			printf("In: Microphone");
		else
			printf("In: Sound Card");
		direction=dir;
		_delay_ms(20); //this is so we can see someting on the lcd
		lcd_clear(); //clear the lcd before staring
		for(i=0;i<FFT_N;i++){ //gather 64 converted values
			capture[i]=ReadADC() - 32768;
		}
		fft_input(capture, bfly_buff);
		fft_execute(bfly_buff);
		fft_output(bfly_buff, spektrum); //transform the collected signal into frequicies
		for (i=0;i<21 ;i++){
			spektrum[i+2]*=5;
			if (spektrum[i+2]>40)
				spektrum[i+2]=40;
			bar(i,0,spektrum[i+2],BLACK,direction);	//draw the graph on the lcd
		}
	}
	return 0;
}
