#ifndef F_CPU
#define F_CPU 16000000UL
#endif
#include <stdio.h>
//#include <avr/io.h>
#include <avr/pgmspace.h>
//#include <avr/interrupt.h>
#include <util/delay.h>
#include "lcd.h"

#define write_bank(bank,x,c)\
	do{\
	if(c) (bank)|=(x);\
	else (bank)&=~(x);\
	}while(0);

typedef enum { SEND_CMD  = 0, SEND_DATA = 1 } LcdCmdData; //to decide between sending cmd or data to the lcd
/* A copy of the screen is kept by the controller as well*/
unsigned char screen[84][6];

//this mask is used to draw a complete a bar in the lower part of an upward bar
const unsigned char PROGMEM data_mask_up[]={0xFF,0x80,0xC0,0xE0,0xF0,0xF8,0xFC,0xFE};
//this mask is used to draw a complete a bar in the upper part of an upward bar
const unsigned char PROGMEM data_mask_down[]={0x00,0x7F,0x3F,0x1F,0x0F,0x07,0x03,0x01};
//this mask is used to draw a complete a bar in the upper part of a downward bar
const unsigned char PROGMEM data_mask_up2[]={0xFF,0xFE,0xFC,0xF8,0xF0,0xE0,0xC0,0x80};
//this mask is used to draw a complete a bar in the lowr part of a downward bar
const unsigned char PROGMEM data_mask_down2[]={0x00,0x01,0x03,0x07,0x0F,0x1F,0x3F,0x7F};
/*this is useed to print characters on the LCD*/
unsigned char PROGMEM font5x7 [][5] = {
	{ 0x00, 0x00, 0x00, 0x00, 0x00 },   // space
    { 0x00, 0x00, 0x2f, 0x00, 0x00 },   // !
    { 0x00, 0x07, 0x00, 0x07, 0x00 },   // "
    { 0x14, 0x7f, 0x14, 0x7f, 0x14 },   // #
    { 0x24, 0x2a, 0x7f, 0x2a, 0x12 },   // $
	{ 0x32, 0x34, 0x08, 0x16, 0x26 },   // %
    { 0x36, 0x49, 0x55, 0x22, 0x50 },   // &
    { 0x00, 0x05, 0x03, 0x00, 0x00 },   // '
    { 0x00, 0x1c, 0x22, 0x41, 0x00 },   // (
    { 0x00, 0x41, 0x22, 0x1c, 0x00 },   // )
    { 0x14, 0x08, 0x3E, 0x08, 0x14 },   // *
    { 0x08, 0x08, 0x3E, 0x08, 0x08 },   // +
    { 0x00, 0x00, 0x50, 0x30, 0x00 },   // ,
    { 0x10, 0x10, 0x10, 0x10, 0x10 },   // -
    { 0x00, 0x60, 0x60, 0x00, 0x00 },   // .
    { 0x20, 0x10, 0x08, 0x04, 0x02 },   // /
    { 0x3E, 0x51, 0x49, 0x45, 0x3E },   // 0
    { 0x00, 0x42, 0x7F, 0x40, 0x00 },   // 1
    { 0x42, 0x61, 0x51, 0x49, 0x46 },   // 2
    { 0x21, 0x41, 0x45, 0x4B, 0x31 },   // 3
    { 0x18, 0x14, 0x12, 0x7F, 0x10 },   // 4
    { 0x27, 0x45, 0x45, 0x45, 0x39 },   // 5
    { 0x3C, 0x4A, 0x49, 0x49, 0x30 },   // 6
    { 0x01, 0x71, 0x09, 0x05, 0x03 },   // 7
    { 0x36, 0x49, 0x49, 0x49, 0x36 },   // 8
    { 0x06, 0x49, 0x49, 0x29, 0x1E },   // 9
    { 0x00, 0x36, 0x36, 0x00, 0x00 },   // :
    { 0x00, 0x56, 0x36, 0x00, 0x00 },   // ;
    { 0x08, 0x14, 0x22, 0x41, 0x00 },   // <
    { 0x14, 0x14, 0x14, 0x14, 0x14 },   // =
    { 0x00, 0x41, 0x22, 0x14, 0x08 },   // >
    { 0x02, 0x01, 0x51, 0x09, 0x06 },   // ?
    { 0x32, 0x49, 0x59, 0x51, 0x3E },   // @
    { 0x7E, 0x11, 0x11, 0x11, 0x7E },   // A
    { 0x7F, 0x49, 0x49, 0x49, 0x36 },   // B
    { 0x3E, 0x41, 0x41, 0x41, 0x22 },   // C
    { 0x7F, 0x41, 0x41, 0x22, 0x1C },   // D
    { 0x7F, 0x49, 0x49, 0x49, 0x41 },   // E
    { 0x7F, 0x09, 0x09, 0x09, 0x01 },   // F
    { 0x3E, 0x41, 0x49, 0x49, 0x7A },   // G
    { 0x7F, 0x08, 0x08, 0x08, 0x7F },   // H
    { 0x00, 0x41, 0x7F, 0x41, 0x00 },   // I
    { 0x20, 0x40, 0x41, 0x3F, 0x01 },   // J
    { 0x7F, 0x08, 0x14, 0x22, 0x41 },   // K
    { 0x7F, 0x40, 0x40, 0x40, 0x40 },   // L
    { 0x7F, 0x02, 0x0C, 0x02, 0x7F },   // M
    { 0x7F, 0x04, 0x08, 0x10, 0x7F },   // N
    { 0x3E, 0x41, 0x41, 0x41, 0x3E },   // O
    { 0x7F, 0x09, 0x09, 0x09, 0x06 },   // P
    { 0x3E, 0x41, 0x51, 0x21, 0x5E },   // Q
    { 0x7F, 0x09, 0x19, 0x29, 0x46 },   // R
    { 0x46, 0x49, 0x49, 0x49, 0x31 },   // S
    { 0x01, 0x01, 0x7F, 0x01, 0x01 },   // T
    { 0x3F, 0x40, 0x40, 0x40, 0x3F },   // U
    { 0x1F, 0x20, 0x40, 0x20, 0x1F },   // V
    { 0x3F, 0x40, 0x38, 0x40, 0x3F },   // W
    { 0x63, 0x14, 0x08, 0x14, 0x63 },   // X
    { 0x07, 0x08, 0x70, 0x08, 0x07 },   // Y
    { 0x61, 0x51, 0x49, 0x45, 0x43 },   // Z
    { 0x00, 0x7F, 0x41, 0x41, 0x00 },   // [
    { 0x55, 0x2A, 0x55, 0x2A, 0x55 },   // 55
    { 0x00, 0x41, 0x41, 0x7F, 0x00 },   // ]
    { 0x04, 0x02, 0x01, 0x02, 0x04 },   // ^
    { 0x40, 0x40, 0x40, 0x40, 0x40 },   // _
    { 0x00, 0x01, 0x02, 0x04, 0x00 },   // '
    { 0x20, 0x54, 0x54, 0x54, 0x78 },   // a
    { 0x7F, 0x48, 0x44, 0x44, 0x38 },   // b
    { 0x38, 0x44, 0x44, 0x44, 0x20 },   // c
    { 0x38, 0x44, 0x44, 0x48, 0x7F },   // d
    { 0x38, 0x54, 0x54, 0x54, 0x18 },   // e
    { 0x08, 0x7E, 0x09, 0x01, 0x02 },   // f
    { 0x0C, 0x52, 0x52, 0x52, 0x3E },   // g
    { 0x7F, 0x08, 0x04, 0x04, 0x78 },   // h
    { 0x00, 0x44, 0x7D, 0x40, 0x00 },   // i
    { 0x20, 0x40, 0x44, 0x3D, 0x00 },   // j
    { 0x7F, 0x10, 0x28, 0x44, 0x00 },   // k
    { 0x00, 0x41, 0x7F, 0x40, 0x00 },   // l
    { 0x7C, 0x04, 0x18, 0x04, 0x78 },   // m
    { 0x7C, 0x08, 0x04, 0x04, 0x78 },   // n
    { 0x38, 0x44, 0x44, 0x44, 0x38 },   // o
    { 0x7C, 0x14, 0x14, 0x14, 0x08 },   // p
    { 0x08, 0x14, 0x14, 0x18, 0x7C },   // q
    { 0x7C, 0x08, 0x04, 0x04, 0x08 },   // r
    { 0x48, 0x54, 0x54, 0x54, 0x20 },   // s
    { 0x04, 0x3F, 0x44, 0x40, 0x20 },   // t
    { 0x3C, 0x40, 0x40, 0x20, 0x7C },   // u
    { 0x1C, 0x20, 0x40, 0x20, 0x1C },   // v
    { 0x3C, 0x40, 0x30, 0x40, 0x3C },   // w
    { 0x44, 0x28, 0x10, 0x28, 0x44 },   // x
    { 0x0C, 0x50, 0x50, 0x50, 0x3C },   // y
    { 0x44, 0x64, 0x54, 0x4C, 0x44 },   // z
    { 0x00, 0x7F, 0x3E, 0x1C, 0x08 },   // > Filled
	{ 0x08, 0x1C, 0x3E, 0x7F, 0x00 }, 	 // < Filled
	{ 0x08, 0x7C, 0x7E, 0x7C, 0x08 },   // Arrow up
	{ 0x10, 0x3E, 0x7E, 0x3E, 0x10 },   // Arrow down	
	{ 0x3E, 0x3E, 0x3E, 0x3E, 0x3E },   // Stop
	{ 0x00, 0x7F, 0x3E, 0x1C, 0x08 }    // Play
};
/* Function prototypes */
void lcd_init(VideoMode video_mode); //initialization of the controller 
void lcd_send(unsigned char data, LcdCmdData cd); //sente either a command or a data byte
void lcd_chr(char chr);

/******************************************************************************************************************************
*                                                                                                                             *
*                                            Communication with LCD API                                                       *
*                                                                                                                             *
******************************************************************************************************************************/

// Initialisation of the controller
void lcd_init(VideoMode video_mode){
	int i;
	// Pull-up on reset pin
	LCD_PORT |= LCD_RST_PIN;
	
	// Set output bits on lcd port
	LCD_DDR |= LCD_RST_PIN | LCD_CE_PIN | LCD_DC_PIN | LCD_DATA_PIN | LCD_CLK_PIN;

	// Wait after VCC high for reset (max 30ms)
	_delay_ms(15);

	// Toggle display reset pin
	LCD_PORT &= ~LCD_RST_PIN;
	for(i=-32000;i<32000;i++); //wait some time
	LCD_PORT |= LCD_RST_PIN;

	// Disable LCD controller
	LCD_PORT |= LCD_CE_PIN;
	//Sending initialization commands:
	lcd_send(0x21, SEND_CMD);  //0b00100001 Function set: horziontal adressing & use exdended commands
	lcd_send(0xC8, SEND_CMD);  //0b11001000 Set LCD Vop (Contrast)
	lcd_send(0x06, SEND_CMD);  //0b00000110 Set Temperature coefficient 2 
	lcd_send(0x13, SEND_CMD);  //0b00010011 LCD bias mode 1:48
	lcd_send(0x20, SEND_CMD);  //0b00100000 Funciton set: horizontal addressing & use standar commands
	lcd_send(0x0C | video_mode, SEND_CMD);  //0b00001100 Set display configuration: normal or inverted

	//Clear lcd
	lcd_clear();
	//Associate the function lcd_chr with de std_out so we can use printf
	fdevopen(lcd_chr, 0);	
}

//Set display contrast
void lcd_contrast(unsigned char contrast)
{
	lcd_send(0x21, SEND_CMD); //extended commands 
	lcd_send(0x80 | contrast, SEND_CMD);	//set the vop: contrast must be between 0 and 63
	lcd_send(0x20, SEND_CMD); //back to standard commands
}

/* Clears the display */
void lcd_clear(void)
{
	unsigned char x,y;
	lcd_move_base_addr(0,0);
	
	// Set the entire cache to zero and write 0s to lcd
	for(x=0;x<84;x++)
		for(y=0;y<6;y++){
		screen[x][y]=0;
		lcd_send(0, SEND_DATA);
	}
} 
//Moves the base address of the lcd
void lcd_move_base_addr(unsigned char x, unsigned char y){
	if (x>83 || y>5) return;
	lcd_send(0x80 |x, SEND_CMD);
	lcd_send(0x40 |y, SEND_CMD);
}

//Sends data or commands to display controller
void lcd_send(unsigned char data, LcdCmdData cd)
{
	unsigned char i;
	// Data/DC are outputs for the lcd (all low)
	LCD_DDR |= LCD_DATA_PIN | LCD_DC_PIN;
	
	// Enable display controller (active low)
	LCD_PORT &= ~LCD_CE_PIN;

	//set D/C pin on the corresponding value 
	if(cd == SEND_DATA){
		LCD_PORT |= LCD_DC_PIN;
	}
	else{
		LCD_PORT &= ~LCD_DC_PIN;
	}
	
	for(i=0;i<8;i++) {
	
		// Set the DATA pin value
		if((data>>(7-i)) & 0x01) {
			LCD_PORT |= LCD_DATA_PIN;
		} else {
			LCD_PORT &= ~LCD_DATA_PIN;
		}
		
		// Toggle the clock
		LCD_PORT |= LCD_CLK_PIN;
		LCD_PORT &= ~LCD_CLK_PIN;
	}

	// Disable display controller
	LCD_PORT |= LCD_CE_PIN;
	LCD_DDR &= ~(LCD_DATA_PIN | LCD_DC_PIN);
	LCD_PORT |= LCD_DATA_PIN | LCD_DC_PIN;
}
/******************************************************************************************************************************
*                                                                                                                             *
*                                            Graphical API                                                                    *
*                                                                                                                             *
******************************************************************************************************************************/
//Initializes the lcd and sets the contrast
void graphics_init(VideoMode vm, unsigned char contrast){
	lcd_init(vm);
	lcd_contrast(contrast);
	_delay_ms(300); 
}
/* THESE FUNCTIONS ARE NOT USED ANYMORE
//Draws a point on the (x,y) coordinates (x=0..83, y=0..47) of the color c (B/W)
//NOTE the color is relative to the backgrowund so if the display si in inverse video mode then Black means White and viceversa
void plot(unsigned char x,unsigned char y, Color c){
	if(x>83 || y>47) return;
	unsigned char y_real=y>>3;
	//put the pixel in the local memory
	write_bank(screen[x][y_real], 1<< (y&7), c);
	lcd_move_base_addr(x,y_real);
	lcd_send(screen[x][y_real],SEND_DATA);
}
//Draws a point on the (x,y) coordinates (x=0..83, y=0..47) of the color c (B/W)
//NOTE the color is relative to the backgrowund so if the display is in inverse video mode then Black means White and viceversa
void line(unsigned char x0, unsigned char y0, unsigned char x1, unsigned char y1, Color c){
	if (x0>83 || y0>47 || x1>83 || y1>47) return;
	signed char dy = y1 - y0;
	signed char dx = x1 - x0;
	signed char stepx, stepy;
	signed char fraction;

	if (dy < 0){
		dy = -dy;
		stepy = -1;
	}
	else{
	stepy = 1; }
	if (dx < 0){ dx = -dx;  stepx = -1; } else { stepx = 1; }
	dy <<= 1;
	dx <<= 1;
	plot(x0,y0,c);
	if (dx > dy){
		fraction = dy - (dx >> 1);
		while (x0 != x1){
			if (fraction >= 0){
				y0 += stepy;
				fraction -= dx;
				}
			x0 += stepx;
			fraction += dy;
			plot(x0,y0,c);
		}
	}
	else
	{
		fraction = dx - (dy >> 1);
		while (y0 != y1){
			if (fraction >= 0){
				x0 += stepx;
				fraction -= dy;
			}
			y0 += stepy;
			fraction += dx;
			plot(x0,y0,c);
		}
	}
}

*/	
//draws a solid bar on a pre-estabilshed position
void bar(unsigned char pos, unsigned char base, unsigned char height, Color c, Direction d){
	if (height ==0 || height>40 || base>40 || pos>21) return;
	unsigned char low,high,x,i;
	x=pos*4;
	
	if(d==UPWARDS){
		low=(40-height)>>3;
		high=(40-base)>>3;

		if (low==high){
			lcd_move_base_addr(x,high);

			write_bank(screen[x][high],pgm_read_byte(&data_mask_up[height & 7]) & pgm_read_byte(&data_mask_down[base &7]),c);
			lcd_send(screen[x][high],SEND_DATA);

			write_bank(screen[x+1][high],pgm_read_byte(&data_mask_up[height & 7]) & pgm_read_byte(&data_mask_down[base &7]),c);
			lcd_send(screen[x+1][high],SEND_DATA);

			write_bank(screen[x+2][high],pgm_read_byte(&data_mask_up[height & 7]) & pgm_read_byte(&data_mask_down[base &7]),c);
			lcd_send(screen[x+2][high],SEND_DATA);
			return;
		}

		lcd_move_base_addr(x,high);
		write_bank(screen[x][high], pgm_read_byte(&data_mask_down[base &7]),c);
		lcd_send(screen[x][high],SEND_DATA);

		write_bank(screen[x+1][high], pgm_read_byte(&data_mask_down[base &7]),c);
		lcd_send(screen[x+1][high],SEND_DATA);

		write_bank(screen[x+2][high], pgm_read_byte(&data_mask_down[base &7]),c);
		lcd_send(screen[x+2][high],SEND_DATA);
	
		for (i=high-1;i>low;i--){
			lcd_move_base_addr(x,i);

			if(c) screen[x][i] =0xFF;
			else screen[x][i] =0x00;
			lcd_send(screen[x][i],SEND_DATA);

			if(c) screen[x+1][i] =0xFF;
			else screen[x+1][i] =0x00;
			lcd_send(screen[x+1][i],SEND_DATA);

			if(c) screen[x+2][i] =0xFF;
			else screen[x+2][i] =0x00;
			lcd_send(screen[x+2][i],SEND_DATA);
		}
		lcd_move_base_addr(x,i);

		write_bank(screen[x][i],pgm_read_byte(&data_mask_up[height &7]),c);
		lcd_send(screen[x][i],SEND_DATA);

		write_bank(screen[x+1][i],pgm_read_byte(&data_mask_up[height &7]),c);
		lcd_send(screen[x+1][i],SEND_DATA);

		write_bank(screen[x+2][i],pgm_read_byte(&data_mask_up[height &7]),c);
		lcd_send(screen[x+2][i],SEND_DATA);
	}
	else{
		low=(base)>>3;
		high=(height)>>3;

		if (low==high){
			lcd_move_base_addr(x,high);

			write_bank(screen[x][high],pgm_read_byte(&data_mask_up2[base & 7]) & pgm_read_byte(&data_mask_down2[height &7]),c);
			lcd_send(screen[x][high],SEND_DATA);

			write_bank(screen[x+1][high],pgm_read_byte(&data_mask_up2[base & 7]) & pgm_read_byte(&data_mask_down2[height &7]),c);
			lcd_send(screen[x+1][high],SEND_DATA);

			write_bank(screen[x+2][high],pgm_read_byte(&data_mask_up2[base & 7]) & pgm_read_byte(&data_mask_down2[height &7]),c);
			lcd_send(screen[x+2][high],SEND_DATA);
			return;
		}

		lcd_move_base_addr(x,low);
		write_bank(screen[x][low],pgm_read_byte(&data_mask_up2[base &7]),c);
		lcd_send(screen[x][low],SEND_DATA);

		write_bank(screen[x+1][low],pgm_read_byte(&data_mask_up2[base &7]),c);
		lcd_send(screen[x+1][low],SEND_DATA);

		write_bank(screen[x+2][low],pgm_read_byte(&data_mask_up2[base &7]),c);
		lcd_send(screen[x+2][low],SEND_DATA);

		for (i=low+1;i<high;i++){
			lcd_move_base_addr(x,i);

			if(c) screen[x][i] =0xFF;
			else screen[x][i] =0x00;
			lcd_send(screen[x][i],SEND_DATA);

			if(c) screen[x+1][i] =0xFF;
			else screen[x+1][i] =0x00;
			lcd_send(screen[x+1][i],SEND_DATA);

			if(c) screen[x+2][i] =0xFF;
			else screen[x+2][i] =0x00;
			lcd_send(screen[x+2][i],SEND_DATA);
		}

		lcd_move_base_addr(x,high);
		write_bank(screen[x][high], pgm_read_byte(&data_mask_down2[height &7]),c);
		lcd_send(screen[x][high],SEND_DATA);

		write_bank(screen[x+1][high], pgm_read_byte(&data_mask_down2[height &7]),c);
		lcd_send(screen[x+1][high],SEND_DATA);

		write_bank(screen[x+2][high], pgm_read_byte(&data_mask_down2[height &7]),c);
		lcd_send(screen[x+2][high],SEND_DATA);
	}
}
//prints a character on the screen
void lcd_chr(char chr)
{
	unsigned char i;
    // 5 pixel wide characters and add space
    for(i=0;i<5;i++) {
		lcd_send(pgm_read_byte(&font5x7[chr-32][i]) << 1, SEND_DATA);
    }
	lcd_send(0, SEND_DATA);
	
}


