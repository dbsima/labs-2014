#ifndef _LCD_H_
#define _LCD_H_

/* Lcd screen size */
#define LCD_X_MAX 84
#define LCD_Y_MAX 48

/* Pinout for LCD */
#define LCD_CLK_PIN 	(1<<PC4)
#define LCD_DATA_PIN 	(1<<PC3)
#define LCD_DC_PIN 		(1<<PC2)
#define LCD_CE_PIN 		(1<<PC1)
#define LCD_RST_PIN 	(1<<PC0)
#define LCD_PORT		PORTC
#define LCD_DDR			DDRC

typedef enum { WHITE = 0, BLACK= 1 } Color;
typedef enum { WIREFRAME= 0, SOLID= 1 } FillType;
typedef enum { NORMAL_MODE=0, INVERTED_MODE=1} VideoMode;
typedef enum { UPWARDS=0,DOWNWARDS=1} Direction;

/*//Draws a pixel of color c on (x,y) 
void plot(unsigned char x,unsigned char y, Color c);
//Draws a line between the two pixels
void line(unsigned char x0, unsigned char y0, unsigned char x1, unsigned char y1, Color c);
*/
//Draws a vertical bar (3 pixels width) from base to height. There are 21 positions for bars. each correspunding
//with a frequency. The bar can start from bottom and grow upwards or from the top and grow downwards
void bar(unsigned char pos, unsigned char base, unsigned char height, Color c, Direction d);
//initialises the lcd and sets it;s contrast
void graphics_init(VideoMode vm, unsigned char contrast);
//clears the lcd
void lcd_clear(void);
//sets the cursor to the diseried coordinates
void lcd_move_base_addr(unsigned char x, unsigned char y);

#endif



