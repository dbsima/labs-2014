#ifndef ADC_H
#define ADC_H
//macro function to tell the adc on wich port to listen
//ch must be PA0,PA1,...,PA7
//first clear MUX0..MUX2
//then set the appropiate channel (pin)
#define SET_ADC_CH(ch) {	\
	ADMUX&=0b11111000;		\
	ADMUX|=((ch)&7);		\
	}
//Initialize the ADC (by default it listens on PA0 to change that use above macro)
void InitADC();
//reads analogical data on the input pin and converts it...
uint16_t ReadADC();
#endif
