#include <avr\io.h>
#include "adc.h"

void InitADC(){
	
	PORTA=0;
	ADMUX=(1<<REFS0);// For Aref=AVcc;
	ADCSRA=(1<<ADEN) | (1<<ADPS1)| (1<<ADPS0) | (0<<ADPS2); //Prescalar div factor =128
}
uint16_t ReadADC(){
	//Start Single conversion
	ADCSRA|=(1<<ADSC);
	//Wait for conversion to complete
	while(!(ADCSRA & (1<<ADIF)));

   //Clear ADIF by writing one to it
   //Note you may be wondering why we have write one to clear it
   //This is standard way of clearing bits in io as said in datasheets.
   //The code writes '1' but it result in setting bit to '0' !!!

	ADCSRA|=(1<<ADIF);

	return(ADC);
}
#include <math.h>

