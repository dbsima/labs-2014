#ifndef KEYBOARD_H
#define KEYBOARD_H

#include <avr/io.h>

#define COL2 PD0
#define ROW1 PD1
#define COL1 PD2
#define ROW4 PD3
#define COL3 PD4
#define ROW3 PD5
#define ROW2 PD6


int getkey();

#endif