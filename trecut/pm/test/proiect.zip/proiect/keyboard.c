#include "keyboard.h"

int rows [] = {ROW1, ROW2, ROW3, ROW4};
int cols [] = {COL1, COL2, COL3};


int getkey()
{
    PORTD |= (1 << ROW2) | (1 << ROW1) | (1 << ROW3) | (1 << ROW4);  // activam rezistenta de pull-up
  
  DDRD |= (1 << COL1) | (1 << COL2) | (1 << COL3);
   int i;
  
       if (!(PIND & (1 << ROW3)) || !(PIND & (1 << ROW1)) || !(PIND & (1 << ROW2)) || !(PIND & (1 << ROW4))) {
      PORTD |= (1 << PD7);    // LED ON
    } else 
      PORTD &= ~(1 << PD7);   // LED OFF
}
