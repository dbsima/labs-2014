/************************************************************************ *********
 * Proiectarea cu Microprocesoare
 * Laboratorul 1
 * Digital I/O
 *********************************************************************************/

#include <avr/io.h>
#include <avr/interrupt.h>
#define F_CPU 16000000
#include <util/delay.h>

#include <string.h>

#include "lcd.h"
#include "keyboard.h"

int main()
{
//    DDRD &= ~(1 << PD6);  // pinul PD6 va fi input
 

  DDRD |= (1 << PD7);   // pinul corespunzator led-ului USER este output
   LCD_init();
   LCD_print2("BAAAAUUUUUaaa2ws", "HAHAHAde4y2wdfae32ed");
//    LCD_waitNotBusy();
   
   
   while (1)
  {  
     getkey();

  }

	while(1);
	
	return 0;
}
