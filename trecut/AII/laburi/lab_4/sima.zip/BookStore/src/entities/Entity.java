package entities;

import java.util.ArrayList;

public class Entity {
    public ArrayList<String> getValues() {
        ArrayList<String> result = new ArrayList<>();
        return result;
    }
}
