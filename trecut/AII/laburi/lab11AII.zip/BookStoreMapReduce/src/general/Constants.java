package general;

public interface Constants {
	final static String		FILE									= "fisier";
	final static String		TABLE									= "tabela";
	final static String		RESULTS_DESTINATION						= TABLE; // available options: FILE, TABLE
	
	final static int 		REDUCE_TASKS_NUMBER						= 1;
	
	final static int		CACHING_VALUE							= 500;
	final static boolean	CACHE_BLOCKS_VALUE						= false;
	
	final static String		KEY_VALUE_SEPARATOR_PROPERTY_NAME		= "mapreduce.input.keyvaluelinerecordreader.key.value.separator";
	final static String 	KEY_VALUE_SEPARATOR_VALUE				= "\t";
	
	final static String		BILLS_TABLE_NAME						= "facturi";
	final static String		CONSUMER_FAMILY_COLUMN					= "consumator";
	final static String		NUMERIC_PERSONAL_CODE_COLUMN			= "CNP";
	
	final static String 	BILL_DETAILS_TABLE_NAME					= "detalii_factura";
	final static String		REFERENCE_FAMILY_COLUMN					= "referinta";
	final static String		BILL_IDENTIFIER_COLUMN					= "id_factura";
	final static String		CONTENT_FAMILY_NAME						= "continut";
	final static String		BOOK_IDENTIFIER_COLUMN					= "id_carte";
	final static String		QUANTITY_COLUMN							= "cantitate";
	
	final static String		BOOKS_TABLE_NAME						= "carti";
	final static String		ADMINISTRATION_FAMILY_COLUMN			= "gestiune";
	final static String		PRICE_COLUMN							= "pret";
	
	final static String		USERS_TABLE_NAME						= "utilizatori";
	final static String		IDENTIFICATION_FAMILY_COLUMN			= "intitulare";	
	final static String		FIRST_NAME_COLUMN						= "prenume";
	final static String		LAST_NAME_COLUMN						= "nume";
	
	final static String		STATISTICS_TABLE_NAME					= "statistici";
	final static String		EXPENSES_FAMILY_COLUMN					= "cheltuieli";
	final static String		VALUE_COLUMN							= "valoare";
	
	final static String 	BILL_VALUE_JOB_NAME						= "valoarefactura";
	final static String 	BILL_VALUE_OUTPUT_PATH					= "hdfs://localhost:9000/user/aii2013/billValues";
	final static String 	BILL_VALUE_EXCEPTION_MESSAGE			= "Eroare la rularea sarcinii obtinere valoare factura!";
	
	final static String 	USER_EXPENSES_JOB_NAME					= "cheltuieliutilizator";
	final static String 	USER_EXPENSES_OUTPUT_PATH				= "hdfs://localhost:9000/user/aii2013/userExpenses";
	final static String 	USER_EXPENSES_EXCEPTION_MESSAGE			= "Eroare la rularea sarcinii obtinere cheltuieli utilizatori!";
}
