import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class UserExpensesFileReducer extends Reducer<Text, LongWritable, Text, LongWritable> {

	public void reduce(Text userFirstLastName, Iterable<LongWritable> billValues, Context context) throws IOException, InterruptedException {
		// TO DO (exercise 5f): calculate client bills' value and write them to the context
		long val = 0;
		for(LongWritable billVal : billValues)
			val += billVal.get();
		context.write(userFirstLastName, new LongWritable(val));
	}

}
