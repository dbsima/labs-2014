import general.Constants;
import java.io.IOException;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.hadoop.hbase.mapreduce.TableReducer;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;

public class UserExpensesTableReducer extends TableReducer<Text, LongWritable, ImmutableBytesWritable>  {
   	
	public void reduce(Text userFirstLastName, Iterable<LongWritable> billValues, Context context) throws IOException, InterruptedException {
		// TO DO (exercise 6): calculate client bills' value and write them into the expenses table
		long val = 0;
		for(LongWritable billVal : billValues)
			val += billVal.get();
		Put put = new Put(Bytes.toBytes(userFirstLastName.toString()));
		put.add("cheltuieli".getBytes(), "valoare".getBytes(), Bytes.toBytes(val));
		
		context.write(null, put);
		
	}
}
  