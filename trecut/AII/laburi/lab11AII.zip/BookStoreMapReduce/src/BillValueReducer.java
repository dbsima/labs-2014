import general.Constants;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class BillValueReducer extends Reducer<Text, LongWritable, Text, LongWritable>  {

	public void reduce(Text billIdentifier, Iterable<LongWritable> billProductValues, Context context) throws IOException, InterruptedException {
		long billValue = 0;
		for (LongWritable billProductValue : billProductValues) {
			// TO DO (exercise 5b): calculate billValue
			billValue += billProductValue.get();
			
		}
		Configuration configuration = HBaseConfiguration.create();
		
      	// TO DO (exercise 5c): get the numerical personal code of the user who has paid the bill
		HTable facturi  = new HTable(configuration, "facturi");
		String cnp = "";
		long val = 0;
		try {
			// TO DO (exercise 5a): get the book price from the corresponding HBase tabl
			Get get = new Get(billIdentifier.getBytes());
			get.addColumn("consumator".getBytes(), "CNP".getBytes());
			Result result = facturi.get(get);
			cnp = new String(result.getValue("consumator".getBytes(), "CNP".getBytes()));
		}
		
		catch (Exception e){
			
		}
		finally {
			facturi.close();
			
		}
		
      	// TO DO (exercise 5d): get the first name and the last name of the user with the numerical personal code that has been determined
		HTable utilizatori  = new HTable(configuration, "utilizatori");
		String userFirstLastName = "";
		try {
			Get get = new Get(cnp.getBytes());
			get.addColumn("intitulare".getBytes(), "nume".getBytes());
			get.addColumn("intitulare".getBytes(), "prenume".getBytes());
			Result result = utilizatori.get(get);
			userFirstLastName += new String(result.getValue("intitulare".getBytes(), "nume".getBytes()));
			userFirstLastName += " " + new String(result.getValue("intitulare".getBytes(), "prenume".getBytes()));
		}
		
		catch (Exception e){
			
		}
		finally {
			utilizatori.close();
			
		}
		//String userFirstLastName = "dummy";
      	context.write(new Text(userFirstLastName), new LongWritable(billValue));
	}
}
  
  
