import general.Constants;

import java.io.IOException;

import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.io.ImmutableBytesWritable;
import org.apache.hadoop.hbase.mapreduce.TableMapper;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.conf.Configuration;

public class BillValueMapper extends TableMapper<Text, LongWritable>  {

   	public void map(ImmutableBytesWritable billDetailIdentifier, Result billDetailValue, Context context) throws IOException, InterruptedException {
   			Text billIdentifier = new Text(billDetailValue.getValue(Constants.REFERENCE_FAMILY_COLUMN.getBytes(), Constants.BILL_IDENTIFIER_COLUMN.getBytes()));
   			String bookIdentifier = new String(billDetailValue.getValue(Constants.CONTENT_FAMILY_NAME.getBytes(), Constants.BOOK_IDENTIFIER_COLUMN.getBytes()));       	
   			String bookQuantity = new String(billDetailValue.getValue(Constants.CONTENT_FAMILY_NAME.getBytes(), Constants.QUANTITY_COLUMN.getBytes()));
   			
   			Configuration configuration = HBaseConfiguration.create();
          	
   			HTable books  = new HTable(configuration, "carti");
   			long val = 0;
   			try {
   			// TO DO (exercise 5a): get the book price from the corresponding HBase tabl
   			
   			
   			//
   			Get get = new Get(bookIdentifier.getBytes());
   			
   			//
   			get.addColumn("gestiune".getBytes(), "pret".getBytes());
   			
   			//
   			Result result = books.get(get);
   			
   			//
   			//new String(billDetailValue.getValue(Constants.CONTENT_FAMILY_NAME.getBytes(), Constants.QUANTITY_COLUMN.getBytes()));
   			String pret = new String(result.getValue("gestiune".getBytes(), "pret".getBytes()));
   			
   			//
   			val = Long.parseLong(pret) * Long.parseLong(bookQuantity);  
   			//System.out.println(pret + " " + bookQuantity );
   			books.close();
   			
   			}
   			
   			catch (Exception e){
   				System.out.println("error");
   			}
   			finally {
   				books.close();
   				
   			}
   			//System.out.println(billIdentifier + " " + val );
        	context.write(billIdentifier, new LongWritable(val));
   	}
}
   
   
