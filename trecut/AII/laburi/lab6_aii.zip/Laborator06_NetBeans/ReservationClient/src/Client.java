import org.omg.CORBA.*;
import org.omg.CosNaming.*;
import Reservation.*;

public class Client {
    
    public static void main (String[] args) {
        
        try {
            // creare si initializare ORB
            ORB orb = ORB.init(args,null);
            
            // obtine contextul de nume radacina
            org.omg.CORBA.Object nameServiceRef = orb.resolve_initial_references("NameService");
            NamingContextExt namingContextRef = NamingContextExtHelper.narrow(nameServiceRef);
            
            // rezolvare referinta obiect distribuit prin serviciu de nume
            String serviceName = "ReservationService";
            ReservationService reservationServiceRef = ReservationServiceHelper.narrow(namingContextRef.resolve_str(serviceName));

            // rezervation 1 - 10:00 to 12:00 (10 seats) => should make the reservation (15 available)
            System.out.println("make 1 " + reservationServiceRef.makeReservation(1, new Interval(new Time(new Date(4,11,2013), new Moment(10,0)),new Time(new Date(4,11,2013), new Moment(12,0))), 10));
            
            // reservation 2 - 10:00 to 12:00 (10 seats) => should NOT make the reservation (5 available)
            System.out.println("make 2 " + reservationServiceRef.makeReservation(1, new Interval(new Time(new Date(4,11,2013), new Moment(10,0)),new Time(new Date(4,11,2013), new Moment(12,0))), 10));
            
            // reservation 3 - 14:00 to 19:00 (10 seats) => should make the reservation (15 available)
            System.out.println("make 3 " + reservationServiceRef.makeReservation(1, new Interval(new Time(new Date(4,11,2013), new Moment(14,0)),new Time(new Date(4,11,2013), new Moment(19,0))), 10));
            
            // reservation 4 - 18:00 to 19:00 (10 seats) => should NOT make the reservation (5 available)
            System.out.println("make 4 " + reservationServiceRef.makeReservation(1, new Interval(new Time(new Date(4,11,2013), new Moment(18,0)),new Time(new Date(4,11,2013), new Moment(19,0))), 10));
            
            // cancel reservation 1 - 18:00 to 19:00 => does NOT exist
            System.out.println("cancel 1 " + reservationServiceRef.cancelReservation(1, new Interval(new Time(new Date(4,11,2013), new Moment(18,0)),new Time(new Date(4,11,2013), new Moment(19,0)))));
        
            // get all reservations for user with id = 1 => should return 2
            System.out.println("#reservation " + reservationServiceRef.getReservation(1).length);
             
            // cancel reservation 2 - 14:00 to 19:00 => does exist 
            System.out.println("cancel 2 " + reservationServiceRef.cancelReservation(1, new Interval(new Time(new Date(4,11,2013), new Moment(14,0)),new Time(new Date(4,11,2013), new Moment(19,0)))));
        
            // get all reservations for user with id = 1 => should return 2
            System.out.println("#reservation " + reservationServiceRef.getReservation(1).length);
        }
        catch (Exception exception) {
            System.out.println("exceptie: "+exception.getMessage());
            exception.printStackTrace();
        }
    }
}
