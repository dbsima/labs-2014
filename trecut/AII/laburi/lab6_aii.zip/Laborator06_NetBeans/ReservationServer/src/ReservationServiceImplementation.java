
import Reservation.Moment;
import Reservation.Time;
import entities.Interval;
import entities.ReservationData;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TreeSet;

public class ReservationServiceImplementation extends Reservation.ReservationServicePOA { 
    
    private int                                    numberOfSeats;
    private ArrayList<entities.Interval>           timetable;
    private ArrayList<entities.ReservationData>    reservations;
    
    public ReservationServiceImplementation() throws IOException {
        numberOfSeats   = -1;
        timetable       = new ArrayList<>();
        reservations    = new ArrayList<>();
        // TO DO: exercise 3a
        List<Integer> list = new ArrayList<>();
        File file = new File("timetable.txt");
        BufferedReader reader = null;

        try {
            reader = new BufferedReader(new FileReader(file));
            String text = null;
            
            numberOfSeats = Integer.parseInt(reader.readLine());
            
            while ((text = reader.readLine()) != null) {
                String[] parts = text.split(" ");
                
                GregorianCalendar startingTime = new GregorianCalendar(Integer.parseInt(parts[2]), 
                                                                       Integer.parseInt(parts[1]),
                                                                        Integer.parseInt(parts[0]),
                                                                        Integer.parseInt(parts[3]), 
                                                                        Integer.parseInt(parts[4]));
                
                GregorianCalendar endingTime = new GregorianCalendar(Integer.parseInt(parts[2]), 
                                                                       Integer.parseInt(parts[1]),
                                                                        Integer.parseInt(parts[0]),
                                                                        Integer.parseInt(parts[5]), 
                                                                        Integer.parseInt(parts[6]));
               
               boolean add = timetable.add(new Interval(startingTime, endingTime));
               
            }
        } catch (FileNotFoundException e) {
        } finally {
            try {
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException e) {
            }
        }
    }
    
    @Override
    public Reservation.Interval[] getTimeTable() throws Reservation.UnspecifiedTimeTable {
        Reservation.Interval[] result = new Reservation.Interval[timetable.size()];
        for(int index = 0; index <  timetable.size(); index++)
            result[index] = toResInterval(timetable.get(index));
        return result;
    }
    
    public Reservation.Interval toResInterval(entities.Interval ei){
        GregorianCalendar start_gc = ei.getStartingTime();
        GregorianCalendar stop_gc = ei.getEndingTime();

        Reservation.Date start_date = new Reservation.Date(start_gc.getTime().getDay(), start_gc.getTime().getMonth(), start_gc.getTime().getYear());
        Reservation.Date stop_date = new Reservation.Date(stop_gc.getTime().getDay(), stop_gc.getTime().getMonth(), stop_gc.getTime().getYear());
        Reservation.Moment start_moment = new Reservation.Moment(start_gc.getTime().getHours(), start_gc.getTime().getMinutes());
        Reservation.Moment stop_moment = new Reservation.Moment(stop_gc.getTime().getHours(), stop_gc.getTime().getMinutes());
        
        Reservation.Time start =  new Reservation.Time(start_date, start_moment);
        Reservation.Time stop = new Reservation.Time(stop_date, stop_moment);
        
        Reservation.Interval ri = new Reservation.Interval(start, stop);
        
        return ri;
    }
    
    public entities.Interval toEntitiesInterval(Reservation.Interval ri){
     
        Reservation.Time start =  ri.start;
        Reservation.Time stop = ri.end;

        
        Reservation.Date start_date = start.d;
        Reservation.Date stop_date = stop.d; 
        Reservation.Moment start_moment = start.m;
        Reservation.Moment stop_moment = stop.m;
        
        GregorianCalendar start_gc = new GregorianCalendar(start_date.year, start_date.month, start_date.day, start_moment.hour, start_moment.minute);
        GregorianCalendar stop_gc = new GregorianCalendar(stop_date.year, stop_date.month, stop_date.day, stop_moment.hour, stop_moment.minute);
        
        entities.Interval ei = new entities.Interval(start_gc, stop_gc);
        
        return ei;
    }
    
    

    private Interval getIntervalIntersection(entities.Interval interval1, entities.Interval interval2) {
        entities.Interval result = new entities.Interval();
        if (interval1.getStartingTime().before(interval2.getStartingTime()) ||
            interval1.getStartingTime().equals(interval2.getStartingTime())) {
            if (interval1.getEndingTime().before(interval2.getStartingTime())) {
                return null;
            }
            if (interval1.getEndingTime().equals(interval2.getStartingTime())) {
                result.setStartingTime(interval1.getEndingTime());
                result.setEndingTime(interval2.getStartingTime());
            }
            if (interval1.getEndingTime().after(interval2.getStartingTime()) ||
                interval1.getEndingTime().equals(interval2.getEndingTime())) {
                result.setStartingTime(interval2.getStartingTime());
                result.setEndingTime(interval1.getEndingTime());
            }
            if (interval1.getEndingTime().after(interval2.getEndingTime())) {
                return interval2;
            }
        }
        if (interval1.getStartingTime().after(interval2.getStartingTime())) {
            if (interval2.getEndingTime().before(interval1.getStartingTime())) {
                return null;
            }
            if (interval1.getStartingTime().equals(interval2.getEndingTime())) {
                result.setStartingTime(interval1.getStartingTime());
                result.setEndingTime(interval2.getEndingTime());
            }
            if (interval1.getStartingTime().before(interval2.getEndingTime()) ||
                interval1.getEndingTime().equals(interval2.getEndingTime())) {
                result.setStartingTime(interval1.getStartingTime());
                result.setEndingTime(interval2.getEndingTime());
            }
            if (interval1.getEndingTime().before(interval2.getEndingTime())) {
                return interval1;
            }
        }
        return result;
    }   
    
    @Override
    public int getAvailableSeats(Reservation.Interval interval) throws Reservation.UnspecifiedTimeTable {
        int result = numberOfSeats;
        // TO DO: exercise 4
        ArrayList<Interval> intersectionIntervals = new ArrayList<>();
        Set<GregorianCalendar> sorted_points = new TreeSet<>();
        Set<GregorianCalendar> unique_points = new LinkedHashSet<>();
        ArrayList<GregorianCalendar> points = new ArrayList<>();
        ArrayList<Interval> segments = new ArrayList<>();
        
        // check if the reservation interval is in the available intervals
        Interval interv;
        for(Interval intervalI: timetable){
            interv = getIntervalIntersection(toEntitiesInterval(interval), intervalI);
            if (interv != null){
             intersectionIntervals.add(getIntervalIntersection(toEntitiesInterval(interval), intervalI));
            }
        }
        
        ArrayList<Integer> seats = new ArrayList<>();
        
        if (intersectionIntervals.size() > 0 && reservations.size() > 0) {
            for(ReservationData rd: reservations){
                interv = getIntervalIntersection(toEntitiesInterval(interval), rd.getInterval());
                if (interv != null){
                    sorted_points.add(interv.getStartingTime());
                    sorted_points.add(interv.getEndingTime());
                }     
            }
            
            if (sorted_points.size() > 0) {
                // eliminate duplicates
                for (GregorianCalendar each: sorted_points)
                    unique_points.add(each);

                for (GregorianCalendar each: unique_points)
                    points.add(each);

                for (int i = 0; i < points.size()- 1; i++) {
                    Interval segment = new Interval();
                    segment.setStartingTime(points.get(i));
                    segment.setEndingTime(points.get(i+1)); 
                    segments.add(segment);
                }

                for (Interval each: segments){
                    for(ReservationData reservatinData: reservations){
                        interv = getIntervalIntersection(each, reservatinData.getInterval());
                        if (interv != null){
                            seats.add(numberOfSeats - reservatinData.getNumberOfSeats());
                        }     
                    }  
                }
                
                if (seats.size() > 0)
                    result = getMinValue(seats);
            }
        } 
        else if (intersectionIntervals.isEmpty())
        {
            // the desired reservation is not possible
            result = -1;
        }
        System.out.println(result);
        return result;
    } // getAvailableSeats 
    
        public static int getMinValue(ArrayList<Integer> array){  
          int minValue = array.get(0);  
          for(int i=1;i < array.size();i++){  
            if(array.get(i) < minValue){  
            minValue = array.get(i);  

             }  
         }  
                 return minValue;  
    } 
    
    @Override
    public boolean makeReservation(int customerId, Reservation.Interval interval, int numberOfSeats) throws Reservation.UnspecifiedTimeTable {
        boolean result = false;
        // TO DO: exercise 5
        int seats = getAvailableSeats(interval);
        if (seats == -1)
            result = false;
        else if (seats >= numberOfSeats){
            ReservationData rd = new ReservationData(customerId, toEntitiesInterval(interval), numberOfSeats);
            reservations.add(rd);
            result = true;
        }
        
        return result;
    } // makeReservation     
    
    @Override
    public boolean cancelReservation(int customerId, Reservation.Interval interval) throws Reservation.UnspecifiedTimeTable {
        boolean result = false;
        for(int i = 0; i < reservations.size(); i++){
            ReservationData rd = reservations.get(i);
            if (rd.getClientId() == customerId){
                Interval interv = rd.getInterval();
                
                if (interv.getStartingTime().equals(toEntitiesInterval(interval).getStartingTime()) &&
                        interv.getEndingTime().equals(toEntitiesInterval(interval).getEndingTime())) {
                    result = true;
                    
                    // remove reservation
                    reservations.remove(i);
                }
            }
        }
        return result;
    } // cancelReservation
    
    // TO DO: exercise 9
    @Override
    public Reservation.ReservationData[] getReservation(int clientId) throws Reservation.UnspecifiedTimeTable {
        List<Reservation.ReservationData> result1 = new ArrayList<>();

        for(entities.ReservationData rd: reservations)
            if (rd.getClientId() == clientId){
                Reservation.ReservationData r = new Reservation.ReservationData(toResInterval(rd.getInterval()),rd.getNumberOfSeats());
                result1.add(r);
            }
        
        Reservation.ReservationData[] result2 = new Reservation.ReservationData[result1.size()];
        for(int i = 0; i < result1.size(); i++)
            result2[i] = result1.get(i);
        
        return result2;
    }
}
