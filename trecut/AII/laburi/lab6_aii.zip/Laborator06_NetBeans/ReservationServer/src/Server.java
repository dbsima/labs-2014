import org.omg.CORBA.*;
import org.omg.CosNaming.*;
import org.omg.PortableServer.*;
import Reservation.*;

public class Server {
    
    public static void main (String[] args) {
        
        try {
            
            // creare si initializare ORB
            ORB orb = ORB.init(args,null);
            
            // obtine referinta catre obiectul radacina POA si activeaza POAManager
            POA POARoot = POAHelper.narrow(orb.resolve_initial_references("RootPOA"));
            POARoot.the_POAManager().activate();
            
            // creare instanta servant
            ReservationServiceImplementation reservationServiceImpl = new ReservationServiceImplementation();
            
            // obtine referinta catre obiectul distribuit de la instanta servant
            org.omg.CORBA.Object reservationServiceImplRef = POARoot.servant_to_reference(reservationServiceImpl);
            ReservationService reservationServiceRef = ReservationServiceHelper.narrow(reservationServiceImplRef);
            
            // obtine contextul de nume radacina
            org.omg.CORBA.Object nameServiceRef = orb.resolve_initial_references("NameService");
            NamingContextExt nameContextRef = NamingContextExtHelper.narrow(nameServiceRef);
            
            // legare referinta obiect distribuit la context de nume
            String numeserviciu = "ReservationService";
            NameComponent nameComponent = new NameComponent (numeserviciu,"");
            NameComponent path[] = {nameComponent};
            nameContextRef.rebind (path,reservationServiceRef);
            
            System.out.println ("server pornit cu succes");
            
            // asteptare de invocari de la clienti
            orb.run();
            
        }
        catch (Exception exception) {
            System.out.println("exceptie :"+exception.getMessage());
            exception.printStackTrace();
        }
        
        System.out.println ("server oprit cu succes");
    }
}
