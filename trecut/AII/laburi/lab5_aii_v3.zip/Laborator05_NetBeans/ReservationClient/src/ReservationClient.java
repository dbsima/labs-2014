import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.GregorianCalendar;
import java.util.HashMap;
import reservation.Interval;
import reservation.Reservation;

public class ReservationClient {
 
    public static void main(String[] args) {        
        if (System.getSecurityManager() == null) {
            System.setSecurityManager(new SecurityManager());
        }
		
        try {
            String serviceName = "ReservationService";
            Registry registry = LocateRegistry.getRegistry(args[0]);
            Reservation reservation = (Reservation)registry.lookup(serviceName);
            
            
            // rezervation 1 - 10:00 to 12:00 (10 seats) => should make the reservation (15 available)
            GregorianCalendar startingTime = new GregorianCalendar(2013, 11, 4, 10, 0);    
            GregorianCalendar endingTime = new GregorianCalendar(2013, 11, 4, 12, 0);
            
            Interval interval = new Interval();
            interval.setStartingTime(startingTime);
            interval.setEndingTime(endingTime);
           
         
            boolean worked = reservation.makeReservation(1, interval, 10);
            System.out.println("make 1 " + worked);
            //System.out.println(test);*/
            
            // reservation 2 - 10:00 to 12:00 (10 seats) => should NOT make the reservation (5 available)
            startingTime = new GregorianCalendar(2013, 11, 4, 10, 0);
            endingTime = new GregorianCalendar(2013, 11, 4, 12, 0);
            interval = new Interval();
            interval.setStartingTime(startingTime);
            interval.setEndingTime(endingTime);
            worked = reservation.makeReservation(1, interval, 10);
            System.out.println("make 2 " + worked);
            
            // reservation 3 - 14:00 to 19:00 (10 seats) => should make the reservation (15 available)
            startingTime = new GregorianCalendar(2013, 11, 4, 14, 0);
            endingTime = new GregorianCalendar(2013, 11, 4, 19, 0);
            interval = new Interval();
            interval.setStartingTime(startingTime);
            interval.setEndingTime(endingTime);
            worked = reservation.makeReservation(1, interval, 10);
            System.out.println("make 3 " + worked);
            
            // reservation 4 - 18:00 to 19:00 (10 seats) => should NOT make the reservation (5 available)
            startingTime = new GregorianCalendar(2013, 11, 4, 18, 0);
            endingTime = new GregorianCalendar(2013, 11, 4, 19, 0);
            interval = new Interval();
            interval.setStartingTime(startingTime);
            interval.setEndingTime(endingTime);
            worked = reservation.makeReservation(1, interval, 10);
            System.out.println("make 4 " + worked);
            
            // cancel reservation 1 - 18:00 to 19:00 => does NOT exist
            worked = reservation.cancelReservation(1, interval);
            System.out.println("cancel 1 " + worked);
            
            // get all reservations for user with id = 1 => should return 2
            HashMap<Interval, Integer> reservations_done = reservation.getReservation(1);
            System.out.println("#reservations for 1 is " + reservations_done.size());
            
            // cancel reservation 2 - 14:00 to 19:00 => does exist
            startingTime = new GregorianCalendar(2013, 11, 4, 14, 0);
            endingTime = new GregorianCalendar(2013, 11, 4, 19, 0);
            interval = new Interval();
            interval.setStartingTime(startingTime);
            interval.setEndingTime(endingTime);
            worked = reservation.cancelReservation(1, interval);
            System.out.println("cancel 2 " + worked);
            
            // get all reservations for user with id = 1 => should return 1
            reservations_done = reservation.getReservation(1);
            System.out.println("#reservations for 1 is " + reservations_done.size());
            
            
        } catch (Exception exception) {
            System.out.println("exceptie: "+exception.getMessage());
        }
    }
}
