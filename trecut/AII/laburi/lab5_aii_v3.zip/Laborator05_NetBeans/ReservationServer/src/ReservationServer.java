import entities.ReservationData;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import reservation.Interval;
import reservation.Reservation;

public class ReservationServer implements Reservation {
    
    private int                        numberOfSeats;
    private ArrayList<Interval>        timetable;
    private ArrayList<ReservationData> reservations; 
    
    public ReservationServer() throws IOException {
        super();
        numberOfSeats   = -1;
        timetable       = new ArrayList<>();
        reservations    = new ArrayList<>();
        // TO DO: exercise 3a
        
        List<Integer> list = new ArrayList<>();
        File file = new File("timetable.txt");
        BufferedReader reader = null;

        try {
            reader = new BufferedReader(new FileReader(file));
            String text = null;
            
            numberOfSeats = Integer.parseInt(reader.readLine());
            
            while ((text = reader.readLine()) != null) {
                String[] parts = text.split(" ");
                
                GregorianCalendar startingTime = new GregorianCalendar(Integer.parseInt(parts[2]), 
                                                                       Integer.parseInt(parts[1]),
                                                                        Integer.parseInt(parts[0]),
                                                                        Integer.parseInt(parts[3]), 
                                                                        Integer.parseInt(parts[4]));
                
                GregorianCalendar endingTime = new GregorianCalendar(Integer.parseInt(parts[2]), 
                                                                       Integer.parseInt(parts[1]),
                                                                        Integer.parseInt(parts[0]),
                                                                        Integer.parseInt(parts[5]), 
                                                                        Integer.parseInt(parts[6]));
               
               boolean add = timetable.add(new Interval(startingTime, endingTime));
               
            }
        } catch (FileNotFoundException e) {
        } finally {
            try {
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException e) {
            }
        }
        
        
    }

    private Interval getIntervalIntersection(Interval interval1, Interval interval2) {
        Interval result = new Interval();
        if (interval1.getStartingTime().before(interval2.getStartingTime()) ||
            interval1.getStartingTime().equals(interval2.getStartingTime())) {
            if (interval1.getEndingTime().before(interval2.getStartingTime())) {
                return null;
            }
            if (interval1.getEndingTime().equals(interval2.getStartingTime())) {
                result.setStartingTime(interval1.getEndingTime());
                result.setEndingTime(interval2.getStartingTime());
            }
            if (interval1.getEndingTime().after(interval2.getStartingTime()) ||
                interval1.getEndingTime().equals(interval2.getEndingTime())) {
                result.setStartingTime(interval2.getStartingTime());
                result.setEndingTime(interval1.getEndingTime());
            }
            if (interval1.getEndingTime().after(interval2.getEndingTime())) {
                return interval2;
            }
        }
        if (interval1.getStartingTime().after(interval2.getStartingTime())) {
            if (interval2.getEndingTime().before(interval1.getStartingTime())) {
                return null;
            }
            if (interval1.getStartingTime().equals(interval2.getEndingTime())) {
                result.setStartingTime(interval1.getStartingTime());
                result.setEndingTime(interval2.getEndingTime());
            }
            if (interval1.getStartingTime().before(interval2.getEndingTime()) ||
                interval1.getEndingTime().equals(interval2.getEndingTime())) {
                result.setStartingTime(interval1.getStartingTime());
                result.setEndingTime(interval2.getEndingTime());
            }
            if (interval1.getEndingTime().before(interval2.getEndingTime())) {
                return interval1;
            }
        }
        return result;
    }     
    
    @Override
    public ArrayList<Interval> getTimetable() throws RemoteException {
        ArrayList<Interval> result = new ArrayList<>();
        // TO DO: exercise 3b
        System.out.println(timetable.get(0));
        return timetable;
    }
    
    @Override
    public int getAvailableSeats(Interval interval) throws RemoteException {
        int result = numberOfSeats;
        // TO DO: exercise 4
        ArrayList<Interval> intersectionIntervals = new ArrayList<>();
        Set<GregorianCalendar> sorted_points = new TreeSet<>();
        Set<GregorianCalendar> unique_points = new LinkedHashSet<>();
        ArrayList<GregorianCalendar> points = new ArrayList<>();
        ArrayList<Interval> segments = new ArrayList<>();
        
        // check if the reservation interval is in the available intervals
        Interval interv;
        for(Interval intervalI: timetable){
            interv = getIntervalIntersection(interval, intervalI);
            if (interv != null ){
             intersectionIntervals.add(getIntervalIntersection(interval, intervalI));
            }
        }
        
        ArrayList<Integer> seats = new ArrayList<>();
        
        if (intersectionIntervals.size() > 0 && reservations.size() > 0) {
            for(ReservationData rd: reservations){
                interv = getIntervalIntersection(interval, rd.getInterval());
                if (interv != null){
                    sorted_points.add(interv.getStartingTime());
                    sorted_points.add(interv.getEndingTime());
                }     
            }
            
            if (sorted_points.size() > 0) {
                // eliminate duplicates
                for (GregorianCalendar each: sorted_points)
                    unique_points.add(each);

                for (GregorianCalendar each: unique_points)
                    points.add(each);

                for (int i = 0; i < points.size()- 1; i++) {
                    Interval segment = new Interval();
                    segment.setStartingTime(points.get(i));
                    segment.setEndingTime(points.get(i+1)); 
                    segments.add(segment);
                }

                for (Interval each: segments){
                    for(ReservationData reservatinData: reservations){
                        interv = getIntervalIntersection(each, reservatinData.getInterval());
                        if (interv != null){
                            seats.add(numberOfSeats - reservatinData.getNumberOfSeats());
                        }     
                    }  
                }
                
                if (seats.size() > 0)
                    result = getMinValue(seats);
            }
        }
        else if (intersectionIntervals.isEmpty())
        {
            // the desired reservation is not possible
            result = -1;
        } 
        System.out.println(result);
        return result;
    }  
    
    public static int getMinValue(ArrayList<Integer> array){  
          int minValue = array.get(0);  
          for(int i=1;i < array.size();i++){  
            if(array.get(i) < minValue){  
            minValue = array.get(i);  

             }  
         }  
                 return minValue;  
    } 
    
    @Override
    public boolean makeReservation(int customerId, Interval interval, int numberOfSeats) throws RemoteException {
        boolean result = false;
        // TO DO: exercise 5
        int seats = getAvailableSeats(interval);
        if (seats == -1)
            result = false;
        else if (seats >= numberOfSeats){
            ReservationData rd = new ReservationData(customerId, interval, numberOfSeats);
            reservations.add(rd);
            result = true;
        }
        
        return result;
    }    
    
    @Override
    public boolean cancelReservation(int clientId, Interval interval) throws RemoteException {
        boolean result = false;
        for(int i = 0; i < reservations.size(); i++){
            ReservationData rd = reservations.get(i);
            if (rd.getClientId() == clientId){
                Interval interv = rd.getInterval();
                
                if (interv.getStartingTime().equals(interval.getStartingTime()) &&
                        interv.getEndingTime().equals(interval.getEndingTime())) {
                    result = true;
                    
                    // remove reservation
                    reservations.remove(i);
                }
            }
        }
        return result;
    }
    
    @Override
    public HashMap<Interval, Integer> getReservation(int clientId) throws RemoteException {
        HashMap<Interval, Integer> hm = new HashMap<>();
        for(ReservationData rd: reservations)
            if (rd.getClientId() == clientId)
                hm.put(rd.getInterval(), rd.getNumberOfSeats());
        return hm;
    }

    public static void main (String[] args) {
        
        if (System.getSecurityManager() == null) {
            System.setSecurityManager(new SecurityManager());
        }

        try {
            String serviceName = "ReservationService";
            Reservation service = new ReservationServer();
            Reservation proxy = (Reservation)UnicastRemoteObject.exportObject(service, 0);
            Registry registry = LocateRegistry.getRegistry();
            registry.rebind(serviceName, proxy);
            System.out.println("inregistrare serviciu realizata cu succes");
        } catch (Exception exception) {
            System.out.println("exceptie: "+exception.getMessage());
        }
    }
}
