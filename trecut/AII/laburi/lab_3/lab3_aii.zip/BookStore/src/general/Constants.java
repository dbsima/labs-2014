package general;

public interface Constants {
    final public static String      DATABASE_CONNECTION     = "jdbc:mysql://localhost/librarie";
    final public static String      DATABASE_USERNAME       = "root";
    final public static String      DATABASE_PASSWORD       = "sima";
    final public static String      DATABASE_NAME           = "librarie";
    
    final public static boolean     DEBUG                   = true;
}
