public class BookStore {
    public static void main(String[] args) {
        // TO DO: exercises 2 -> 11
    }
}
