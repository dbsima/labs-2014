import dataaccess.DataBaseConnection;
import entities.Record;
import general.Constants;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Enumeration;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class AdministratorServlet extends HttpServlet {
    final public static long    serialVersionUID = 10011001L;
    
    private ArrayList<String>   dataBaseStructure;
    private String              selectedTable;
    private String              userDisplayName;
 
    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        try {
            DataBaseConnection.openConnection();
            dataBaseStructure   = DataBaseConnection.getTableNames();
            selectedTable       = dataBaseStructure.get(0);
        } catch (SQLException exception) {
            System.out.println("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }
    }

    @Override
    public void destroy() {
        try {
            DataBaseConnection.closeConnection();
        } catch (SQLException exception) {
            System.out.println("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }
    }

    public ArrayList<String> getAttributes(ArrayList<Record> records) {
        ArrayList<String> result = new ArrayList<>();
        for (Record record: records) {
            result.add(record.getAttribute());
        }
        return result;
    }

    public ArrayList<String> getValues(String tableName, ArrayList<Record> records) {
        ArrayList<String> result        = new ArrayList<>();       
        ArrayList<String> attributes    = getAttributes(records);
        for (String attribute:attributes) {
            for (Record record: records) {
                if (attribute.equals(record.getAttribute())) {
                    String value = record.getValue();
                    if (value == null || value.equals("")) {
                        value = Constants.INVALID_VALUE;
                    }
                    result.add(value);
                }
            }
        }
        return result;      
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ArrayList<Record> insertRecords  = new ArrayList<>();
        ArrayList<Record> updateRecords  = new ArrayList<>();
        ArrayList<Record> deleteRecords  = new ArrayList<>();
        ArrayList<Record> genericRecords = new ArrayList<>();
        Enumeration parameters = request.getParameterNames();        
        int operation = Constants.OPERATION_NONE;
        String primaryKeyAttribute = new String();
        try {
            primaryKeyAttribute = DataBaseConnection.getTablePrimaryKey(selectedTable);
        } catch (SQLException exception) {
            System.out.println ("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }
        String primaryKeyValue = new String();
        while(parameters.hasMoreElements()) {
            String parameter = (String)parameters.nextElement();
            if (parameter.equals(Constants.LOGOUT.toLowerCase())) {
                operation = Constants.OPERATION_LOGOUT;
            }
            if (parameter.equals(Constants.ADD_BUTTON_NAME.toLowerCase())) {
                operation = Constants.OPERATION_INSERT;
            }
            else if (parameter.contains(Constants.UPDATE_BUTTON_NAME.toLowerCase()+"1_")) {
                operation = Constants.OPERATION_UPDATE_PHASE1;
                primaryKeyValue = parameter.substring(parameter.indexOf("_")+1);
            }
            else if (parameter.contains(Constants.UPDATE_BUTTON_NAME.toLowerCase()+"2_")) {
                operation = Constants.OPERATION_UPDATE_PHASE2;
                primaryKeyValue = parameter.substring(parameter.indexOf("_")+1);
            }            
            else if (parameter.contains(Constants.DELETE_BUTTON_NAME.toLowerCase())) {
                operation = Constants.OPERATION_DELETE;
                primaryKeyValue = parameter.substring(parameter.indexOf("_")+1);
                deleteRecords.add(new Record(primaryKeyAttribute,primaryKeyValue));
            }
            else {
                genericRecords.add(new Record(parameter,request.getParameter(parameter)));
            }
            if (parameter.equals(Constants.SELECTED_TABLE)) {
                selectedTable = request.getParameter(parameter);
            }
        }
        RequestDispatcher requestDispatcher = null;
        switch (operation) {
            case Constants.OPERATION_INSERT:
                for (Record record:genericRecords) {
                    String attribute = record.getAttribute();
                    String value     = record.getValue();
                    if (attribute.endsWith("_"+Constants.ADD_BUTTON_NAME.toLowerCase())) {
                        insertRecords.add(new Record(attribute.substring(0,attribute.indexOf("_")),value));
                    }
                }
                try {
                    DataBaseConnection.insertValuesIntoTable(selectedTable,getAttributes(insertRecords),getValues(selectedTable,insertRecords),false);
                } catch (Exception exception) {
                    System.out.println ("exceptie: "+exception.getMessage());
                    if (Constants.DEBUG)
                        exception.printStackTrace();
                }
                break;
            case Constants.OPERATION_UPDATE_PHASE2:
                String whereClause = new String();
                for (Record record:genericRecords) {
                    String attribute = record.getAttribute();
                    String value     = record.getValue();
                    if (attribute.endsWith("_"+primaryKeyValue)) {
                        if (attribute.startsWith(primaryKeyAttribute))
                            whereClause += primaryKeyAttribute + "=\'"+ primaryKeyValue + "\'";
                        else
                            updateRecords.add(new Record(attribute.substring(0,attribute.indexOf("_")),value));
                    }
                }    
                try {
                    if (whereClause.isEmpty())
                        whereClause += primaryKeyAttribute + "=\'"+ primaryKeyValue + "\'";
                    DataBaseConnection.updateRecordsIntoTable(selectedTable,getAttributes(updateRecords),getValues(selectedTable,updateRecords),whereClause);
                } catch (Exception exception) {
                    System.out.println ("exceptie: "+exception.getMessage());
                    if (Constants.DEBUG)
                        exception.printStackTrace();
                }
                break;
            case Constants.OPERATION_DELETE:
                try {
                    DataBaseConnection.deleteRecordsFromTable(selectedTable,getAttributes(deleteRecords),getValues(selectedTable,deleteRecords),null);
                } catch (Exception exception) {
                    System.out.println ("exceptie: "+exception.getMessage());
                    if (Constants.DEBUG)
                        exception.printStackTrace();
                }
                break;
            case Constants.OPERATION_LOGOUT:
                // TO DO (exercise 12): add logic for administrator logout
                HttpSession session = request.getSession(true);
                session.invalidate();
                requestDispatcher = getServletContext().getRequestDispatcher("/");
                requestDispatcher.forward(request,response);
                return;
        } 	
            
        HttpSession session = request.getSession(true);
        userDisplayName = session.getAttribute(Constants.IDENTIFIER).toString();           
        if (operation == Constants.OPERATION_UPDATE_PHASE1)
            request.setAttribute("primaryKeyValue",primaryKeyValue);	
        requestDispatcher = getServletContext().getRequestDispatcher("/administrator.jsp");
        if (requestDispatcher != null) {
            request.setAttribute("dataBaseConnection",Constants.DATABASE_CONNECTION);
            request.setAttribute("dataBaseUser",Constants.DATABASE_USER);
            request.setAttribute("dataBasePassword",Constants.DATABASE_PASSWORD);
            request.setAttribute("userDisplayName",userDisplayName);
            request.setAttribute("dataBaseStructure",dataBaseStructure);
            request.setAttribute("currentTableName",selectedTable); 
            try {
                ArrayList<String> attributes = DataBaseConnection.getTableAttributes(selectedTable);
                request.setAttribute("attributes",attributes);
                String primaryKey = DataBaseConnection.getTablePrimaryKey(selectedTable);
                request.setAttribute("primaryKey",primaryKey);
                if (!selectedTable.equals(Constants.USERS_TABLE)) {
                    int primaryKeyMaxValue = DataBaseConnection.getTablePrimaryKeyMaxValue(selectedTable)+1;
                    request.setAttribute("primaryKeyMaxValue",primaryKeyMaxValue);
                }
            } catch (SQLException exception) {
                System.out.println("Exceptie: "+exception.getMessage());
                exception.printStackTrace();
            }
            requestDispatcher.forward(request,response);
        }         
    } 	 
}
