import dataaccess.DataBaseConnection;
import entities.Record;
import general.Constants;
import general.Utilities;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ClientServlet extends HttpServlet {
    final public static long    serialVersionUID = 10021002L;
    
    public String               selectedTable, selectedCollection, selectedDomain;
    public String               userDisplayName;
    
    public ArrayList<Record>	shoppingCart;
 
    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        try {
            DataBaseConnection.openConnection();
            selectedTable       = Constants.BOOKS_TABLE;
            selectedCollection  = Constants.ALL;
            selectedDomain      = Constants.ALL;
        } catch (SQLException exception) {
            System.out.println("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }
    }

    @Override
    public void destroy() {
        try {
            DataBaseConnection.closeConnection();
        } catch (SQLException exception) {
            System.out.println("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {       
        HttpSession session = request.getSession(true);
        userDisplayName = session.getAttribute(Constants.IDENTIFIER).toString();
        shoppingCart = (ArrayList<Record>)session.getAttribute(Utilities.removeSpaces(Constants.SHOPPING_CART.toLowerCase()));
        if (shoppingCart == null) {
            shoppingCart = new ArrayList<>();
        }
        RequestDispatcher requestDispatcher = null;
        String errorMessage = "";
        Enumeration parameters = request.getParameterNames();
        while(parameters.hasMoreElements()) {
            String parameter = (String)parameters.nextElement();                
            if (parameter.equals("selectedCollection")) {
                selectedCollection = request.getParameter(parameter);
            }
            if (parameter.equals("selectedDomain")) {
                selectedDomain = request.getParameter(parameter);
            }               
            // TO DO (exercise 8): create shopping cart
            if (parameter.contains("exemplare") && !request.getParameter(parameter).equals(""))
                {
                    String idCarte = parameter.split("_")[1];
                    String nrExemplare = request.getParameter(parameter);      
                    
                    ArrayList<String> attributes = new ArrayList<>();
                    attributes.add("carti.stoc");
                    try {
                        ArrayList<ArrayList<Object>> tableContent = DataBaseConnection.getTableContent("carti", attributes, "idcarte='"+idCarte+"'",null,null);               
                        errorMessage = tableContent.get(0).get(0).toString() + "   " + nrExemplare;
                        if (Integer.parseInt(tableContent.get(0).get(0).toString()) > Integer.parseInt(nrExemplare))
                        {
                            boolean in = false;
                            for (Record r: shoppingCart)
                                if(r.getAttribute().equals(idCarte)){
                                    in = true;
                                    if (nrExemplare.equals("0"))
                                        shoppingCart.remove(r);
                                    else
                                        r.setValue(nrExemplare);
                                }
                           if (in == false) shoppingCart.add(new Record(idCarte, nrExemplare));
                                    
                        }
                        //else
                        //     errorMessage = "No se puede";
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }
              
            // TO DO (exercise 11): add logic for canceling / completing command
            if (parameter.equals("finalizare") && request.getParameter(parameter).equals("Finalizare"))
            {
                errorMessage = "finalizare";
                
                // get cnp
                String cnp = "";
                ArrayList<String> attributes = new ArrayList<>();
                attributes.add("CNP");
                ArrayList<ArrayList<Object>> tableContent;               
                try {
                    tableContent = DataBaseConnection.getTableContent("utilizatori", attributes, "nume='"+userDisplayName.split(" ")[1]+"' AND prenume='" + userDisplayName.split(" ")[0]+"'",null,null);
                    cnp = tableContent.get(0).get(0).toString();
                } catch (SQLException ex) {
                    Logger.getLogger(ClientServlet.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                // select max(idfactura) from facturi;
                String lastIdFactura = "";
                attributes = new ArrayList<>();
                attributes.add("MAX(idfactura)");
                             
                try {
                    tableContent = DataBaseConnection.getTableContent("facturi", attributes, null, null,null);
                    lastIdFactura = tableContent.get(0).get(0).toString();
                } catch (SQLException ex) {
                    Logger.getLogger(ClientServlet.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                int idFactura = Integer.parseInt(lastIdFactura) + 1;
                
                // insert in "facturi"
                attributes = new ArrayList<>();
                attributes.add("idFactura");
                attributes.add("serienumar");
                attributes.add("data");
                attributes.add("stare");
                attributes.add("CNP");
                     
                ArrayList<String> values = new ArrayList<>();
                values.add(Integer.toString(idFactura));
                values.add(Utilities.generateBillNumber().toString());
                values.add("CURDATE()");
                values.add("emisa");
                values.add(cnp);
                
                try {
                    DataBaseConnection.insertValuesIntoTable("facturi", attributes, values, false);
                } catch (Exception exception) {
                    System.out.println ("exceptie: "+exception.getMessage());
                    if (Constants.DEBUG){
                        exception.printStackTrace();
                        errorMessage =  exception.toString();
                    }
                }
                
                // check if the stock of a book has the number of wanted books
                for (Record r: shoppingCart)
                {
                    String idCarte = r.getAttribute();
                    String nrExemplare = r.getValue();
                    
                    attributes = new ArrayList<>();
                    attributes.add("carti.stoc");
                    try {               
                        tableContent = DataBaseConnection.getTableContent("carti", attributes, "idcarte='"+idCarte+"'",null,null);
                        String stoc = tableContent.get(0).get(0).toString();
                        
                        int difference = Integer.parseInt(stoc) - Integer.parseInt(nrExemplare);
                        
                        if (difference >= 0){
                            // update stock
                            values = new ArrayList<>();
                            values.add(Integer.toString(difference));
                            DataBaseConnection.updateRecordsIntoTable("carti", attributes, values, "idcarte='"+idCarte+"'");
     
                            // insert in "detalii_facturi"
                            attributes = new ArrayList<>();
                            attributes.add("idFactura");
                            attributes.add("idCarte");
                            attributes.add("cantitate");
                            
                            values = new ArrayList<>();
                            values.add(Integer.toString(idFactura));
                            values.add(idCarte);
                            values.add(nrExemplare);
                            
                            try {
                                DataBaseConnection.insertValuesIntoTable("detalii_factura", attributes, values, false);
                            } catch (Exception exception) {
                                System.out.println ("exceptie: "+exception.getMessage());
                                if (Constants.DEBUG){
                                    exception.printStackTrace();
                                    errorMessage =  exception.toString();
                                }
                            }
                            
                        }
                    } catch (SQLException ex) {
                        Logger.getLogger(ClientServlet.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (Exception ex) {
                        Logger.getLogger(ClientServlet.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                // empty shopping cart
                shoppingCart = new ArrayList<>();
            }
            
            if (parameter.equals("stergere") && request.getParameter(parameter).equals("Stergere"))
            {
                errorMessage = "stergere";
                shoppingCart = new ArrayList<>();
            }
            
            // TO DO (exercise 12): add logic for client logout
            if (parameter.equals("deautentificare")) {
                session.invalidate();
                requestDispatcher = getServletContext().getRequestDispatcher("/");
                requestDispatcher.forward(request,response);
                return;
            }
        }
        
        session.setAttribute(Utilities.removeSpaces(Constants.SHOPPING_CART.toLowerCase()), shoppingCart);

        requestDispatcher = getServletContext().getRequestDispatcher("/client.jsp");
        if (requestDispatcher != null) {
            request.setAttribute("dataBaseConnection",Constants.DATABASE_CONNECTION);
            request.setAttribute("dataBaseUser",Constants.DATABASE_USER);
            request.setAttribute("dataBasePassword",Constants.DATABASE_PASSWORD);
            request.setAttribute("userDisplayName",userDisplayName);
            request.setAttribute("errorMessage",errorMessage);
            request.setAttribute("currentTableName",selectedTable); 
            if (selectedCollection == null || selectedCollection.isEmpty())
                selectedCollection = Constants.ALL;
            request.setAttribute("currentCollection",selectedCollection);
            if (selectedDomain == null || selectedDomain.isEmpty())
                selectedDomain = Constants.ALL;
            request.setAttribute("currentDomain",selectedDomain); 
            request.setAttribute("shoppingCart",shoppingCart); 
            try {
                ArrayList<String> attributes = DataBaseConnection.getTableAttributes(selectedTable);
                request.setAttribute("attributes",attributes);
                String collectionPrimaryKey = DataBaseConnection.getTablePrimaryKey(Constants.COLLECTIONS_TABLE);
                String primaryKey = DataBaseConnection.getTablePrimaryKey(selectedTable);
                request.setAttribute("primaryKey",primaryKey);                
                request.setAttribute("collectionPrimaryKey",collectionPrimaryKey);
                String domainPrimaryKey = DataBaseConnection.getTablePrimaryKey(Constants.DOMAINS_TABLE);
                request.setAttribute("domainPrimaryKey",domainPrimaryKey);               
            } catch (SQLException exception) {
                System.out.println("Exceptie: "+exception.getMessage());
                exception.printStackTrace();
            }            
            requestDispatcher.forward(request,response);
        }
    }  	 
}
