SELECT concat (autor.prenume, ' ', autor.nume) as 'Autor', group_concat(carte.titlu) as 'Carti', count(carte.titlu) as 'Vol.', count(DISTINCT autor_carte.id_carte) as 'Vol. unic' 
FROM carte, autor, autor_carte WHERE carte.id_carte = autor_carte.id_carte AND autor.id_autor = autor_carte.id_autor 
GROUP BY autor.id_autor;
