UPDATE carte
SET pret = pret + (pret/5)
WHERE an < '2010';

SELECT titlu, an, pret FROM carte ORDER BY an ASC, pret DESC;

