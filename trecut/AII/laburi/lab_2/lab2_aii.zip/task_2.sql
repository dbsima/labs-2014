DROP DATABASE IF EXISTS librarie;
CREATE database librarie;

USE librarie;

CREATE TABLE IF NOT EXISTS domeniu (
				id_domeniu INT PRIMARY KEY NOT NULL, 
				nume VARCHAR(20) NOT NULL, 
				descriere VARCHAR(20) NOT NULL
				);

CREATE TABLE IF NOT EXISTS colectie (
				id_colectie INT PRIMARY KEY NOT NULL, 
				nume VARCHAR(20) NOT NULL,
				descriere VARCHAR(20) NOT NULL
				);

CREATE TABLE IF NOT EXISTS editura (
				id_editura INT PRIMARY KEY NOT NULL, 
				denumire VARCHAR(20) NOT NULL,
				cif VARCHAR(20) NOT NULL,
				descriere VARCHAR(20) NOT NULL,
				localitate VARCHAR(20) NOT NULL,
				regiune VARCHAR(20) NOT NULL,
				tara VARCHAR(20) NOT NULL
				);

CREATE TABLE IF NOT EXISTS client (
				id_client INT PRIMARY KEY NOT NULL, 
				nume VARCHAR(20) NOT NULL,
				prenume VARCHAR(20) NOT NULL,
				adresa VARCHAR(20) NOT NULL,
				nr_tel VARCHAR(20),
				email VARCHAR(20) NOT NULL,
				tip VARCHAR(20) NOT NULL,
				rol VARCHAR(20) NOT NULL
				);

ALTER TABLE client ADD CONSTRAINT email_check CHECK (email LIKE '%@%.%');

CREATE TABLE IF NOT EXISTS carte (
				id_carte INT PRIMARY KEY NOT NULL, 
				titlu VARCHAR(20) NOT NULL,
				an YEAR NOT NULL,
				editie INT UNSIGNED NOT NULL,
				descriere VARCHAR(20),
				stoc INT UNSIGNED NOT NULL,
				pret FLOAT UNSIGNED NOT NULL,
				id_editura INT NOT NULL,
				id_domeniu INT NOT NULL,
				id_colectie INT NOT NULL,
				FOREIGN KEY (id_editura) REFERENCES editura (id_editura) ON UPDATE CASCADE ON DELETE CASCADE,
				FOREIGN KEY (id_domeniu) REFERENCES domeniu (id_domeniu) ON UPDATE CASCADE ON DELETE CASCADE,
				FOREIGN KEY (id_colectie) REFERENCES colectie (id_colectie) ON UPDATE CASCADE ON DELETE CASCADE
				);

CREATE TABLE IF NOT EXISTS autor (
				id_autor INT PRIMARY KEY NOT NULL, 
				nume VARCHAR(20) NOT NULL,
				prenume VARCHAR(20) NOT NULL,
				descriere VARCHAR(45) NOT NULL
				);

CREATE TABLE IF NOT EXISTS autor_carte (
				id_asociere INT PRIMARY KEY NOT NULL, 
				id_carte INT not NULL,
				id_autor INT not NULL,
				FOREIGN KEY (id_carte) REFERENCES carte (id_carte) ON UPDATE CASCADE ON DELETE CASCADE,
				FOREIGN KEY (id_autor) REFERENCES autor (id_autor) ON UPDATE CASCADE ON DELETE CASCADE
				);

CREATE TABLE IF NOT EXISTS factura_c(
				id_factura_c INT PRIMARY KEY NOT NULL,
				serie VARCHAR(20) not NULL,				
				numar INT not NULL,
				stare VARCHAR(20) not NULL,
				data DATE not NULL,
				id_client INT not NULL, 
				FOREIGN KEY (id_client) REFERENCES client (id_client) ON UPDATE CASCADE ON DELETE CASCADE
				);

CREATE TABLE IF NOT EXISTS comanda_c(
				id_comanda_c INT PRIMARY KEY NOT NULL,
				cantitate INT not NULL,				
				id_carte INT not NULL,
				id_factura_c INT not NULL, 
				FOREIGN KEY (id_carte) REFERENCES carte (id_carte) ON UPDATE CASCADE ON DELETE CASCADE,
				FOREIGN KEY (id_factura_c) REFERENCES factura_c (id_factura_c) ON UPDATE CASCADE ON DELETE CASCADE
				);

CREATE TABLE IF NOT EXISTS factura_e(
				id_factura_e INT PRIMARY KEY NOT NULL,
				serie VARCHAR(20) not NULL,				
				numar INT not NULL,
				stare VARCHAR(20) not NULL,
				data DATE not NULL,
				id_editura INT not NULL, 
				FOREIGN KEY (id_editura) REFERENCES editura (id_editura) ON UPDATE CASCADE ON DELETE CASCADE
				);

CREATE TABLE IF NOT EXISTS comanda_e(
				id_comanda_e INT PRIMARY KEY NOT NULL,
				cantitate INT not NULL,				
				id_carte INT not NULL,
				id_factura_e INT not NULL, 
				FOREIGN KEY (id_carte) REFERENCES carte (id_carte) ON UPDATE CASCADE ON DELETE CASCADE,
				FOREIGN KEY (id_factura_e) REFERENCES factura_e (id_factura_e) ON UPDATE CASCADE ON DELETE CASCADE
				);




