DROP PROCEDURE IF EXISTS suma_facturi;

DELIMITER //
CREATE PROCEDURE suma_facturi(IN id INT)
BEGIN
SELECT factura_c.serie, factura_c.numar, comanda_c.id_carte as 'Id', factura_c.data, val_comanda_c(comanda_c.id_comanda_c) as 'Total' 
FROM factura_c, comanda_c
WHERE factura_c.id_client = id AND factura_c.id_factura_c = comanda_c.id_factura_c 
ORDER BY factura_c.data;

SELECT concat(client.prenume, ' ', client.nume) as 'Client', sum(val_comanda_c(comanda_c.id_comanda_c)) as 'Suma facturi' 
FROM client, factura_c, comanda_c 
WHERE factura_c.id_client = id AND factura_c.id_factura_c = comanda_c.id_factura_c AND client.id_client = id;
END//
delimiter ;

CALL suma_facturi(2);
