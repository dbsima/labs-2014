SELECT carte.titlu, SUM(valoare_factura(factura.id)) AS 'total'
  FROM factura_c, factura, carte 
  WHERE factura.id=factura_c.id_factura 
  AND factura_c.id_carte=carte.id 
  GROUP BY carte.titlu 
  ORDER BY carte.titlu DESC;
 
