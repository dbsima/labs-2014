INSERT INTO domeniu (id_domeniu, nume, descriere) VALUES 
(1 , 'SF', 'Science-Fiction'), 							 
(2 , 'Horror', 'Groaza'),							 
(3 , 'Politica', 'Despre mizarii');

INSERT INTO colectie (id_colectie, nume, descriere) VALUES
(1 , 'Bestseller', 'Cele mai vandute'), 
(2 , 'AP', 'Acord parental'),
(3 , '+18', 'Interzis minorilor');

INSERT INTO editura (id_editura, denumire, cif, descriere, localitate, regiune, tara) VALUES 
(1 , 'Paralela45', '1000', 'Editura Paralela 45', 'Pitesti', 'Arges', 'Romania'),
(2 , 'Litera', '1001', 'Editura Litera', 'Bucuresti', 'Bucuresti', 'Romania'),
(3 , 'Humanitas', '1002', 'Editura Humanitas', 'Bucuresti', 'Bucuresti', 'Romania');

INSERT INTO client (id_client, nume, prenume, nr_tel, email, tip, rol) VALUES 
(1, 'Sima', 'Dragos', '0748749281', 'simadragos@gmail.com', 'administrator', 'super-administrator'),
(2, 'Pitac', 'Alexandru', '0748749282', 'pitacalex@gmail.com', 'client', 'client-inregistrat'),
(3, 'Petcu', 'Ovidiu', '0748749283', 'petcuovidiu@gmail.com', 'administrator', 'administrator-simplu'),
(4, 'Gliga', 'Andrei', '0748749284', 'gligaandrei@gmail.com', 'client', 'client-verificat');

INSERT INTO carte (id_carte, titlu, an, editie, descriere, stoc, pret, id_editura, id_domeniu, id_colectie) VALUES 
(1, 'Morometii', '1992', 4, 'descriere Morometii', 10, 22.4, 1, 1, 1),
(2, 'La_Tiganci', '1992', 2, 'descriere La Tiganci', 12, 33.4, 1, 2, 2),
(3, 'Piciul', '2011', 4, 'descriere Piciul', 1, 23.4, 2, 1, 1),
(4, 'Plumb', '2001', 1, 'descriere Plumb', 3, 100, 3, 1, 3),
(5, 'O scrisoare pierduta', '2001', 4, 'un pamflet', 3, 20, 3, 1, 3),
(6, 'Dl. Goe', '2001', 3, 'descriere Plumb', 3, 30, 3, 1, 3);

INSERT INTO autor (id_autor, nume, prenume, descriere) VALUES 
(1, 'Preda', 'Marin', 'descriere Marin Preda'),
(2, 'Creanga', 'Ion', 'descriere Ion Creanga'),
(3, 'Bacovia', 'George', 'descriere George Bacovia'),
(4, 'Eminescu', 'Mihai', 'descriere Mihai Eminescu'),
(5, 'Caragiale', 'I.L.', 'descriere I.L. Caragiale');


INSERT INTO autor_carte (id_asociere, id_carte, id_autor) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 2, 1),
(4, 2, 3),
(5, 3, 4),
(6, 4, 3),
(7, 5, 5),
(8, 6, 5);

INSERT INTO factura_c (id_factura_c, serie, numar, stare, data, id_client) VALUES
(1, 'TC', '136610', 'proforma', '2010-11-10', 1),
(2, 'TC', '136609', 'finalizata', '2009-11-10', 2),
(3, 'TC', '136608', 'proforma', '2011-11-10', 2),
(4, 'TC', '136607', 'finalizata', '2009-11-19', 3),
(5, 'TC', '136606', 'finalizata', '2009-11-12', 3);

INSERT INTO comanda_c (id_comanda_c, cantitate, id_carte, id_factura_c) VALUES
(1, 2, 1, 1),
(2, 1, 2, 2),
(3, 1, 3, 3),
(4, 1, 3, 4),
(5, 1, 3, 5);

INSERT INTO factura_e (id_factura_e, serie, numar, stare, data, id_editura) VALUES
(1, 'TC', '136610', 'proforma', '2010-11-10', 1),
(2, 'TC', '136609', 'finalizata', '2009-11-10', 3),
(3, 'TC', '136608', 'proforma', '2011-11-10', 2),
(4, 'TC', '136607', 'finalizata', '2009-11-19', 2),
(5, 'TC', '136606', 'finalizata', '2009-11-12', 3);

INSERT INTO comanda_e (id_comanda_e, cantitate, id_carte, id_factura_e) VALUES
(1, 2, 1, 1),
(2, 1, 2, 2),
(3, 1, 3, 3),
(4, 1, 3, 4),
(5, 1, 3, 5);


SELECT carte.id_carte, carte.titlu, group_concat(concat (autor.prenume, ' ', autor.nume)) FROM carte, autor, autor_carte WHERE carte.id_carte = autor_carte.id_carte AND autor.id_autor = autor_carte.id_autor GROUP BY carte.id_carte;






 

