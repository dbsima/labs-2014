DROP FUNCTION IF EXISTS val_comanda_e;
DROP FUNCTION IF EXISTS val_comanda_c;

DELIMITER //
CREATE FUNCTION val_comanda_e(id INT)
 	RETURNS INT
BEGIN
DECLARE total INT;
SELECT carte.pret * comanda_e.cantitate INTO total FROM carte, comanda_e WHERE comanda_e.id_carte = carte.id_carte AND id_comanda_e = id;
RETURN total;
END; // 

DELIMITER //
CREATE FUNCTION val_comanda_c(id INT)
 	RETURNS INT
BEGIN
DECLARE total INT;
SELECT carte.pret * comanda_c.cantitate INTO total FROM carte, comanda_c WHERE comanda_c.id_carte = carte.id_carte AND id_comanda_c = id;
RETURN total;
END; //

SELECT editura.denumire as 'Editura', sum(val_comanda_e(comanda_e.id_comanda_e)) as 'Volum'
FROM comanda_e, editura, factura_e
WHERE editura.id_editura = factura_e.id_editura AND factura_e.id_factura_e = comanda_e.id_factura_e
GROUP BY factura_e.id_editura
ORDER BY Volum DESC LIMIT 3;

SELECT concat(client.prenume, ' ', client.nume) as 'Client', sum(val_comanda_c(comanda_c.id_comanda_c)) as 'Volum'  
FROM comanda_c, client, factura_c
WHERE client.id_client = factura_c.id_client AND factura_c.id_factura_c = comanda_c.id_factura_c
GROUP BY factura_c.id_client 
ORDER BY Volum DESC LIMIT 3;

