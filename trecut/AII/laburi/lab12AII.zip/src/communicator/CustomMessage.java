package communicator;

import java.io.Serializable;
import java.util.Date;
import javafx.scene.chart.PieChart.Data;

public class CustomMessage implements Serializable {

    private static final long serialVersionUID = 1024L;

    private String senderUserName;
    private String messageContent;

    public CustomMessage(String senderUserName, String messageContent) {
        Date d = new Date();
        this.senderUserName = d.toString() + ": " + senderUserName;
        this.messageContent = messageContent;
    }

    public String getSenderUserName() {
        return senderUserName;
    }

    public void setSenderUserName(String senderUserName) {
        this.senderUserName = senderUserName;
    }

    public String getMessageContent() {
        return messageContent;
    }

    public void setMessageContent(String messageContent) {
        this.messageContent = messageContent;
    }

}
