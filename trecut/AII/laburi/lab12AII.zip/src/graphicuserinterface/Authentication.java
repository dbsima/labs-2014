package graphicuserinterface;

import general.Constants;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.FadeTransition;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import javafx.util.Duration;
import javax.jms.JMSException;

public class Authentication extends Application {

    private Stage applicationStage;
    private Scene applicationScene;

    @FXML
    private TextField userNameTextField;
    @FXML
    private Button okButton, cancelButton;
    @FXML
    private Label errorLabel;

    @Override
    public void start(Stage mainStage) {
        applicationStage = mainStage;
        try {
            applicationScene = new Scene((Parent) FXMLLoader.load(getClass().getResource(Constants.AUTHENTICATION_FXML_FILE)));
        } catch (Exception exception) {
            System.out.println("exceptie: " + exception.getMessage());
            if (Constants.DEBUG) {
                exception.printStackTrace();
            }
        }
        applicationStage.setTitle(Constants.APPLICATION_TITLE);
        applicationStage.getIcons().add(new Image(Authentication.class.getResourceAsStream(Constants.ICON_FILE_NAME)));
        okButton = (Button) applicationScene.lookup("#okButton");
        okButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                userNameTextField = (TextField) applicationScene.lookup("#userNameTextField");
                String userName = userNameTextField.getText();
                if (userName.isEmpty()) {
                    errorLabel = (Label) applicationScene.lookup("#errorLabel");
                    errorLabel.setText(Constants.NO_USERNAME_ERROR);
                    FadeTransition fadeTransition = new FadeTransition(Duration.millis(Constants.MESSAGE_ERROR_TIMEOUT), errorLabel);
                    fadeTransition.setFromValue(1.0);
                    fadeTransition.setToValue(0.0);
                    fadeTransition.setAutoReverse(false);
                    fadeTransition.play();
                } else {
                    applicationStage.hide();
                    try {
                        new ContactsList(userName).start();
                    } catch (JMSException ex) {
                        Logger.getLogger(Authentication.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (IOException ex) {
                        Logger.getLogger(Authentication.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        });
        cancelButton = (Button) applicationScene.lookup("#cancelButton");
        cancelButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Platform.exit();
            }
        });
        applicationStage.setScene(applicationScene);
        applicationStage.show();
    }

    public void show() {
        applicationStage.show();
    }

    public void hide() {
        applicationStage.hide();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
