SELECT * FROM pontaje WHERE data IN (SELECT data FROM `calendar` WHERE data BETWEEN '2013-01-10' AND '2013-11-11')
UNION
SELECT * FROM concedii WHERE start IN (SELECT data FROM `calendar` WHERE data BETWEEN '2013-01-10' AND '2013-11-11')



SELECT * FROM `calendar`
JOIN pontaje
ON calendar.data = pontaje.data
WHERE calendar.data BETWEEN '2013-01-10' AND '2013-11-11'

UNION
SELECT * FROM `calendar`
JOIN concedii
ON calendar.data BETWEEN concedii.start AND concedii.sfarsit
WHERE calendar.data BETWEEN '2013-01-10' AND '2013-11-11'


SELECT * FROM (SELECT pontaje.id_ang, calendar.data, pontaje.ora_sosire, pontaje.ora_plecare FROM `calendar`
JOIN pontaje
ON calendar.data = pontaje.data
WHERE calendar.data BETWEEN '2013-01-10' AND '2013-11-21'

UNION
SELECT concedii.id_ang, calendar.data, concedii.tip, concedii.tip FROM `calendar`
JOIN concedii
ON calendar.data BETWEEN concedii.start AND concedii.sfarsit
WHERE calendar.data BETWEEN '2013-01-10' AND '2013-11-21') a
WHERE id_ang = 2
ORDER BY data


####
# Fara buguri sper :D

SELECT pontaje.id_ang, calendar.data, pontaje.ora_sosire, pontaje.ora_plecare, pontaje.ora_sosire AS 'intarziere', pontaje.ora_plecare AS 'extra', HOUR(pontaje.ora_plecare - pontaje.ora_sosire) AS 'suplimentare'
FROM `calendar`
JOIN pontaje
ON calendar.data = pontaje.data

UNION
SELECT concedii.id_ang, calendar.data, CONCAT('din ', concedii.start), CONCAT('pana ', concedii.sfarsit), concedii.tip, concedii.tip, concedii.tip FROM `calendar`
JOIN concedii
ON calendar.data BETWEEN concedii.start AND concedii.sfarsit


### 
#Si mai bun ;)
SELECT * FROM (SELECT pontaje.id_ang, calendar.data, pontaje.ora_sosire, pontaje.ora_plecare, pontaje.ora_sosire AS 'intarziere', pontaje.ora_plecare AS 'extra', HOUR(pontaje.ora_plecare - pontaje.ora_sosire) AS 'suplimentare'
FROM `calendar`
JOIN pontaje
ON calendar.data = pontaje.data

UNION
SELECT concedii.id_ang, calendar.data, concedii.start, concedii.sfarsit, concedii.tip, concedii.tip, concedii.tip FROM `calendar`
JOIN concedii
ON calendar.data BETWEEN concedii.start AND concedii.sfarsit) a
WHERE id_ang = 2 AND data BETWEEN '2013-01-10' AND '2013-11-21'
ORDER BY data



############# 
## Cred ca asta o sa il folosesc


SELECT * FROM (SELECT pontaje.id_ang, calendar.data, pontaje.ora_sosire, pontaje.ora_plecare, pontaje.ora_sosire AS 'intarziere', pontaje.ora_plecare AS 'extra', HOUR(pontaje.ora_plecare - pontaje.ora_sosire) AS 'suplimentare'
FROM `calendar`
JOIN pontaje
ON calendar.data = pontaje.data
WHERE calendar.data BETWEEN '2013-01-10' AND '2013-11-21'

UNION
SELECT concedii.id_ang, calendar.data, concedii.start, concedii.sfarsit, concedii.tip, concedii.tip, concedii.tip FROM `calendar`
JOIN concedii
ON calendar.data BETWEEN concedii.start AND concedii.sfarsit
WHERE calendar.data BETWEEN '2013-01-10' AND '2013-11-21') a
WHERE id_ang = 2
ORDER BY data