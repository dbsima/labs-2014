package graphicuserinterface;

import general.Constants;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class AboutGUI implements EventHandler {

    private Stage                   applicationStage;
    private Scene                   applicationScene;    
    private Label                   label;
    private Button                  button;
    
    public AboutGUI() {       
    }
    
    public void start() {
        // TO DO: Exercise 5
    }
    
    @Override
    public void handle(Event event) {           
        // TO DO: Exercise 5     
    }     
}
