package graphicuserinterface;

import dataaccess.DataBaseConnection;
import entities.Activitate;
import entities.Angajat;
import entities.CheltuialaAngajat;
import entities.CheltuialaDepartament;
import entities.Componenta;
import entities.Concediu;
import entities.Constanta;
import entities.Contract;
import entities.Defect;
import entities.Departament;
import entities.Echipa;
import entities.Entity;
import entities.Salariu;
import entities.Intrare;
import entities.Proiect;
import entities.VenitProiect;
import entities.Versiune;
import entities.Zi;
import general.Constants;
import general.ReferrencedTable;
import general.Utilities;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.FadeTransition;
import javafx.animation.ScaleTransition;
import javafx.animation.ParallelTransition;
import javafx.animation.Timeline;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Control;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;

public class DataBaseManagementGUI implements EventHandler {
    private Stage                   applicationStage;
    private Scene                   applicationScene;
    private MenuBar                 applicationMenu;    
    public  VBox                    container;    
    private double                  sceneWidth, sceneHeight;
    
    private String                  tableName, menuName="";
    
    private TableView<Entity>       tableContent;
    private ArrayList<Label>        attributeLabels;
    private ArrayList<Control>      attributeControls; 
    private String role;
    private String[][]              menu_structure;
    
    public DataBaseManagementGUI(String role) {
        container = new VBox();
        container.setSpacing(Constants.DEFAULT_SPACING);
        container.setPadding(new Insets(Constants.DEFAULT_SPACING, Constants.DEFAULT_SPACING, Constants.DEFAULT_SPACING, Constants.DEFAULT_SPACING));        
       
        this.role = role;
        
        if (role.contains("admin") || role.contains("superadmin"))
            menu_structure = Constants.ADMIN_MENU_STRUCTURE;
        else if (role.contains("MP"))
            menu_structure = Constants.MP_MENU_STRUCTURE;
        else if (role.contains("D"))
            menu_structure = Constants.D_MENU_STRUCTURE;
        else if (role.contains("C"))
            menu_structure = Constants.C_MENU_STRUCTURE;
        else if (role.contains("RU"))
            menu_structure = Constants.RU_MENU_STRUCTURE;
    }
    
    
    public void start() {
        applicationStage = new Stage();
        applicationStage.setTitle(Constants.APPLICATION_NAME);
        applicationStage.getIcons().add(new Image(Constants.ICON_FILE_NAME));
        Dimension screenDimension = Toolkit.getDefaultToolkit().getScreenSize();
        sceneWidth  = Constants.SCENE_WIDTH_SCALE*screenDimension.width;
        sceneHeight = Constants.SCENE_HEITH_SCALE*screenDimension.height;
        applicationScene = new Scene(new VBox(), sceneWidth, sceneHeight);      
        applicationScene.setFill(Color.AZURE);        
        applicationMenu = new MenuBar();  
        for (int currentIndex1 = 0; currentIndex1 < menu_structure.length; currentIndex1++) {
            Menu menu = new Menu(menu_structure[currentIndex1][0]);
            for (int currentIndex2 = 1; currentIndex2 < menu_structure[currentIndex1].length; currentIndex2++) {
                MenuItem menuItem = new MenuItem(menu_structure[currentIndex1][currentIndex2]);
                menuItem.addEventHandler(EventType.ROOT, (EventHandler<Event>)this);
                menu.getItems().add(menuItem);
            }
            applicationMenu.getMenus().add(menu);   
        } 
        ((VBox)applicationScene.getRoot()).getChildren().addAll(applicationMenu);
        applicationStage.setScene(applicationScene);
        applicationStage.show();        
    }
    
    private Entity getCurrentEntity(ArrayList<Object> values) {
        switch(tableName) {
            case "activitati":
                return new Activitate(values, role);
            case "angajati":
                return new Angajat(values);
            case "contracte":
                return new Contract(values);
            case "departamente":
                return new Departament(values);
            case "proiecte":
                return new Proiect(values);
            case "versiuni":
                return new Versiune(values);
            case "echipe":
                return new Echipa(values);
            case "componente":
                return new Componenta(values);
            case "defecte":
                return new Defect(values);
            case "concedii":
                return new Concediu(values);
            case "constante":
                return new Constanta(values);
            case "zile":
                return new Zi(values, role);
            case "intrari":
                return new Intrare(values);
            case "salarii":
                return new Salariu(values, role);
            case "venitproiecte":
                return new VenitProiect(values);
            case "cheltuieliangajat":
                return new CheltuialaAngajat(values);
            case "cheltuielidepartament":
                return new CheltuialaDepartament(values);
        }
        return null;        
    }

    public void populateTableView(String whereClause) {
        try {
            String orderByClause = null;
            String groupByClause = null;
            
            ArrayList<String> attr = new ArrayList<>();
            
            if (role.equals("admin") && tableName.equals("angajati"))
                whereClause = "functie != 'admin' AND functie != 'superadmin'";
            else if (role.equals("superadmin") && tableName.equals("angajati"))
                whereClause = "functie != 'superadmin'";
            else if (role.contains("C_"))
            {
                switch (tableName) {
                    case "angajati":
                    case "contracte":
                    case "concedii":
                    case "activitati":
                    case "zile":
                    {
                        String idAngajat = role.split("_")[2];
                        whereClause = "idangajat = '" + idAngajat + "'";
                        break;  
                    }
                }
            }   
            else if (role.contains("RU_"))
            {
                switch (tableName) {
                    case "salarii":
                    {
                        String idAngajat = role.split("_")[2];
                        whereClause = "idangajat = '" + idAngajat + "'";
                        break;  
                    }
                }
            }   
            else if (role.contains("MP_"))
            {
                System.out.println("mp");
                // the employee is the chief of a the "programare" /
                // "asigurarea calitatii" department
                switch (tableName) {
                    case "echipe":
                    // the employee can see only the teams from his/her deparment
                    {
                        String idDept = role.split("_")[1];
                        whereClause = "echipe.iddepartament = '" + idDept + "'";
                        break;
                    }
                    case "componente":
                    // the employee can only see informations about the teams
                    // from his/her deparment
                    {
                        String idDept = role.split("_")[1];
                                       
                        // get the id of the teams from his/her department
                        ArrayList<String> attributes = new ArrayList<>();
                        attributes.add("idechipa");
                        whereClause = "echipe.iddepartament='"+idDept+"'";
                        ArrayList<ArrayList<Object>> values = DataBaseConnection.getTableContent("echipe", attributes, whereClause, null, null);
                        
                        whereClause = "componente.idechipa IN (";
                        int i, j;
                        for (i = 0; i < values.size(); i++)
                            for(j = 0; j < values.get(i).size(); j++)
                                whereClause += "'" + values.get(i).get(j).toString() + "', ";
                        whereClause = whereClause.substring(0, whereClause.length() - 2) + ")";
                        System.out.println(whereClause);
                        break;
                    }
                    case "proiecte":
                    case "versiuni":
                    {
                        String idDept = role.split("_")[1];
                                                
                        // get the id of the projects of his/her department
                        ArrayList<String> attributes = new ArrayList<>();
                        attributes.add("idproiect");
                        whereClause = "echipe.iddepartament='"+idDept+"'";
                        ArrayList<ArrayList<Object>> values = DataBaseConnection.getTableContent("echipe", attributes, whereClause, null, null);
                        
                        whereClause = "idproiect IN (";
                        int i, j;
                        for (i = 0; i < values.size(); i++)
                            for(j = 0; j < values.get(i).size(); j++)
                                whereClause += "'" + values.get(i).get(j).toString() + "', ";
                        whereClause = whereClause.substring(0, whereClause.length() - 2) + ")";
                        System.out.println(whereClause);
                        break;
                    }
                    case "defecte":
                    {    
                        orderByClause = "defecte.severitate DESC, defecte.idversiune ASC, defecte.datamodif DESC";
                        break;
                    }
                    case "angajati":
                    case "contracte":
                    case "concedii":
                    case "activitati":
                    case "zile":
                    case "salarii":
                    {
                        String idAngajat = role.split("_")[2];
                        whereClause = "idangajat = '" + idAngajat + "'";
                        break;  
                    }
                }
            }
            
            else if (role.contains("D_"))
            {
                // the employee is part of a development department (programare 
                // || "asigurarea calitatii")
                switch (tableName) {
                    case "componente":
                    // an employee that is the "programare" or "asigurarea
                    // calitatii" department and is not the chief of it can 
                    // only see informations about him/her
                    {
                        String idAngajat = role.split("_")[2];
                        whereClause = "componente.idmembru='"+idAngajat+"'";
                        break;
                    }
                    case "proiecte":
                    case "versiuni":
                    {
                        String idAngajat = role.split("_")[2];
                        
                        // get the idEchipa from componente for the current user
                        ArrayList<String> attributes = new ArrayList<>();
                        attributes.add("idechipa");
                        whereClause = "componente.idmembru='"+idAngajat+"'";
                        ArrayList<ArrayList<Object>> values = DataBaseConnection.getTableContent("componente", attributes, whereClause, null, null);
                        String idEchipa = values.get(0).get(0).toString();
                    
                        // get the idProiect from echipe for the idEchipa of the current user
                        attributes = new ArrayList<>();
                        attributes.add("idproiect");
                        whereClause = "echipe.idechipa='"+idEchipa+"'";
                        values = DataBaseConnection.getTableContent("echipe", attributes, whereClause, null, null);
                        
                        String idProiect = values.get(0).get(0).toString();
                        whereClause = "idproiect='"+idProiect+"'";
                        break;
                    }
                    case "defecte":
                    {
                        orderByClause = "defecte.severitate DESC, defecte.idversiune ASC, defecte.datamodif DESC";
                        break;
                    }
                    case "angajati":
                    case "contracte":
                    case "concedii":
                    case "activitati":
                    case "zile":
                    case "salarii":
                    {
                        String idAngajat = role.split("_")[2];
                        whereClause = "idangajat = '" + idAngajat + "'";
                        break;  
                    }
                }
            }

            ArrayList<ArrayList<Object>> values = DataBaseConnection.getTableContent(tableName, attr, (whereClause==null || whereClause.isEmpty())?null:whereClause, orderByClause, groupByClause);
            ObservableList<Entity> data = FXCollections.observableArrayList();
            
            for (int i = 0; i < values.size(); i++) {
                System.out.println("v1 " + values.get(i));
                data.add(getCurrentEntity(values.get(i)));
            }
            tableContent.setItems(data);
        } catch (Exception exception) {
            System.out.println ("exceptie: " + tableName + exception.getMessage());
            exception.printStackTrace();
        }
    }
    
    private void setContent() throws SQLException {
        if (tableName == null || tableName.equals("")) {
            return;
        }
        tableContent        = new TableView<>();
        attributeLabels     = new ArrayList<>();
        attributeControls   = new ArrayList<>();    
        container.getChildren().clear();
        ArrayList<String> attributes = new ArrayList<>();
        for (String entry:DataBaseConnection.getTableNames()) {
            if (tableName.toLowerCase().replaceAll(" ","").equals(entry.toLowerCase().replaceAll("_",""))) {    
                tableName = entry;
                attributes = DataBaseConnection.getTableAttributes(tableName);
                System.out.println("a1 " + attributes);
                break;
            }
        }
        
        final ArrayList<ReferrencedTable> referrencedTables = DataBaseConnection.getReferrencedTables(tableName);
        tableContent.setEditable(true);
        for (int currentIndex = 0; currentIndex < attributes.size(); currentIndex++) {
                TableColumn column = new TableColumn(attributes.get(currentIndex));
                column.setMinWidth((int)(sceneWidth / attributes.size()));
                column.setCellValueFactory(new PropertyValueFactory<Entity,String>(attributes.get(currentIndex)));
                tableContent.getColumns().addAll(column);
                Label attributeLabel = new Label(attributes.get(currentIndex));
                attributeLabels.add(attributeLabel);
                String foreignKeyParentTable = DataBaseConnection.foreignKeyParentTable(attributes.get(currentIndex), referrencedTables);
                /*if (foreignKeyParentTable != null) {
                    ComboBox attributeComboBox = new ComboBox();
                    try {
                        ArrayList<ArrayList<Object>> tableDescription = DataBaseConnection.getTableContent(foreignKeyParentTable, DataBaseConnection.getTableDescription(foreignKeyParentTable), null, null, null);
                        for (ArrayList<Object> entityDescription:tableDescription) {
                            attributeComboBox.getItems().addAll(entityDescription.get(0).toString());
                        }
                    } catch (Exception exception) {
                        System.out.println ("exceptie: "  +exception.getMessage());
                    }
                    attributeComboBox.setMinWidth(Constants.DEFAULT_COMBOBOX_WIDTH);
                    attributeComboBox.setMaxWidth(Constants.DEFAULT_COMBOBOX_WIDTH);
                    attributeControls.add(attributeComboBox);
                } else {*/
                    TextField attributeTextField = new TextField();
                    attributeTextField.setPromptText(attributes.get(currentIndex));
                    attributeTextField.setPrefColumnCount(Constants.DEFAULT_TEXTFIELD_WIDTH);
                    if (currentIndex==0) {
                        attributeTextField.setEditable(false);
                        try {
                            attributeTextField.setText((DataBaseConnection.getTablePrimaryKeyMaxValue(tableName)+1)+"");
                        } catch (Exception exception) {
                            System.out.println ("exceptie: "+exception.getMessage());
                        }
                    }
                    attributeControls.add(attributeTextField);
                
           // }
        }
        populateTableView(null);
        tableContent.setOnMouseClicked(new EventHandler<MouseEvent>() { 
          @Override
          public void handle(MouseEvent event) {   
              ArrayList<String> values = ((Entity)tableContent.getSelectionModel().getSelectedItem()).getValues();
              int currentIndex = 0;
              System.out.println("values " + values);
              for (String value:values) {
                  if (attributeControls.get(currentIndex) instanceof TextField) {
                    ((TextField)attributeControls.get(currentIndex)).setText(value);
                  } else {
                    String foreignKeyParentTable = DataBaseConnection.foreignKeyParentTable(attributeLabels.get(currentIndex).getText(), referrencedTables);
                    try {
                        ArrayList<ArrayList<Object>> tableDescription = DataBaseConnection.getTableContent(foreignKeyParentTable, DataBaseConnection.getTableDescription(foreignKeyParentTable), DataBaseConnection.getTablePrimaryKey(foreignKeyParentTable) +"="+values.get(currentIndex), null, null);
                        ((ComboBox)attributeControls.get(currentIndex)).setValue(tableDescription.get(0).get(0).toString());
                    } catch (Exception exception) {
                        System.out.println ("exceptie: " + exception.getMessage());
                    }
                  }
                  currentIndex++;
              }
          } 
        });
        container.getChildren().addAll(tableContent);
        
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(Constants.DEFAULT_SPACING, Constants.DEFAULT_SPACING, Constants.DEFAULT_SPACING, Constants.DEFAULT_SPACING));
        grid.setVgap(Constants.DEFAULT_GAP);
        grid.setHgap(Constants.DEFAULT_GAP);        
        
        int currentGridRow = 0, currentGridColumn = 2;
        
        int i;
        for (i = 0; i < attributeLabels.size(); i++) {
            GridPane.setConstraints(attributeLabels.get(i), 0, i);
            grid.add(attributeLabels.get(i), 0, i);
            
            GridPane.setConstraints(attributeControls.get(i), 0, i);
            grid.add(attributeControls.get(i), 1, i);
        }
        
        if (role.contains("RU_") && (tableName.equals("activitati"))) {
            Label nume = new Label("Nume");
            GridPane.setConstraints(nume, 0, i);
            grid.add(nume, 0, i);

            TextField nume_ = new TextField();
            GridPane.setConstraints(nume, 0, i);
            nume_.setPrefColumnCount(Constants.DEFAULT_TEXTFIELD_WIDTH);
            grid.add(nume_, 1, i);
            attributeLabels.add(nume);
            attributeControls.add(nume_);
            i++;
            
            Label dataStart = new Label("Data start");
            GridPane.setConstraints(dataStart, 0, i);
            grid.add(dataStart, 0, i);

            TextField data_start = new TextField();
            GridPane.setConstraints(data_start, 0, i);
            data_start.setPrefColumnCount(Constants.DEFAULT_TEXTFIELD_WIDTH);
            grid.add(data_start, 1, i);
            attributeLabels.add(dataStart);
            attributeControls.add(data_start);
            i++;

            Label dataStop = new Label("Data stop");
            GridPane.setConstraints(dataStop, 0, i);
            grid.add(dataStop, 0, i);

            TextField data_stop = new TextField();
            data_stop.setPrefColumnCount(Constants.DEFAULT_TEXTFIELD_WIDTH);
            GridPane.setConstraints(data_stop, 0, i);
            grid.add(data_stop, 1, i);
            attributeLabels.add(dataStop);
            attributeControls.add(data_stop);
        }
        
        // If the employee is not banned from editing tables
        if ((role.contains("RU_") && !tableName.equals("salarii") && !tableName.equals("zile")) || 
            (role.contains("MP_") && 
                (tableName.equals("proiecte") || 
                tableName.equals("versiuni") || 
                tableName.equals("echipe") || 
                tableName.equals("componente") || 
                tableName.equals("defecte"))) ||
              (role.contains("D_") && tableName.equals("defecte")) ||
              (role.contains("admin") || role.contains("superadmin")) ||
              (role.contains("C_") && 
                (tableName.equals("salarii") || 
                tableName.equals("intrari")))
               )
        {   
            final Button addButton = new Button(Constants.ADD_BUTTON_NAME);
            addButton.setMaxWidth(Double.MAX_VALUE);
            addButton.setOnMouseClicked(new EventHandler<MouseEvent>() { 
              @Override
              public void handle(MouseEvent event) {
                  ArrayList<String> values = new ArrayList<>();
              
                  Control attributeControl;
                  for(int currentIndex = 1; currentIndex < attributeControls.size(); currentIndex++){
                      attributeControl = attributeControls.get(currentIndex);

                      if (attributeControl instanceof TextField) {
                              values.add(((TextField)attributeControl).getText());
                              System.out.println("val1:" + values);
                      } else {
                          try {
                            System.out.println("debug:" + attributeLabels.get(currentIndex).getText() + " - " + referrencedTables.get(0).getParentTable());
                            String foreignKeyParentTable = DataBaseConnection.foreignKeyParentTable(attributeLabels.get(currentIndex).getText(), referrencedTables);
                            ArrayList<String> foreignKeyParentTablePrimaryKey = new ArrayList<>();
                            foreignKeyParentTablePrimaryKey.add(DataBaseConnection.getTablePrimaryKey(foreignKeyParentTable));
                            ArrayList<ArrayList<Object>> tableDescription = DataBaseConnection.getTableContent(foreignKeyParentTable, foreignKeyParentTablePrimaryKey, DataBaseConnection.getTableDescription(foreignKeyParentTable).get(0)+"=\""+((ComboBox)attributeControl).getValue()+"\"", null, null);
                            values.add(tableDescription.get(0).get(0).toString());
                            System.out.println("val1:" + values);
                          } catch (Exception exception) {
                              System.out.println ("exceptie: "+exception.getMessage());
                          }
                      }
                  }
                  try {
                        DataBaseConnection.insertValuesIntoTable(tableName, null, values, true);
                  } catch (Exception exception) {
                      System.out.println ("exceptie: "+exception.getMessage());
                  }
                  populateTableView(null);
              } 
            });
            GridPane.setConstraints(addButton, currentGridColumn, currentGridRow++);
            grid.getChildren().add(addButton);

            final Button updateButton = new Button(Constants.UPDATE_BUTTON_NAME);
            updateButton.setMaxWidth(Double.MAX_VALUE);
            updateButton.setOnMouseClicked(new EventHandler<MouseEvent>() { 
              @Override
              public void handle(MouseEvent event) {
                  ArrayList<String> values = new ArrayList<>();
                  ArrayList<String> labels = new ArrayList<>();

                  for (Label attrLabel : attributeLabels) {
                        labels.add(attrLabel.getText());
                  }

                  for (Control attrControl : attributeControls) {
                        values.add(( (TextField) attrControl).getText());
                  }
                  try {
                      DataBaseConnection.updateRecordsIntoTable(tableName, labels, values, attributeLabels.get(0).getText() + "=" + ( (TextField) attributeControls.get(0)).getText());
                  } catch (Exception ex) {
                      Logger.getLogger(DataBaseManagementGUI.class.getName()).log(Level.SEVERE, null, ex);
                  }
                  populateTableView(null);
              } 
            });        
            GridPane.setConstraints(updateButton, currentGridColumn, currentGridRow++);
            grid.getChildren().add(updateButton);        
            final Button deleteButton = new Button(Constants.DELETE_BUTTON_NAME);
            deleteButton.setMaxWidth(Double.MAX_VALUE);
            deleteButton.setOnMouseClicked(new EventHandler<MouseEvent>() { 
              @Override
              public void handle(MouseEvent event) { 
                  try {
                        DataBaseConnection.deleteRecordsFromTable(tableName,null,null,attributeLabels.get(0).getText()+"="+((TextField)attributeControls.get(0)).getText());
                  } catch (Exception exception) {
                      System.out.println ("exceptie: "+exception.getMessage());
                  }
                  populateTableView(null);
                  for (Control attributeControl:attributeControls) {
                      if (attributeControl instanceof TextField) {
                        ((TextField)attributeControl).setText("");
                      } else {
                        ((ComboBox)attributeControl).setValue("");
                      }
                  }
                  try {
                    ((TextField)attributeControls.get(0)).setText((DataBaseConnection.getTablePrimaryKeyMaxValue(tableName)+1)+"");
                  } catch (Exception exception) {
                    System.out.println ("exceptie: "+exception.getMessage());
                  }
                  populateTableView(null);
              } 
            });        
            GridPane.setConstraints(deleteButton, currentGridColumn, currentGridRow++);
            grid.getChildren().add(deleteButton);        

            final Button newButton = new Button(Constants.NEW_RECORD_BUTTON_NAME);
            newButton.setMaxWidth(Double.MAX_VALUE);
            newButton.setOnMouseClicked(new EventHandler<MouseEvent>() { 
              @Override
              public void handle(MouseEvent event) {   
                  for (Control attrCtrl : attributeControls) {
                      if (attrCtrl instanceof TextField) {
                        (( TextField) attrCtrl).setText("");
                      } else {
                        ( (ComboBox) attrCtrl).setValue("");
                      }
                  }
              } 
            });
            GridPane.setConstraints(newButton, currentGridColumn, currentGridRow++);
            grid.getChildren().add(newButton);    

            if ((tableName.equals("activitati"))){                   
                final Button searchButton = new Button("Cautare");
                searchButton.setMaxWidth(Double.MAX_VALUE);
                searchButton.setOnMouseClicked(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent event) {
                        String whereClause = new String();
                        String dataClause = new String();
                        String nume = new String();
                        boolean name = false;
                        boolean data1 = false;
                        boolean data2 = false;

                        for (int i = 1; i < attributeLabels.size(); i++) {
                            if (!((TextField) attributeControls.get(i)).getText().isEmpty()) {
                                if(data1 && !data2){
                                    dataClause += ((TextField) attributeControls.get(i)).getText() + "')";
                                    data2 = true;
                                }
                                if (name && !data1) {
                                    dataClause += "data IN ('"  + ((TextField) attributeControls.get(i)).getText() + "' , '";
                                    data1 = true;
                                }
                                if (!name) {
                                    nume += attributeLabels.get(i).getText() + "='" + ((TextField) attributeControls.get(i)).getText() + "'";
                                    name = true;
                                }
                            }
                        }
                        System.out.println(dataClause);
                        if (tableName.equals("activitati")) {
                            ArrayList<String> attr = new ArrayList<>();
                            attr.add("idangajat");
                            try {
                                ArrayList<ArrayList<Object>> res = DataBaseConnection.getTableContent("angajati", attr, nume+"  ", null, null);
                                System.out.println(res.get(0).get(0));
                                if(res!=null && !res.isEmpty()){
                                    whereClause = "idangajat='"+res.get(0).get(0)+"'";
                                    if (data2)
                                        whereClause+=" AND "+dataClause;
                                }
                                                
                                setContent();
                            } catch (SQLException ex) {
                                Logger.getLogger(DataBaseManagementGUI.class.getName()).log(Level.SEVERE, null, ex);
                            }

                        }
                        populateTableView(whereClause);
                    }
                    });
                GridPane.setConstraints(searchButton, currentGridColumn, currentGridRow++);
                grid.getChildren().add(searchButton); 
            }
            
            final DropShadow shadow = new DropShadow();
            final FadeTransition fadeTransition = new FadeTransition(Duration.millis(1000));
            final ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(1000));
            final ParallelTransition parallelTransition = new ParallelTransition(fadeTransition,scaleTransition);

            container.getChildren().addAll(grid);
        }
        
    }    
    
    @Override
    public void handle(Event event) {           
        if (event.getSource() instanceof MenuItem) {
            String entry = ((MenuItem)event.getSource()).getText();
            System.out.println(entry);
            if(entry.contains(" ")) {
                menuName = entry.split(" ")[1];
                entry = entry.split(" ")[0].toLowerCase();
                
                if(menuName.equals("Proiecte") && entry.equals("venituri"))
                    entry = "venitproiecte";
                if(menuName.equals("Angajat") && entry.equals("cheltuieli"))
                    entry = "cheltuieliangajat";
                if(menuName.equals("Departament") && entry.equals("cheltuieli"))
                    entry = "cheltuielidepartament";
                System.out.println(entry);
            }
            if (Utilities.isTableName(entry)) {
                ((VBox)applicationScene.getRoot()).getChildren().clear();
                tableName = entry;
               
                try {
                    setContent();
                } catch (Exception exception) {
                    System.out.println ("exceptie: "+exception.getMessage());
                }
                ((VBox)applicationScene.getRoot()).getChildren().addAll(applicationMenu,container);
                applicationStage.setScene(applicationScene);
                applicationStage.show();
            } else {
                //
            }
        }        
    }    
}
