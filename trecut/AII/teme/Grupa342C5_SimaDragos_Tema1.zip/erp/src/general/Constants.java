package general;

public interface Constants {
    final public static String      APPLICATION_NAME            = "ERP";

    final public static String[][] ADMIN_MENU_STRUCTURE         = {
                                                                    {"Administrare", "Angajati" , "Departamente", "Proiecte", "Constante"}
                                                                  };
    final public static String[][] RU_MENU_STRUCTURE            = {
                                                                    {"Resurse umane", "Angajati", "Contracte", "Zile", "Concedii", "Activitati"},
                                                                    {"Despre mine", "Salarii"},
                                                                  };
    final public static String[][] C_MENU_STRUCTURE            = {
                                                                    {"Despre mine", "Angajati", "Contracte", "Zile", "Concedii", "Activitati"},
                                                                    {"Contabilitate", "Intrari", "Venituri Proiecte", "Salarii", "Cheltuieli Departament", "Cheltuieli Angajat"}       
                                                                  };
    final public static String[][] D_MENU_STRUCTURE            = {  
                                                                    {"Despre mine", "Angajati", "Contracte", "Zile", "Concedii", "Activitati", "Salarii"},
                                                                    {"Dezvoltare", "Proiecte", "Componente", "Versiuni"},
                                                                    {"Gestiunea defectelor", "Defecte"}
                                                                  };
    final public static String[][] MP_MENU_STRUCTURE            = { 
                                                                    {"Despre mine", "Angajati", "Contracte", "Concedii", "Zile", "Activitati", "Salarii"},
                                                                    {"Monitorizare proiecte", "Proiecte", "Versiuni", "Echipe", "Componente"},
                                                                    {"Gestiunea defectelor", "Defecte"}
                                                                  };
    
    final public static String      DATABASE_CONNECTION         = "jdbc:mysql://localhost:3306/erp";
    final public static String      DATABASE_NAME               = "erp";
    final public static String      DATABASE_USER               = "root";
    final public static String      DATABASE_PASSWORD           = "sima";
    
    final public static boolean     DEBUG                       = true;
    
    final public static String      ADD_BUTTON_NAME             = "Adauga";
    final public static String      UPDATE_BUTTON_NAME          = "Modifica";
    final public static String      DELETE_BUTTON_NAME          = "Sterge";
    final public static String      NEW_RECORD_BUTTON_NAME      = "Inregistrare Noua";
    final public static String      SEARCH_BUTTON_NAME          = "Cautare";
    
    final public static double      SCENE_WIDTH_SCALE           = 0.99;
    final public static double      SCENE_HEITH_SCALE           = 0.90;
    final public static int         DEFAULT_SPACING             = 10;
    final public static int         DEFAULT_GAP                 = 5;
    final public static int         DEFAULT_COMBOBOX_WIDTH      = 125;
    final public static int         DEFAULT_TEXTFIELD_WIDTH     = 10;
    
    final public static String      FXML_DOCUMENT_NAME          = "authentication.fxml";
    final public static String      ICON_FILE_NAME              = "icon.png";
    
    final public static String      PRIVILEGED_ROLE             = "administrator";
    final public static String      SUBMIT_BUTTON               = "Acceptare";
    final public static String      CANCEL_BUTTON               = "Renuntare";    
    final public static String      ERROR_USERNAME_PASSWORD     = "Nume Utilizator / Parola incorecte !";
    final public static String      ERROR_ACCESS_NOT_ALLOWED    = "Nu aveti suficiente drepturi pentru a accesa aplicatia !";
    final public static String      ABOUT_TEXT                  = "ERP\n";
}
