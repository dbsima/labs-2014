import dataaccess.DataBaseConnection;
import general.Constants;
import graphicuserinterface.DataBaseManagementGUI;
import java.util.ArrayList;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class erp extends Application implements EventHandler {  
    private Stage               applicationStage;
    private Scene               applicationScene;
    
    @FXML private TextField     campTextNumeUtilizator;
    @FXML private PasswordField campTextParola;
    @FXML private Label         etichetaAfisare;    
    
    public erp() {
    }  
    
    @Override
    public void start(Stage mainStage) {
        applicationStage = mainStage;
        try {
            applicationScene = new Scene((Parent)FXMLLoader.load(getClass().getResource(Constants.FXML_DOCUMENT_NAME)));
            applicationScene.addEventHandler(EventType.ROOT,(EventHandler<? super Event>)this);
        } catch (Exception exception) {
            System.out.println ("exception : "+exception.getMessage());
        }        
        applicationStage.setTitle(Constants.APPLICATION_NAME);
        applicationStage.getIcons().add(new Image(Constants.ICON_FILE_NAME));
        applicationStage.setScene(applicationScene);
        applicationStage.show();
    }
    
    @FXML protected void handleButonAcceptareAction(ActionEvent event) throws Exception {
        String user = campTextNumeUtilizator.getText();
        String pass = campTextParola.getText();
        
        
        ArrayList<String> attributes = new ArrayList<>();
        attributes.add("angajati.numeutilizator");
        attributes.add("angajati.parola");
        attributes.add("angajati.functie");
        attributes.add("angajati.iddep");
        attributes.add("angajati.idAngajat");
                
        ArrayList<ArrayList<Object>> result = DataBaseConnection.getTableContent("angajati", attributes, "angajati.numeutilizator = \'" + user + "\'", null, null);
        System.out.println(result);
        
               
        String error = null;
        if (result == null)
            etichetaAfisare.setText("Inexistent user");
        else 
        {
            ArrayList<Object> userDetails = result.get(0);
            
            if (!userDetails.get(1).equals(pass))
                etichetaAfisare.setText("User and password do not match");
            else {
                error = "Succes";
                
                DataBaseManagementGUI dbmGUI = new DataBaseManagementGUI((String) userDetails.get(2));
                
                attributes = new ArrayList<>();
                attributes.add("departamente.denumire");
                result = DataBaseConnection.getTableContent("departamente", attributes, "departamente.iddepartament = \'" + (String) userDetails.get(3) + "\'", null, null);
                
                if (!result.isEmpty()) {
                    System.out.println(result.get(0).get(0));
                    if (result.get(0).get(0).equals("contabilitate"))
                        // the employee is in the "contabilitate deparment"
                        dbmGUI = new DataBaseManagementGUI("C_" + (String) userDetails.get(3) +"_"+ (String) userDetails.get(4));
                    else if (result.get(0).get(0).equals("resurse umane"))
                        dbmGUI = new DataBaseManagementGUI("RU_" + (String) userDetails.get(3) +"_"+ (String) userDetails.get(4));
                }
                
                attributes = new ArrayList<>();
                attributes.add("departamente.idresponsabil");
                attributes.add("departamente.denumire");
                result = DataBaseConnection.getTableContent("departamente", attributes, "departamente.iddepartament = \'" + (String) userDetails.get(3) + "\' AND departamente.denumire IN ('programare', 'asigurarea calitatii')", null, null);
                                
                if (!result.isEmpty()) {
                    // the employee is in the department of programare or asigurarea calitatii
                    System.out.println(result.get(0).get(0) + " - " + (String) userDetails.get(4));
                    if (result.get(0).get(0).equals((String) userDetails.get(4)))
                        // the employee is the person responsible for his department
                        dbmGUI = new DataBaseManagementGUI("MP_" + (String) userDetails.get(3) + "_" + (String) userDetails.get(4));
                    else
                        dbmGUI = new DataBaseManagementGUI("D_" + (String) userDetails.get(3) +"_"+ (String) userDetails.get(4));
                }
               
                dbmGUI.start();
            }
            System.out.println(error);
        }
    }  
    
    @FXML protected void handleButonRenuntareAction(ActionEvent event) {
        System.exit(0);
    } 
    
    @Override
    public void handle(Event event) {
        if (event.getTarget() instanceof Button && ((Button)event.getTarget()).getText().equals(Constants.SUBMIT_BUTTON) && event.getEventType().equals(ActionEvent.ACTION) && !applicationStage.isFocused()) {
           applicationStage.hide(); 
        }
    }
    
    public static void main(String[] args) {
        launch(args);
    }
}
