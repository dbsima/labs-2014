/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package entities;

import java.util.ArrayList;
import javafx.beans.property.SimpleStringProperty;

public class Echipa extends Entity {
    final private SimpleStringProperty id, denumire, idresponsabil, iddepartament, idproiect;
    
    public Echipa(ArrayList<Object> contract) {
        this.id = new SimpleStringProperty(contract.get(0).toString());
        this.denumire = new SimpleStringProperty(contract.get(1).toString());
        this.idresponsabil = new SimpleStringProperty(contract.get(2).toString());
        this.iddepartament = new SimpleStringProperty(contract.get(3).toString());
        this.idproiect = new SimpleStringProperty(contract.get(4).toString());
    }
    
    public String getIdechipa() {
        return id.get();
    }
    
    public String getDenumire() {
        return denumire.get();
    }
    
    public void setDenumire(String salariu) {
        this.denumire.set(salariu);
    }
    
    public String getIdresponsabil() {
        return idresponsabil.get();
    }
    
    public void setIdresponsabil(String ore) {
        this.idresponsabil.set(ore);
    }
    
    public String getIddepartament() {
        return iddepartament.get();
    }
    
    public void setIddepartament(String dept) {
        this.iddepartament.set(dept);
    }
    
    public String getIdproiect() {
        return idproiect.get();
    }
    
     public void setIdproiect(String idproiect) {
        this.idproiect.set(idproiect);
    }
    
    
     @Override
    public ArrayList<String> getValues() {
        ArrayList<String> values = new ArrayList<>();
        values.add(id.get());
        values.add(denumire.get());
        values.add(idresponsabil.get());
        values.add(iddepartament.get());
        values.add(idproiect.get());
        return values;
    }
}
