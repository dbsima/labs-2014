/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package entities;

import java.util.ArrayList;
import javafx.beans.property.SimpleStringProperty;

public class Proiect extends Entity {
    final private SimpleStringProperty id, denumire, descriere;
    
    public Proiect(ArrayList<Object> contract) {
        this.id = new SimpleStringProperty(contract.get(0).toString());
        this.denumire = new SimpleStringProperty(contract.get(1).toString());
        this.descriere = new SimpleStringProperty(contract.get(2).toString());     
    }
    
    public String getIdproiect() {
        return id.get();
    }
    
    public void setIdproiect(String salariu) {
        this.id.set(salariu);
    }
    
    public String getDenumire() {
        return denumire.get();
    }
    
    public void setDenumire(String salariu) {
        this.denumire.set(salariu);
    }
    
    public String getDescriere() {
        return descriere.get();
    }
    
    public void setDescriere(String ore) {
        this.descriere.set(ore);
    }
    
  
     @Override
    public ArrayList<String> getValues() {
        ArrayList<String> values = new ArrayList<>();
        values.add(id.get());
        values.add(denumire.get());
        values.add(descriere.get());
        return values;
    }
}
