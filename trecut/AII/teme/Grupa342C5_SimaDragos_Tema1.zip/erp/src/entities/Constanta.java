/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package entities;

import java.util.ArrayList;
import javafx.beans.property.SimpleStringProperty;

public class Constanta extends Entity {
    final private SimpleStringProperty idconstanta, cheie, valoare;
    
    public Constanta(ArrayList<Object> contract) {
        this.idconstanta = new SimpleStringProperty(contract.get(0).toString());
        this.cheie = new SimpleStringProperty(contract.get(1).toString());
        this.valoare = new SimpleStringProperty(contract.get(2).toString());     
    }
    
    public String getIdconstanta() {
        return idconstanta.get();
    }
    
    public String getCheie() {
        return cheie.get();
    }
    
    public void setCheie(String salariu) {
        this.cheie.set(salariu);
    }
    
    public String getValoare() {
        return valoare.get();
    }
    
    public void setValoare(String ore) {
        this.valoare.set(ore);
    }
    
  
     @Override
    public ArrayList<String> getValues() {
        ArrayList<String> values = new ArrayList<>();
        values.add(idconstanta.get());
        values.add(cheie.get());
        values.add(valoare.get());
        return values;
    }
}
