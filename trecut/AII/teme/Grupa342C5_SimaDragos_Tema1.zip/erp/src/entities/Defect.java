/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package entities;

import java.util.ArrayList;
import javafx.beans.property.SimpleStringProperty;

public class Defect extends Entity {
    final private SimpleStringProperty iddefect, denumire, severitate, descriere, reproductibilitate, statut, rezultat, comentarii, datamodif, idversiune, idangajat;
    
    public Defect(ArrayList<Object> contract) {
        this.iddefect = new SimpleStringProperty(contract.get(0).toString());
        this.denumire = new SimpleStringProperty(contract.get(1).toString());
        this.severitate = new SimpleStringProperty(contract.get(2).toString());
        this.descriere = new SimpleStringProperty(contract.get(3).toString());
        this.reproductibilitate = new SimpleStringProperty(contract.get(4).toString());
        this.statut = new SimpleStringProperty(contract.get(5).toString());
        this.rezultat = new SimpleStringProperty(contract.get(6).toString());
        this.comentarii = new SimpleStringProperty(contract.get(7).toString());
        this.datamodif = new SimpleStringProperty(contract.get(8).toString());
        this.idversiune = new SimpleStringProperty(contract.get(9).toString());
        this.idangajat = new SimpleStringProperty(contract.get(10).toString());
    }
    
    public String getIddefect() {
        return iddefect.get();
    }
    
    public String getDenumire() {
        return denumire.get();
    }
    
    public void setDenumire(String salariu) {
        this.denumire.set(salariu);
    }
    
    public String getSeveritate() {
        return severitate.get();
    }
    
    public void setSeveritate(String ore) {
        this.severitate.set(ore);
    }
    
    public String getDescriere() {
        return descriere.get();
    }
    
    public void setDescriere(String dept) {
        this.descriere.set(dept);
    }
    
    public String getReproductibilitate() {
        return reproductibilitate.get();
    }
    
     public void setReproductibilitate(String idproiect) {
        this.reproductibilitate.set(idproiect);
    }
     
    public String getStatus() {
        return statut.get();
    }
    
    public void setStatut(String statut) {
        this.statut.set(statut);
    }
    
    public String getRezultat() {
        return rezultat.get();
    }
    
    public void setRezultat(String dept) {
        this.rezultat.set(dept);
    }
    
    public String getComentarii() {
        return comentarii.get();
    }
    
    public void setComentarii(String dept) {
        this.comentarii.set(dept);
    }
    
    public String getDatamodif() {
        return datamodif.get();
    }
    
    public void setDatamodif(String dept) {
        this.datamodif.set(dept);
    }
    
    public String getIdversiune() {
        return idversiune.get();
    }
    
    public void setIdversiune(String dept) {
        this.idversiune.set(dept);
    }
    
    public String getIdangajat() {
        return idangajat.get();
    }
    
    public void setIdangajat(String idangajat) {
        this.idangajat.set(idangajat);
    }
    
    @Override
    public ArrayList<String> getValues() {
        ArrayList<String> values = new ArrayList<>();
        values.add(iddefect.get());
        values.add(denumire.get());
        values.add(severitate.get());
        values.add(reproductibilitate.get());
        values.add(statut.get());
        values.add(rezultat.get());
        values.add(comentarii.get());
        values.add(datamodif.get());
        values.add(idversiune.get());
        values.add(idangajat.get());
        return values;
    }
}
