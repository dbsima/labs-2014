/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package entities;

import java.util.ArrayList;
import javafx.beans.property.SimpleStringProperty;

public class Versiune extends Entity {
    final private SimpleStringProperty id, denumire, deadline, idproiect;
    
    public Versiune(ArrayList<Object> contract) {
        this.id = new SimpleStringProperty(contract.get(0).toString());
        this.denumire = new SimpleStringProperty(contract.get(1).toString());
        this.deadline = new SimpleStringProperty(contract.get(2).toString());
        this.idproiect = new SimpleStringProperty(contract.get(3).toString());  
    }
    
    public String getIdversiune() {
        return id.get();
    }
    
    public String getDenumire() {
        return denumire.get();
    }
    
    public void setDenumire(String salariu) {
        this.denumire.set(salariu);
    }
    
    public String getDeadline() {
        return deadline.get();
    }
    
    public void setDescriere(String ore) {
        this.deadline.set(ore);
    }
    
    public String getIdproiect() {
        return idproiect.get();
    }
    
     public void setIdproiect(String idproiect) {
        this.idproiect.set(idproiect);
    }
    
  
     @Override
    public ArrayList<String> getValues() {
        ArrayList<String> values = new ArrayList<>();
        values.add(id.get());
        values.add(denumire.get());
        values.add(deadline.get());
        values.add(idproiect.get());
        return values;
    }
}
