/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package entities;

import java.util.ArrayList;
import javafx.beans.property.SimpleStringProperty;

public class Componenta extends Entity {
    final private SimpleStringProperty id, datainceput, datasfarsit, idmembru, idechipa;
    
    public Componenta(ArrayList<Object> contract) {
        this.id = new SimpleStringProperty(contract.get(0).toString());
        this.datainceput = new SimpleStringProperty(contract.get(1).toString());
        this.datasfarsit = new SimpleStringProperty(contract.get(2).toString());
        this.idmembru = new SimpleStringProperty(contract.get(3).toString());
        this.idechipa = new SimpleStringProperty(contract.get(4).toString());
    }
    
    public String getId() {
        return id.get();
    }
    
    public String getDatainceput() {
        return datainceput.get();
    }
    
    public void setDatainceput(String salariu) {
        this.datainceput.set(salariu);
    }
    
    public String getDatasfarsit() {
        return datainceput.get();
    }
    
    public void setDatasfarsit(String ore) {
        this.datainceput.set(ore);
    }
    
    public String getIdmembru() {
        return idmembru.get();
    }
    
    public void setIdmembru(String dept) {
        this.idmembru.set(dept);
    }
    
    public String getIdechipa() {
        return idechipa.get();
    }
    
     public void setIdechipa(String idproiect) {
        this.idechipa.set(idproiect);
    }
    
    @Override
    public ArrayList<String> getValues() {
        ArrayList<String> values = new ArrayList<>();
        values.add(id.get());
        values.add(datainceput.get());
        values.add(datasfarsit.get());
        values.add(idmembru.get());
        values.add(idechipa.get());
        return values;
    }
}
