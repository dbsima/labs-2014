/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package entities;

import java.util.ArrayList;
import javafx.beans.property.SimpleStringProperty;

public class Angajat extends Entity {
    final private SimpleStringProperty CNP, nume, prenume, adresa, telefon, email, IBAN, functie, data_angajare, utilizator, parola, id, departament;
    
    public Angajat(ArrayList<Object> user) {
        this.id = new SimpleStringProperty(user.get(0).toString());
        this.CNP = new SimpleStringProperty(user.get(1).toString());
        this.nume = new SimpleStringProperty(user.get(2).toString());
        this.prenume = new SimpleStringProperty(user.get(3).toString());
        this.adresa = new SimpleStringProperty(user.get(4).toString()); 
        this.telefon = new SimpleStringProperty(user.get(5).toString()); 
        this.email = new SimpleStringProperty(user.get(6).toString()); 
        this.IBAN = new SimpleStringProperty(user.get(7).toString()); 
        this.functie = new SimpleStringProperty(user.get(8).toString()); 
        this.data_angajare = new SimpleStringProperty(user.get(9).toString());
        this.utilizator = new SimpleStringProperty(user.get(10).toString()); 
        this.parola = new SimpleStringProperty(user.get(11).toString()); 
        this.departament = new SimpleStringProperty(user.get(12).toString());    
    }
    
    public String getIdangajat() {
        return id.get();
    }
    
    public String getCNP() {
        return CNP.get();
    }
    
    public void setCNP(String CNP) {
        this.CNP.set(CNP);
    }
    
    public String getNume() {
        return nume.get();
    }
    
    public void setNume(String nume) {
        this.nume.set(nume);
    }
    
    public String getPrenume() {
        return prenume.get();
    }
    
    public void setPrenume(String prenume) {
        this.prenume.set(prenume);
    }
    
    public String getEmail() {
        return email.get();
    }
    
    public void setEmail(String email) {
        this.email.set(email);
    }
    
    public String getAdresa() {
        return adresa.get();
    }
    
    public void setAdresa(String adresa) {
        this.adresa.set(adresa);
    }
    
    public String getTelefon() {
        return telefon.get();
    }
    
    public void setTelefon(String telefon) {
        this.telefon.set(telefon);
    }
    
    public String getIBAN() {
        return IBAN.get();
    }
    
    public void setIBAN(String IBAN) {
        this.IBAN.set(IBAN);
    }
    
    public String getFunctie() {
        return functie.get();
    }
    
    public void setFunctie(String functie) {
        this.functie.set(functie);
    }
    
    public String getDataang() {
        return data_angajare.get();
    }
    
    public void setDataang(String data_angajare) {
        this.data_angajare.set(data_angajare);
    }
    
    public String getNumeutilizator() {
        return utilizator.get();
    }
    
    public void setNumeutilizator(String nume) {
        this.utilizator.set(nume);
    }
    
    public String getParola() {
        return parola.get();
    }
    
    public void setParola(String parola) {
        this.parola.set(parola);
    }
    
    public String getIddep() {
        return departament.get();
    }
    
    public void setIddep(String iddep) {
        this.departament.set(iddep);
    }
    
    @Override
    public ArrayList<String> getValues() {
        ArrayList<String> values = new ArrayList<>();
        values.add(id.get());
        values.add(CNP.get());
        values.add(nume.get());
        values.add(prenume.get());
        values.add(adresa.get());
        values.add(telefon.get());
        values.add(email.get());
        values.add(IBAN.get());
        values.add(functie.get());
        values.add(data_angajare.get());
        values.add(utilizator.get());
        values.add(parola.get());
        values.add(departament.get());
        return values;
    }
}
