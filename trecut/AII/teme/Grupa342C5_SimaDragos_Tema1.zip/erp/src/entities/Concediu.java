/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package entities;

import java.util.ArrayList;
import javafx.beans.property.SimpleStringProperty;

public class Concediu extends Entity {
    final private SimpleStringProperty idconcediu, tip, dataplecare, datarevenire, idangajat;
    
    public Concediu(ArrayList<Object> contract) {
        this.idconcediu = new SimpleStringProperty(contract.get(0).toString());
        this.tip = new SimpleStringProperty(contract.get(1).toString());
        this.dataplecare = new SimpleStringProperty(contract.get(2).toString());
        this.datarevenire = new SimpleStringProperty(contract.get(3).toString());
        this.idangajat = new SimpleStringProperty(contract.get(4).toString());
    }
    
    public String getIdconcediu() {
        return idconcediu.get();
    }
    
    public String getTip() {
        return tip.get();
    }
    
    public void setTip(String salariu) {
        this.tip.set(salariu);
    }
    
    public String getDatainceput() {
        return dataplecare.get();
    }
    
    public void setDatainceput(String salariu) {
        this.dataplecare.set(salariu);
    }
    
    public String getDatasfarsit() {
        return datarevenire.get();
    }
    
    public void setDatasfarsit(String ore) {
        this.datarevenire.set(ore);
    }
    
    public String getIdangajat() {
        return idangajat.get();
    }
    
    public void setIdangajat(String dept) {
        this.idangajat.set(dept);
    }
    
    @Override
    public ArrayList<String> getValues() {
        ArrayList<String> values = new ArrayList<>();
        values.add(idconcediu.get());
        values.add(tip.get());
        values.add(dataplecare.get());
        values.add(datarevenire.get());
        values.add(idangajat.get());
        return values;
    }
}
