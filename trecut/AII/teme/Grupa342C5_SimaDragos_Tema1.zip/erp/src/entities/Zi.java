/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package entities;

import dataaccess.DataBaseConnection;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleStringProperty;

import org.joda.time.DateTime;
import org.joda.time.Days;

public class Zi extends Entity {
    final private SimpleStringProperty idzi, ramase, odihna, medical, faraplata, motivespeciale, idangajat;
    
    final private String role;
    
    public Zi(ArrayList<Object> activitate, String role) {
        this.idzi = new SimpleStringProperty(activitate.get(0).toString());
        this.ramase = new SimpleStringProperty(activitate.get(1).toString());
        this.odihna = new SimpleStringProperty(activitate.get(2).toString());
        this.medical = new SimpleStringProperty(activitate.get(3).toString());
        this.faraplata = new SimpleStringProperty(activitate.get(4).toString());
        this.motivespeciale = new SimpleStringProperty(activitate.get(5).toString());
        this.idangajat = new SimpleStringProperty(activitate.get(6).toString());
    
        this.role = role;
    }
    
    public String getIdzi() {
        return idzi.get();
    }
    
    public String getRamase() {
        ArrayList<String> attr = new ArrayList<>();
        attr.add("valoare");
        
        try {
            ArrayList<ArrayList<Object>> values = DataBaseConnection.getTableContent("constante", attr, "cheie = 'zileconcediu'", null, null);

            Integer zileConcediu = Integer.parseInt(values.get(0).get(0).toString());
            Integer zileOdihna = Integer.parseInt(getOdihna());
            Integer zileMedical = Integer.parseInt(getMedical());
            Integer zileFaraplata = Integer.parseInt(getFaraplata());
            Integer zileMotivespeciale = Integer.parseInt(getMotivespeciale());
            System.out.println(new Integer(zileConcediu - zileOdihna - zileMedical - zileFaraplata - zileMotivespeciale).toString());
            ramase.set(new Integer(zileConcediu - zileOdihna - zileMedical - zileFaraplata - zileMotivespeciale).toString());
        } catch (SQLException ex) {
            Logger.getLogger(Zi.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ramase.get();
    }
    
    public String getOdihna() {
        ArrayList<String> attr = new ArrayList<>();
        attr.add("datainceput");
        attr.add("datasfarsit");
        
        String idAngajat = role.split("_")[2];
        if(role.contains("RU_"))
            idAngajat = getIdangajat();

        try {
            ArrayList<ArrayList<Object>> values = DataBaseConnection.getTableContent("concedii", attr, "idangajat = '" + idAngajat + "' AND tip = 'concediu de odihna'", null, null);
            
            int restDays = 0;
            for (int i = 0; i < values.size(); i++) {       
                DateTime date1 = new DateTime(values.get(i).get(0));
                DateTime date2 = new DateTime(values.get(i).get(1));
                int days = Days.daysBetween(date1, date2).getDays() + 1;
                restDays += days;
                System.out.println(values.get(i) + "  -  " + days);
            }

            if (restDays > 0)
                odihna.set(new Integer(restDays).toString());
             
             } catch (SQLException ex) {
            Logger.getLogger(Zi.class.getName()).log(Level.SEVERE, null, ex);
        }
        return odihna.get();
    }
    
    public String getMedical() {
        ArrayList<String> attr = new ArrayList<>();
        attr.add("datainceput");
        attr.add("datasfarsit");
        
        String idAngajat = role.split("_")[2];
        if(role.contains("RU_"))
            idAngajat = getIdangajat();
        try {
            ArrayList<ArrayList<Object>> values = DataBaseConnection.getTableContent("concedii", attr, "idangajat = '" + idAngajat + "' AND tip = 'concediu medical'", null, null);
            
            int restDays = 0;
            for (int i = 0; i < values.size(); i++) {       
                DateTime date1 = new DateTime(values.get(i).get(0));
                DateTime date2 = new DateTime(values.get(i).get(1));
                int days = Days.daysBetween(date1, date2).getDays() + 1;
                restDays += days;
                System.out.println(values.get(i) + "  -  " + days);
            }

            if (restDays > 0)
                medical.set(new Integer(restDays).toString());
             
             } catch (SQLException ex) {
            Logger.getLogger(Zi.class.getName()).log(Level.SEVERE, null, ex);
        }
        return medical.get();
    }
    
    public String getFaraplata() {
        ArrayList<String> attr = new ArrayList<>();
        attr.add("datainceput");
        attr.add("datasfarsit");
        
        String idAngajat = role.split("_")[2];
        if(role.contains("RU_"))
            idAngajat = getIdangajat();

        try {
            ArrayList<ArrayList<Object>> values = DataBaseConnection.getTableContent("concedii", attr, "idangajat = '" + idAngajat + "' AND tip = 'concediu fara plata'", null, null);
            
            int restDays = 0;
            for (int i = 0; i < values.size(); i++) {       
                DateTime date1 = new DateTime(values.get(i).get(0));
                DateTime date2 = new DateTime(values.get(i).get(1));
                int days = Days.daysBetween(date1, date2).getDays() + 1;
                restDays += days;
                System.out.println(values.get(i) + "  -  " + days);
            }

            if (restDays > 0)
                faraplata.set(new Integer(restDays).toString());
             
             } catch (SQLException ex) {
            Logger.getLogger(Zi.class.getName()).log(Level.SEVERE, null, ex);
        }
        return faraplata.get();
    }
    
    public String getMotivespeciale() {
        ArrayList<String> attr = new ArrayList<>();
        attr.add("datainceput");
        attr.add("datasfarsit");
        
        String idAngajat = role.split("_")[2];
        if(role.contains("RU_"))
            idAngajat = getIdangajat();

        try {
            ArrayList<ArrayList<Object>> values = DataBaseConnection.getTableContent("concedii", attr, "idangajat = '" + idAngajat + "' AND tip = 'concediu motive speciale'", null, null);
            
            int restDays = 0;
            for (int i = 0; i < values.size(); i++) {       
                DateTime date1 = new DateTime(values.get(i).get(0));
                DateTime date2 = new DateTime(values.get(i).get(1));
                int days = Days.daysBetween(date1, date2).getDays() + 1;
                restDays += days;
                System.out.println(values.get(i) + "  -  " + days);
            }

            if (restDays > 0)
                motivespeciale.set(new Integer(restDays).toString());
             
             } catch (SQLException ex) {
            Logger.getLogger(Zi.class.getName()).log(Level.SEVERE, null, ex);
        }
        return motivespeciale.get();
    }
    
    public String getIdangajat() {
        return idangajat.get();
    }
    
    public void setIdangajat(String iddep) {
        this.idangajat.set(iddep);
    }
    
    @Override
    public ArrayList<String> getValues() {
        ArrayList<String> values = new ArrayList<>();
        values.add(idzi.get());
        values.add(ramase.get());
        values.add(odihna.get());
        values.add(medical.get());
        values.add(faraplata.get());
        values.add(motivespeciale.get());
        values.add(idangajat.get());        
        return values;
    }
}
