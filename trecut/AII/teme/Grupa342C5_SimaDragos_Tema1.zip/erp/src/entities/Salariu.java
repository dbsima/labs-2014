/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package entities;

import dataaccess.DataBaseConnection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleStringProperty;
import org.joda.time.DateTime;
import org.joda.time.Days;

public class Salariu extends Entity {
    final private SimpleStringProperty id, data, oreefectuate, zileconcediu, brut, net, oresuplimentare, suplimentar, idangajat;
    final private String role;
    
    public Salariu(ArrayList<Object> contract, String role) {
        this.id = new SimpleStringProperty(contract.get(0).toString());
        this.data = new SimpleStringProperty(contract.get(1).toString());
        this.oreefectuate = new SimpleStringProperty(contract.get(2).toString());
        this.zileconcediu = new SimpleStringProperty(contract.get(3).toString());
        this.brut = new SimpleStringProperty(contract.get(4).toString());
        this.net = new SimpleStringProperty(contract.get(5).toString());
        this.oresuplimentare = new SimpleStringProperty(contract.get(6).toString());
        this.suplimentar = new SimpleStringProperty(contract.get(7).toString());
        this.idangajat = new SimpleStringProperty(contract.get(8).toString());
        
        this.role = role;
    }
    
    public String getIdfactura() {
        return id.get();
    }
    
    public String getData() {
        return data.get();
    }
    

    
    public void setData(String salariu) {
        this.data.set(salariu);
    }
    
    public String getOreefectuate() {
          return oreefectuate.get();
     }
    
    public String getZileconcediu() {
        ArrayList<String>attr = new ArrayList<>();
        attr.add("datainceput");
        attr.add("datasfarsit");
        
        String dataEmitere = getData();
        String idAngajat = getIdangajat();

        try {
            // get year and month for wich to display the outcome
            String year = dataEmitere.split("-")[0];
            String month = dataEmitere.split("-")[1];
           
            // get the number of payd vacancy days for that month of the year
            ArrayList<ArrayList<Object>> values = DataBaseConnection.getTableContent("concedii", attr, "idangajat = '" + idAngajat + "' AND tip IN ('concediu de odihna', 'concediu medical', 'concediu motive speciale') AND (datainceput LIKE '" + year + "-" + month + "%' OR datasfarsit LIKE '" + year + "-" + month + "%')", null, null);
            
            Integer restDays = 0;
            for (int i = 0; i < values.size(); i++) {       
                DateTime date1 = new DateTime(values.get(i).get(0));
                DateTime date2 = new DateTime(values.get(i).get(1));

                if (!values.get(i).get(1).toString().split("-")[1].equals(month) )
                    date2 = date1.dayOfMonth().withMaximumValue();
                if (!values.get(i).get(0).toString().split("-")[1].equals(month) )
                    date1 = date2.dayOfMonth().withMinimumValue();
                int days = Days.daysBetween(date1, date2).getDays() + 1;
                restDays += days;
            }
            zileconcediu.set(restDays.toString());
        
        } catch (SQLException ex) {
            Logger.getLogger(Zi.class.getName()).log(Level.SEVERE, null, ex);
        }
          return zileconcediu.get();
     }
    
    public String getBrut() {
        ArrayList<String>attr = new ArrayList<>();
        attr.add("ore");
        attr.add("salariu");
        
        String dataEmitere = getData();
        String idAngajat = getIdangajat();
        
        Integer zileSalariu = new Integer(getZileconcediu());
        
        try {
            // get year and month for wich to display the outcome
            String year = dataEmitere.split("-")[0];
            String month = dataEmitere.split("-")[1];
            
            // get number of hours to do per day
            ArrayList<ArrayList<Object>> values = DataBaseConnection.getTableContent("contracte", attr, "idangajat = '" + idAngajat + "'", null, null);
            Integer oreNorma = new Integer(values.get(0).get(0).toString().split(":")[0]);
            Integer salariu = new Integer(values.get(0).get(1).toString());
            Integer minuteNorma = oreNorma*60;

            // 
            attr = new ArrayList<>();
            attr.add("orasosire");
            attr.add("oraplecare");
            attr.add("data");
            values = DataBaseConnection.getTableContent("activitati", attr, "idangajat = '" + idAngajat + "' AND data LIKE '" + year + "-" + month + "%'", null, null);
            if(!values.isEmpty()) {
                Integer totalOreEfectuate = zileSalariu * oreNorma;
                Integer totalOreSuplimentare = 0;
                Integer minuteSuplimentare = 0;
                
                for(ArrayList<Object> value: values) {
                    zileSalariu++;
                    Integer oraSosire = new Integer(value.get(0).toString().split(":")[0]);
                    Integer minutSosire = new Integer(value.get(0).toString().split(":")[1]);
                    
                    Integer oraPlecare = new Integer(value.get(1).toString().split(":")[0]);
                    Integer minutPlecare = new Integer(value.get(1).toString().split(":")[1]);
                    
                    Integer minuteEfectuate = new Integer((oraPlecare - oraSosire)*60 + minutPlecare - minutSosire);
                    if (minuteEfectuate >= minuteNorma){
                        totalOreEfectuate += oreNorma;
                        totalOreSuplimentare += (minuteEfectuate - minuteNorma)/60;
                    }
                    else
                        totalOreEfectuate += minuteEfectuate/60;
                }
                oresuplimentare.set(totalOreSuplimentare.toString());
                oreefectuate.set(totalOreEfectuate.toString());
                if(zileSalariu > 0)
                    brut.set(new Integer(totalOreEfectuate*salariu/(zileSalariu*oreNorma)).toString());
            }
            else
               brut.set(new Integer(zileSalariu*oreNorma).toString());

        } catch (SQLException ex) {
            Logger.getLogger(Zi.class.getName()).log(Level.SEVERE, null, ex);
        }
        return brut.get();
    }
    
    public String getNet() {
        Integer salariuBrut = new Integer(getBrut());
        
        ArrayList<String>attr = new ArrayList<>();
        attr.add("valoare");
        
        try {
            ArrayList<ArrayList<Object>> values = DataBaseConnection.getTableContent("constante", attr, "cheie IN ('asigurari sociale', 'ajutor somaj', 'asigurari sanatate', 'impozit')", null, null);
            float taxa = 0;
            for(ArrayList<Object> value: values)
                taxa += Float.parseFloat(value.get(0).toString());
            net.set((salariuBrut - taxa*salariuBrut/100)+"");
            
        } catch (SQLException ex) {
            Logger.getLogger(Zi.class.getName()).log(Level.SEVERE, null, ex);
        }
          return net.get();
    }
    
    public String getOresuplimentare() {
          Integer salariuBrut = new Integer(getBrut());
          return oresuplimentare.get();
    }
    
    public String getSuplimentar() {
          Integer totalOreSuplimentare = new Integer(getOresuplimentare());
          suplimentar.set(totalOreSuplimentare*7 + "");     
          return suplimentar.get();
    }
    
    public String getIdangajat() {
        return idangajat.get();
    }
    
    public void setIdangajat(String idproiect) {
        this.idangajat.set(idproiect);
    }
    
    
     @Override
    public ArrayList<String> getValues() {
        ArrayList<String> values = new ArrayList<>();
        values.add(id.get());
        values.add(data.get());
        values.add(oreefectuate.get());
        values.add(zileconcediu.get());
        values.add(brut.get());
        values.add(net.get());
        values.add(oresuplimentare.get());
        values.add(suplimentar.get());
        values.add(idangajat.get());
        return values;
    }
}
