/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package entities;

import java.util.ArrayList;
import javafx.beans.property.SimpleStringProperty;

public class Intrare extends Entity {
    final private SimpleStringProperty id, data, suma, idproiect;

    
    public Intrare(ArrayList<Object> contract) {
        this.id = new SimpleStringProperty(contract.get(0).toString());
        this.data = new SimpleStringProperty(contract.get(1).toString());
        this.suma = new SimpleStringProperty(contract.get(2).toString());
        this.idproiect = new SimpleStringProperty(contract.get(3).toString());
    }
    
    public String getIdfactura() {
        return id.get();
    }
    
    public String getData() {
        return data.get();
    }
    
    public void setData(String salariu) {
        this.data.set(salariu);
    }
    
    public String getSuma() {
        return suma.get();
    }
    
    public void setSuma(String salariu) {
        this.suma.set(salariu);
    }
    
    public String getIdproiect() {
        return idproiect.get();
    }
    
     public void setIdproiect(String idproiect) {
        this.idproiect.set(idproiect);
    }
    
    
     @Override
    public ArrayList<String> getValues() {
        ArrayList<String> values = new ArrayList<>();
        values.add(id.get());
        values.add(data.get());
        values.add(suma.get());
        values.add(idproiect.get());
        return values;
    }
}
