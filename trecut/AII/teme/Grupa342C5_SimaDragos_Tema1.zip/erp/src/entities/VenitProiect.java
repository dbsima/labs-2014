/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package entities;

import dataaccess.DataBaseConnection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleStringProperty;

public class VenitProiect extends Entity {
    final private SimpleStringProperty id, suma, denumire;

    
    public VenitProiect(ArrayList<Object> contract) {
        this.id = new SimpleStringProperty(contract.get(0).toString());
        this.suma = new SimpleStringProperty(contract.get(1).toString());
        this.denumire = new SimpleStringProperty(contract.get(2).toString());
    }
    
    public String getId() {
        return id.get();
    }
    
    public String getSuma() {
        ArrayList<String> attr = new ArrayList<>();
        attr.add("suma");
        Integer id = new Integer(getId());
        Integer totalSuma = 0;
        
        try {
            ArrayList<ArrayList<Object>> values = DataBaseConnection.getTableContent("intrari", attr, "idproiect = '"+id+"'", null, null);
            for(int i = 0; i < values.size(); i++)
                totalSuma += new Integer(values.get(i).get(0).toString());
            suma.set(totalSuma.toString());
        } catch (SQLException ex) {
            Logger.getLogger(Zi.class.getName()).log(Level.SEVERE, null, ex);
        }
        return suma.get();
    }
    
    public void setSuma(String salariu) {
        this.suma.set(salariu);
    }
    
    public String getDenumire() {
        ArrayList<String> attr = new ArrayList<>();
        attr.add("denumire");
        Integer id = new Integer(getId());
        
        try {
            ArrayList<ArrayList<Object>> values = DataBaseConnection.getTableContent("proiecte", attr, "idproiect = '"+id+"'", null, null);
            for(int i = 0; i < values.size(); i++)
                denumire.set(values.get(i).get(0).toString());

        } catch (SQLException ex) {
            Logger.getLogger(Zi.class.getName()).log(Level.SEVERE, null, ex);
        }
        return denumire.get();
    }
    
     public void setDenumire(String idproiect) {
        this.denumire.set(idproiect);
    }
    
    
     @Override
    public ArrayList<String> getValues() {
        ArrayList<String> values = new ArrayList<>();
        values.add(id.get());
        values.add(suma.get());
        values.add(denumire.get());
        return values;
    }
}
