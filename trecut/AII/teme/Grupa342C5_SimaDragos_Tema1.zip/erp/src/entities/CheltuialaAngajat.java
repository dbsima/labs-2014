/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package entities;

import dataaccess.DataBaseConnection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleStringProperty;
import org.joda.time.DateTime;
import org.joda.time.Days;

public class CheltuialaAngajat extends Entity {
    final private SimpleStringProperty id, suma, angajat;

    
    public CheltuialaAngajat(ArrayList<Object> contract) {
        this.id = new SimpleStringProperty(contract.get(0).toString());
        this.suma = new SimpleStringProperty(contract.get(1).toString());
        this.angajat = new SimpleStringProperty(contract.get(2).toString());
    }
    
    public String getId() {
        return id.get();
    }
    
    public Integer getZileconcediu() {
        ArrayList<String>attr = new ArrayList<>();
        attr.add("datainceput");
        attr.add("datasfarsit");
        
        String idAngajat = getId();
        Integer restDays = 0;
        
        try {
            // get the number of payd vacancy days
            ArrayList<ArrayList<Object>> values = DataBaseConnection.getTableContent("concedii", attr, "idangajat = '" + idAngajat + "' AND tip IN ('concediu de odihna', 'concediu medical', 'concediu motive speciale')", null, null);
            
            
            for (int i = 0; i < values.size(); i++) {       
                DateTime date1 = new DateTime(values.get(i).get(0));
                DateTime date2 = new DateTime(values.get(i).get(1));

                int days = Days.daysBetween(date1, date2).getDays() + 1;
                restDays += days;
            }
            return restDays;
        } catch (SQLException ex) {
            Logger.getLogger(Zi.class.getName()).log(Level.SEVERE, null, ex);
        }
        return restDays;
          
     }
    
    public String getSuma() {
        ArrayList<String>attr = new ArrayList<>();
        attr.add("ore");
        attr.add("salariu");
        
        String idAngajat = getId();
        
        Integer zileSalariu = new Integer(getZileconcediu());
        
        try {

            // get number of hours to do per day
            ArrayList<ArrayList<Object>> values = DataBaseConnection.getTableContent("contracte", attr, "idangajat = '" + idAngajat + "'", null, null);
            Integer oreNorma = new Integer(values.get(0).get(0).toString().split(":")[0]);
            Integer salariu = new Integer(values.get(0).get(1).toString());
            Integer minuteNorma = oreNorma*60;

            // 
            attr = new ArrayList<>();
            attr.add("orasosire");
            attr.add("oraplecare");
            attr.add("data");
            values = DataBaseConnection.getTableContent("activitati", attr, "idangajat = '" + idAngajat + "'", null, null);
            if(!values.isEmpty()) {
                Integer totalOreEfectuate = zileSalariu * oreNorma;
                Integer totalOreSuplimentare = 0;
                Integer minuteSuplimentare = 0;
                
                for(ArrayList<Object> value: values) {
                    zileSalariu++;
                    Integer oraSosire = new Integer(value.get(0).toString().split(":")[0]);
                    Integer minutSosire = new Integer(value.get(0).toString().split(":")[1]);
                    
                    Integer oraPlecare = new Integer(value.get(1).toString().split(":")[0]);
                    Integer minutPlecare = new Integer(value.get(1).toString().split(":")[1]);
                    
                    Integer minuteEfectuate = new Integer((oraPlecare - oraSosire)*60 + minutPlecare - minutSosire);
                    if (minuteEfectuate >= minuteNorma){
                        totalOreEfectuate += oreNorma;
                        totalOreSuplimentare += (minuteEfectuate - minuteNorma)/60;
                    }
                    else
                        totalOreEfectuate += minuteEfectuate/60;
                }

                if(zileSalariu > 0)
                    suma.set(new Integer(totalOreSuplimentare*7 + totalOreEfectuate*salariu/(zileSalariu*oreNorma)).toString());
            }
            else
               suma.set(new Integer(zileSalariu*oreNorma).toString());

        } catch (SQLException ex) {
            Logger.getLogger(Zi.class.getName()).log(Level.SEVERE, null, ex);
        }
        return suma.get();
    }
    
    public void setSuma(String salariu) {
        this.suma.set(salariu);
    }
    
    public String getAngajat() {
        ArrayList<String> attr = new ArrayList<>();
        attr.add("nume");
        attr.add("prenume");
        Integer id = new Integer(getId());
        
        try {
            ArrayList<ArrayList<Object>> values = DataBaseConnection.getTableContent("angajati", attr, "idangajat = '"+id+"'", null, null);
            for(int i = 0; i < values.size(); i++)
                angajat.set(values.get(i).get(0).toString()+" "+ values.get(i).get(1).toString());

        } catch (SQLException ex) {
            Logger.getLogger(Zi.class.getName()).log(Level.SEVERE, null, ex);
        }
        return angajat.get();
    }
    
     public void setAngajat(String idproiect) {
        this.angajat.set(idproiect);
    }
    
    
     @Override
    public ArrayList<String> getValues() {
        ArrayList<String> values = new ArrayList<>();
        values.add(id.get());
        values.add(suma.get());
        values.add(angajat.get());
        return values;
    }
}
