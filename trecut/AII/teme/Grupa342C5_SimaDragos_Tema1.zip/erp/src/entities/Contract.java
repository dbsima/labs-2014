/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package entities;

import java.util.ArrayList;
import javafx.beans.property.SimpleStringProperty;

public class Contract extends Entity {
    final private SimpleStringProperty id, salariu, ore, idangajat;
    
    public Contract(ArrayList<Object> contract) {
        this.id = new SimpleStringProperty(contract.get(0).toString());
        this.salariu = new SimpleStringProperty(contract.get(1).toString());
        this.ore = new SimpleStringProperty(contract.get(2).toString());
        this.idangajat = new SimpleStringProperty(contract.get(3).toString());      
    }
    
    public String getIdcontract() {
        return id.get();
    }
    
    public String getSalariu() {
        return salariu.get();
    }
    
    public void setSalariu(String salariu) {
        this.salariu.set(salariu);
    }
    
    public String getOre() {
        return ore.get();
    }
    
    public void setOre(String ore) {
        this.ore.set(ore);
    }
    
    public String getIdangajat() {
        return idangajat.get();
    }
    
    public void setIdangajat(String idangajat) {
        this.idangajat.set(idangajat);
    }
    
     @Override
    public ArrayList<String> getValues() {
        ArrayList<String> values = new ArrayList<>();
        values.add(id.get());
        values.add(salariu.get());
        values.add(ore.get());
        values.add(idangajat.get());
        return values;
    }
}
