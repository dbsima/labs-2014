/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package entities;

import dataaccess.DataBaseConnection;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleStringProperty;

public class Activitate extends Entity {
    final private SimpleStringProperty idactivitate, data, orasosire, oraplecare, intarziere, timpextra, timpsuplimentar, observatii, idangajat;
    
    final private String role;
    
    public Activitate(ArrayList<Object> activitate, String role) {
        this.idactivitate = new SimpleStringProperty(activitate.get(0).toString());
        this.data = new SimpleStringProperty(activitate.get(1).toString());
        this.orasosire = new SimpleStringProperty(activitate.get(2).toString());
        this.oraplecare = new SimpleStringProperty(activitate.get(3).toString());
        this.intarziere = new SimpleStringProperty(activitate.get(4).toString());
        this.timpextra = new SimpleStringProperty(activitate.get(5).toString());
        this.timpsuplimentar = new SimpleStringProperty(activitate.get(6).toString());
        this.observatii = new SimpleStringProperty(activitate.get(7).toString());
        this.idangajat = new SimpleStringProperty(activitate.get(8).toString());
    
        this.role = role;
    }
    
    public String getIdactivitate() {
        return idactivitate.get();
    }
    
    public String getData() {
        return data.get();
    }
    
    public void setData(String iddep) {
        this.data.set(iddep);
    }
    
    public String getOrasosire() {
        return orasosire.get();
    }
    
    public void setOrasosire(String iddep) {
        this.orasosire.set(iddep);
    }
    
    public String getOraplecare() {
        return oraplecare.get();
    }
    
    public void setOraplecare(String iddep) {
        this.oraplecare.set(iddep);
    }

    public String getIntarziere() {
       ArrayList<String> attr = new ArrayList<>();
        attr.add("valoare");

        try {
            ArrayList<ArrayList<Object>> values = DataBaseConnection.getTableContent("constante", attr, "cheie = 'orainceput'", null, null);

            Time ora_inceput = new Time(new Integer(values.get(0).get(0).toString()), 0, 0);

            Integer ora = new Integer(orasosire.get().split(":")[0]);
            Integer minute = new Integer(orasosire.get().split(":")[1]);
            Time ora_sosire = new Time(ora, minute, 0);
            if (ora_sosire.compareTo(ora_inceput) > 0)
                intarziere.set(new Integer((ora_sosire.getHours() - ora_inceput.getHours())*60 + ora_sosire.getMinutes() - ora_inceput.getMinutes()).toString());
        } catch (SQLException ex) {
            Logger.getLogger(Activitate.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return intarziere.get();
    }

    public String getTimpextra() {
        ArrayList<String> attr = new ArrayList<>();
        attr.add("valoare");
        
        try {
            ArrayList<ArrayList<Object>> values = DataBaseConnection.getTableContent("constante", attr, "cheie = 'orasfarsit'", null, null);
            Time ora_sfarsit = new Time(new Integer(values.get(0).get(0).toString()), 0, 0);

            Integer ora = new Integer(oraplecare.get().split(":")[0]);
            Integer minute = new Integer(oraplecare.get().split(":")[1]);
            Time ora_plecare = new Time(ora, minute, 0);
            if (ora_plecare.compareTo(ora_sfarsit) > 0)
                timpextra.set(new Integer((ora_plecare.getHours() - ora_sfarsit.getHours())*60 + ora_plecare.getMinutes() - ora_sfarsit.getMinutes()).toString());
        } catch (SQLException ex) {
            Logger.getLogger(Activitate.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return timpextra.get();
    }

    public String getTimpsuplimentar () {
        ArrayList<String> attr = new ArrayList<>();
        attr.add("ore");
        
        String idAngajat = role.split("_")[2];
        if(role.contains("RU_"))
            idAngajat = getIdangajat();
        try {
            ArrayList<ArrayList<Object>> values = DataBaseConnection.getTableContent("contracte", attr, "idangajat = '" + idAngajat + "'", null, null);
            Integer ore = new Integer(values.get(0).get(0).toString().split(":")[0]);

            Integer ora = new Integer(orasosire.get().split(":")[0]);
            Integer minute = new Integer(orasosire.get().split(":")[1]);
            Time ora_sosire = new Time(ora, minute, 0);
            
            ora = new Integer(oraplecare.get().split(":")[0]);
            minute = new Integer(oraplecare.get().split(":")[1]);
            Time ora_plecare = new Time(ora, minute, 0);
            
            Integer timp = new Integer((ora_plecare.getHours() - ore - ora_sosire.getHours())*60 + ora_plecare.getMinutes() - ora_sosire.getMinutes());
            if (timp > 0)
                timpsuplimentar.set(timp.toString());
        } catch (SQLException ex) {
            Logger.getLogger(Activitate.class.getName()).log(Level.SEVERE, null, ex);
        }
        return timpsuplimentar.get();
    }
    
    public String getObservatii () {
        ArrayList<String> attr = new ArrayList<>();
        attr.add("ore");
        
        String idAngajat = role.split("_")[2];
        if(role.contains("RU_"))
            idAngajat = getIdangajat();
        try {
            ArrayList<ArrayList<Object>> values = DataBaseConnection.getTableContent("contracte", attr, "idangajat = '" + idAngajat + "'", null, null);
            Integer ore = new Integer(values.get(0).get(0).toString().split(":")[0]);

            Integer ora = new Integer(orasosire.get().split(":")[0]);
            Integer minute = new Integer(orasosire.get().split(":")[1]);
            Time ora_sosire = new Time(ora, minute, 0);
            
            ora = new Integer(oraplecare.get().split(":")[0]);
            minute = new Integer(oraplecare.get().split(":")[1]);
            Time ora_plecare = new Time(ora, minute, 0);
            
            Integer timp = new Integer((ora_plecare.getHours() - ore - ora_sosire.getHours())*60 + ora_plecare.getMinutes() - ora_sosire.getMinutes());
            if (timp < 0)
                observatii.set("norma neindeplinita: " + timp.toString() + "m");
        } catch (SQLException ex) {
            Logger.getLogger(Activitate.class.getName()).log(Level.SEVERE, null, ex);
        }
        return observatii.get();
    }
    
    public String getIdangajat() {
        return idangajat.get();
    }
    
    public void setIdangajat(String iddep) {
        this.idangajat.set(iddep);
    }
    
    @Override
    public ArrayList<String> getValues() {
        ArrayList<String> values = new ArrayList<>();
        values.add(idactivitate.get());
        values.add(data.get());
        values.add(orasosire.get());
        values.add(oraplecare.get());
        values.add(intarziere.get());
        values.add(timpextra.get());
        values.add(timpsuplimentar.get());
        values.add(observatii.get());
        values.add(idangajat.get());        
        return values;
    }
}
