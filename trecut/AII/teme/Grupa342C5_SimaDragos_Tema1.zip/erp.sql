DROP DATABASE erp;

CREATE DATABASE erp;

USE erp;

/* tabela ce descrie contractul unui angajat */
CREATE TABLE contracte (
	idcontract	INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY NOT NULL,
	salariu	    INT(10) NOT NULL,
	ore		    INT(10) NOT NULL,
    idangajat	INT(10) UNSIGNED NOT NULL
);
ALTER TABLE contracte ADD CONSTRAINT sal_chk CHECK (sal_per_ora>=0);
ALTER TABLE contracte ADD CONSTRAINT ore_chk CHECK (nr_ore>0);


/* tabela ce descrie concediul unui angajat */
CREATE TABLE concedii (
	idconcediu	    INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY NOT NULL,
	tip 		    VARCHAR(30) NOT NULL,
	datainceput	    DATE NOT NULL,
	datasfarsit	    DATE NOT NULL,
	idangajat	    INT(10) UNSIGNED NOT NULL
);
ALTER TABLE concedii ADD CONSTRAINT tip_chk CHECK (tip IN ('concediu de odihna', 'concediu medical', 'concediu fara plata', 'concediu motive speciale'));

/* tabela ce descrie zilele de concediu ale unui angajat */
CREATE TABLE zile (
	idzi	        INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY NOT NULL,
    ramase          INT(10) UNSIGNED DEFAULT 0,
	odihna          INT(10) UNSIGNED DEFAULT 0,
    medical         INT(10) UNSIGNED DEFAULT 0,
	faraplata       INT(10) UNSIGNED DEFAULT 0,
	motivespeciale  INT(10) UNSIGNED DEFAULT 0,
	idangajat	    INT(10) UNSIGNED NOT NULL
);

/* tabela ce descrie o echipa */
CREATE TABLE echipe (
	idechipa	    INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY NOT NULL,
	denumire	    VARCHAR(30) NOT NULL,
	idresponsabil	INT(10) UNSIGNED NOT NULL,
	iddepartament	INT(10) UNSIGNED NOT NULL,
    idproiect       INT(10) UNSIGNED NOT NULL
);

CREATE TABLE componente (
	id  	    INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY NOT NULL,
    datainceput DATE NOT NULL,
	datasfarsit	DATE NOT NULL,
	idmembru	INT(10) UNSIGNED UNIQUE KEY NOT NULL,
	idechipa	INT(10) UNSIGNED NOT NULL
);


/* tabela ce descrie un departament */
CREATE TABLE departamente (
	iddepartament INT(10) UNSIGNED PRIMARY KEY NOT NULL,
	denumire VARCHAR(30) NOT NULL,
	idresponsabil INT(10) UNSIGNED NOT NULL			
);


/* tabela ce descrie un angajat */
CREATE TABLE angajati (
	idangajat          INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY NOT NULL,
	CNP             BIGINT(13) UNSIGNED UNIQUE KEY NOT NULL,
	nume            VARCHAR(30) NOT NULL,
	prenume         VARCHAR(30) NOT NULL,
	adresa          VARCHAR(100) NOT NULL,
	telefon         INT(10),
	email           VARCHAR(60) NOT NULL,
	IBAN            VARCHAR(100) NOT NULL,
	functie         VARCHAR(30) NOT NULL,
	dataang         DATE NOT NULL,
	numeutilizator  VARCHAR(30) NOT NULL,
	parola          VARCHAR(30) NOT NULL,
	iddep           INT(10) UNSIGNED
);
ALTER TABLE angajati ADD CONSTRAINT email_chk CHECK (email LIKE '%@%.%');


/* tabela ce descrie un proiect */
CREATE TABLE proiecte (
	idproiect	INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY NOT NULL,
	denumire	VARCHAR(30) NOT NULL,
	descriere	VARCHAR(1000)
);


/* tabela ce descrie versiunea unui proiect */
CREATE TABLE versiuni (
	idversiune	INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY NOT NULL,
	denumire	VARCHAR(30) NOT NULL,
	deadline	DATE NOT NULL,
	idproiect	INT(10) UNSIGNED NOT NULL
);


/* tabela ce descrie defectele unei versiuni */
CREATE TABLE defecte (
	iddefect	        INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY NOT NULL,
	denumire	        VARCHAR(30) NOT NULL,
    severitate	        INT(10) NOT NULL,
    descriere	        VARCHAR(30) NOT NULL,
    reproductibilitate	VARCHAR(30) NOT NULL,
    statut	            VARCHAR(30) NOT NULL,
    rezultat	        VARCHAR(30) NOT NULL,
    comentarii      	VARCHAR(30) NOT NULL,
	datamodif	        DATE NOT NULL,
	idversiune	        INT(10) UNSIGNED NOT NULL,
    idangajat	        INT(10) UNSIGNED NOT NULL
);
ALTER TABLE defecte ADD CONSTRAINT sev_chk CHECK (severitate IN (1, 2, 3, 4, 5, 6, 7, 8));
ALTER TABLE defecte ADD CONSTRAINT statut_chk CHECK (statut IN ('neanalizat', 'nu poate fi reprodus', 'nu este defect', 'nu va fi corectat', 'corectat', 'nu poate fi corectat', 'corectat', 'trebuie sa fie corectat'));
ALTER TABLE defecte ADD CONSTRAINT rez_chk CHECK (rezultat IN ('nou', 'verificat', 'necorectat'));


/* tabela ce descrie activitatea unui angajat */
CREATE TABLE activitati (
	idactivitate	INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY NOT NULL,
    data            DATE NOT NULL,
	orasosire	    TIME NOT NULL,
	oraplecare	    TIME NOT NULL,
    intarziere      INT(10) DEFAULT 0,
    timpextra       INT(10) DEFAULT 0,
    timpsuplimentar INT(10) DEFAULT 0,
    observatii      VARCHAR(30) DEFAULT "",
	idangajat	    INT(10) UNSIGNED NOT NULL
);


/* tabela ce descrie intrarile companiei */
CREATE TABLE intrari (
	idfactura	INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY NOT NULL,
	data		DATE NOT NULL,
    suma        INT(10),
	idproiect	INT(10) UNSIGNED NOT NULL
);

/* tabela ce descrie bilantul lunar */
CREATE TABLE profitluna (
	id	        INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY NOT NULL,
	data		DATE NOT NULL,
    suma        INT(10) DEFAULT 0
);

/* tabela ce descrie veniturile per proiect */
CREATE TABLE venitproiecte (
	id          INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY NOT NULL,
    suma        INT(10) DEFAULT 0,
	denumire	VARCHAR(30) DEFAULT ""
);

/* tabela ce descrie salariile unei companii */
CREATE TABLE salarii (
	idfactura	    INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY NOT NULL,
	data		    DATE NOT NULL,
    oreefectuate    INT(10) UNSIGNED DEFAULT 0,
    zileconcediu    INT(10) UNSIGNED DEFAULT 0, 
    brut            FLOAT DEFAULT 0,
    net             FLOAT DEFAULT 0,
    oresuplimentare INT(10) UNSIGNED DEFAULT 0,
    suplimentar     FLOAT DEFAULT 0,
	idangajat	    INT(10) UNSIGNED NOT NULL
);

/* tabela ce descrie cheltuielile per angajat */
CREATE TABLE cheltuieliangajat (
	id	        INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY NOT NULL,
	suma        FLOAT DEFAULT 0,
    angajat	    VARCHAR(30) DEFAULT ""
);

/* tabela ce descrie cheltuielile per departament */
CREATE TABLE cheltuielidepartament (
	id          INT(10) UNSIGNED PRIMARY KEY NOT NULL,
    suma        INT(10) DEFAULT 0,
	denumire	VARCHAR(30) DEFAULT ""
);


   
/* tabela ce descrie constantele necesare customizarii aplicatiei */
CREATE TABLE constante (
	idconstanta	INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY NOT NULL,
	cheie		VARCHAR(30) NOT NULL,
	valoare	    FLOAT UNSIGNED NOT NULL
);

ALTER TABLE concedii ADD FOREIGN KEY (idangajat) REFERENCES angajati (idangajat) ON UPDATE CASCADE ON DELETE CASCADE;

ALTER TABLE echipe ADD CONSTRAINT echipefk1 FOREIGN KEY (idresponsabil) REFERENCES angajati (idangajat) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE echipe ADD CONSTRAINT echipefk2 FOREIGN KEY (iddepartament) REFERENCES departamente (iddepartament) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE echipe ADD CONSTRAINT echipefk3 FOREIGN KEY (idproiect) REFERENCES proiecte (idproiect) ON UPDATE CASCADE ON DELETE CASCADE;	

ALTER TABLE componente ADD CONSTRAINT compfk1 FOREIGN KEY (idmembru) REFERENCES angajati (idangajat) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE componente ADD CONSTRAINT compfk2 FOREIGN KEY (idechipa) REFERENCES echipe (idechipa) ON UPDATE CASCADE ON DELETE CASCADE;


ALTER TABLE angajati ADD CONSTRAINT utilfk2 FOREIGN KEY (iddep) REFERENCES departamente (iddepartament) ON UPDATE CASCADE ON DELETE CASCADE;


ALTER TABLE versiuni ADD CONSTRAINT versfk1 FOREIGN KEY (idproiect) REFERENCES proiecte (idproiect) ON UPDATE CASCADE ON DELETE CASCADE;

ALTER TABLE defecte ADD CONSTRAINT defectfk1 FOREIGN KEY (idversiune) REFERENCES versiuni (idversiune) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE defecte ADD CONSTRAINT defectfk2 FOREIGN KEY (idangajat) REFERENCES angajati (idangajat) ON UPDATE CASCADE ON DELETE CASCADE;

ALTER TABLE activitati ADD CONSTRAINT activfk FOREIGN KEY (idangajat) REFERENCES angajati (idangajat) ON UPDATE CASCADE ON DELETE CASCADE;

ALTER TABLE intrari ADD CONSTRAINT intrarifk FOREIGN KEY (idproiect) REFERENCES proiecte (idproiect) ON UPDATE CASCADE ON DELETE CASCADE;

ALTER TABLE salarii ADD CONSTRAINT salariifk FOREIGN KEY (idangajat) REFERENCES angajati (idangajat) ON UPDATE CASCADE ON DELETE CASCADE;

ALTER TABLE contracte ADD CONSTRAINT contractefk FOREIGN KEY (idangajat) REFERENCES angajati (idangajat) ON UPDATE CASCADE ON DELETE CASCADE;



INSERT INTO departamente (iddepartament, denumire, idresponsabil)
    VALUES(0, 'administrare', 2);
INSERT INTO departamente (iddepartament, denumire, idresponsabil)
    VALUES(1, 'resurse umane', 5);
INSERT INTO departamente (iddepartament, denumire, idresponsabil)
    VALUES(2, 'contabilitate', 7);
INSERT INTO departamente (iddepartament, denumire, idresponsabil)
    VALUES(3, 'programare', 9);
INSERT INTO departamente (iddepartament, denumire, idresponsabil)
    VALUES(4, 'asigurarea calitatii', 12);

/* administratie  */
INSERT INTO angajati (CNP, nume, prenume, adresa, telefon, email, IBAN, functie, dataang, numeutilizator, parola, iddep)
    VALUES('1220713379377', 'SIMA', 'Dragos', '-', '0', 'dbsima@google.com', 'RO123', 'admin', '2008-1-1', 'dragos.sima', '-', 0);
INSERT INTO angajati (CNP, nume, prenume, adresa, telefon, email, IBAN, functie, dataang, numeutilizator, parola, iddep)
    VALUES('1220713379375', 'COJOCARU', 'Andrei', '-', '0', 'andreicojocaru@google.com', 'RO124', 'superadmin', '2008-1-1', 'andrei.cojocaru', '-', 0);
INSERT INTO angajati (CNP, nume, prenume, adresa, telefon, email, IBAN, functie, dataang, numeutilizator, parola, iddep)
    VALUES('1220713379371', 'PITAC', 'Alexandru', '-', '0', 'apitac@google.com', 'RO131', 'admin', '2008-1-1', 'alex.pitac', '-', 0);
INSERT INTO angajati (CNP, nume, prenume, adresa, telefon, email, IBAN, functie, dataang, numeutilizator, parola, iddep)
    VALUES('1220613379376', 'PETCU', 'Ovidiu', '-', '0', 'opetcu@google.com', 'RO132', 'admin', '2008-1-1', 'petcu', '-', 0);

/* resurse umane */
INSERT INTO angajati (CNP, nume, prenume, adresa, telefon, email, IBAN, functie, dataang, numeutilizator, parola, iddep)
    VALUES('1220713379391', 'BRAILA', 'Viorica', '-', '0', 'viorica.braila@google.com', 'RO139', 'director HR', '2008-1-1', 'vio.br', '-', 1);
INSERT INTO angajati (CNP, nume, prenume, adresa, telefon, email, IBAN, functie, dataang, numeutilizator, parola, iddep)
    VALUES('1220713379392', 'GALATI', 'Viorica', '-', '0', 'viorica.galati@google.com', 'RO140', 'recruiter', '2008-1-1', 'vio.gl', '-', 1);

/* contabilitate */
INSERT INTO angajati (CNP, nume, prenume, adresa, telefon, email, IBAN, functie, dataang, numeutilizator, parola, iddep)
    VALUES('1220713379389', 'DOLAR', 'Jim', '-', '0', 'jim.dolar@google.com', 'RO137', 'contabil', '2008-1-1', 'jim.dolar', '-', 2);
INSERT INTO angajati (CNP, nume, prenume, adresa, telefon, email, IBAN, functie, dataang, numeutilizator, parola, iddep)
    VALUES('1220713379390', 'EURO', 'Viorica', '-', '0', 'viorica.euro@google.com', 'RO138', 'contabil sef', '2008-1-1', 'vio.euro', '-', 2);

/* programare */
INSERT INTO angajati (CNP, nume, prenume, adresa, telefon, email, IBAN, functie, dataang, numeutilizator, parola, iddep)
    VALUES('1220713379379', 'CHITAC', 'Marin', '-', '0', 'marin.chitac@google.com', 'RO120', 'programator', '2008-1-1', 'chitac.marin', '-', 3);
INSERT INTO angajati (CNP, nume, prenume, adresa, telefon, email, IBAN, functie, dataang, numeutilizator, parola, iddep)
    VALUES('1220713379368', 'PICIORAS', 'Marin', '-', '0', 'marin.picior@google.com', 'RO135', 'software engineer', '2008-1-1', 'marin.picior', '-', 3);
INSERT INTO angajati (CNP, nume, prenume, adresa, telefon, email, IBAN, functie, dataang, numeutilizator, parola, iddep)
    VALUES('1220713379369', 'MANUTA', 'Marin', '-', '0', 'marin.mana@google.com', 'RO136', 'programantor ajutor', '2008-1-1', 'marin.mana', '-', 3);

/* asigurarea calitatii */
INSERT INTO angajati (CNP, nume, prenume, adresa, telefon, email, IBAN, functie, dataang, numeutilizator, parola, iddep)
    VALUES('1220713379378', 'ZOTA', 'Daniel', '-', '0', 'zota.daniel@google.com', 'RO122', 'analist IT', '2008-1-1', 'zota.daniel', '-', 4);
INSERT INTO angajati (CNP, nume, prenume, adresa, telefon, email, IBAN, functie, dataang, numeutilizator, parola, iddep)
    VALUES('1220713379332', 'CIOCAN', 'Daniel', '-', '0', 'danielcioc@yahoo.com', 'RO133', 'QA engineer', '2008-1-1', 'daniel.ciocan', '-', 4);
INSERT INTO angajati (CNP, nume, prenume, adresa, telefon, email, IBAN, functie, dataang, numeutilizator, parola, iddep)
    VALUES('1220713379334', 'NICOVALA', 'Daniel', '-', '0', 'danielnico@yahoo.com', 'RO134', 'PM', '2008-1-1', 'daniel.nicovala', '-', 4);


INSERT INTO contracte (salariu, ore, idangajat)
    VALUES(1000, 8, 1);
INSERT INTO contracte (salariu, ore, idangajat)
    VALUES(1200, 10, 2);
INSERT INTO contracte (salariu, ore, idangajat)
    VALUES(1300, 10, 3);
INSERT INTO contracte (salariu, ore, idangajat)
    VALUES(1100, 5, 4);
INSERT INTO contracte (salariu, ore, idangajat)
    VALUES(1000, 8, 5);
INSERT INTO contracte (salariu, ore, idangajat)
    VALUES(1200, 10, 6);
INSERT INTO contracte (salariu, ore, idangajat)
    VALUES(1300, 10, 7);
INSERT INTO contracte (salariu, ore, idangajat)
    VALUES(1100, 5, 8);
INSERT INTO contracte (salariu, ore, idangajat)
    VALUES(1000, 8, 9);
INSERT INTO contracte (salariu, ore, idangajat)
    VALUES(1200, 10, 10);
INSERT INTO contracte (salariu, ore, idangajat)
    VALUES(1300, 10, 11);
INSERT INTO contracte (salariu, ore, idangajat)
    VALUES(1100, 5, 12);
INSERT INTO contracte (salariu, ore, idangajat)
    VALUES(1000, 8, 13);
INSERT INTO contracte (salariu, ore, idangajat)
    VALUES(1200, 10, 14);

/* concedii */
INSERT INTO concedii (tip, datainceput, datasfarsit, idangajat)
    VALUES ('concediu medical', '2008-8-5', '2008-8-10', 1);

INSERT INTO concedii (tip, datainceput, datasfarsit, idangajat)
    VALUES ('concediu fara plata', '2008-7-5', '2008-7-5', 9);
INSERT INTO concedii (tip, datainceput, datasfarsit, idangajat)
    VALUES ('concediu fara plata', '2008-7-21', '2008-7-21', 9);
INSERT INTO concedii (tip, datainceput, datasfarsit, idangajat)
    VALUES ('concediu medical', '2008-8-5', '2008-8-7', 9);
INSERT INTO concedii (tip, datainceput, datasfarsit, idangajat)
    VALUES ('concediu medical', '2008-9-1', '2008-9-3', 9);
INSERT INTO concedii (tip, datainceput, datasfarsit, idangajat)
    VALUES ('concediu de odihna', '2008-9-15', '2008-9-17', 9);
INSERT INTO concedii (tip, datainceput, datasfarsit, idangajat)
    VALUES ('concediu de odihna', '2008-10-5', '2008-10-7', 9);
INSERT INTO concedii (tip, datainceput, datasfarsit, idangajat)
    VALUES ('concediu motive speciale', '2008-10-22', '2008-10-25', 9);
INSERT INTO concedii (tip, datainceput, datasfarsit, idangajat)
    VALUES ('concediu motive speciale', '2008-8-5', '2008-8-5', 9);

INSERT INTO concedii (tip, datainceput, datasfarsit, idangajat)
    VALUES ('concediu de odihna', '2008-12-5', '2008-12-10', 6);

INSERT INTO concedii (tip, datainceput, datasfarsit, idangajat)
    VALUES ('concediu medical', '2008-8-5', '2008-8-10', 7);
INSERT INTO concedii (tip, datainceput, datasfarsit, idangajat)
    VALUES ('concediu medical', '2008-9-5', '2008-9-10', 7);
INSERT INTO concedii (tip, datainceput, datasfarsit, idangajat)
    VALUES ('concediu de odihna', '2008-10-5', '2008-10-10', 7);

INSERT INTO concedii (tip, datainceput, datasfarsit, idangajat)
    VALUES ('concediu medical', '2008-8-5', '2008-8-10', 8);

INSERT INTO concedii (tip, datainceput, datasfarsit, idangajat)
    VALUES ('concediu medical', '2008-8-5', '2008-8-10', 5);
INSERT INTO concedii (tip, datainceput, datasfarsit, idangajat)
    VALUES ('concediu medical', '2008-8-29', '2008-9-1', 5);
INSERT INTO concedii (tip, datainceput, datasfarsit, idangajat)
    VALUES ('concediu de odihna', '2008-9-5', '2008-9-10', 5);

INSERT INTO concedii (tip, datainceput, datasfarsit, idangajat)
    VALUES ('concediu medical', '2008-8-5', '2008-8-10', 10);
INSERT INTO concedii (tip, datainceput, datasfarsit, idangajat)
    VALUES ('concediu medical', '2008-9-5', '2008-9-10', 10);
INSERT INTO concedii (tip, datainceput, datasfarsit, idangajat)
    VALUES ('concediu de odihna', '2008-10-5', '2008-10-10', 10);

INSERT INTO concedii (tip, datainceput, datasfarsit, idangajat)
    VALUES ('concediu medical', '2008-8-5', '2008-8-10', 11);

INSERT INTO concedii (tip, datainceput, datasfarsit, idangajat)
    VALUES ('concediu medical', '2008-9-5', '2008-9-10', 12);
INSERT INTO concedii (tip, datainceput, datasfarsit, idangajat)
    VALUES ('concediu de odihna', '2008-12-5', '2008-12-10', 12);

INSERT INTO concedii (tip, datainceput, datasfarsit, idangajat)
    VALUES ('concediu medical', '2008-8-5', '2008-8-10', 13);

INSERT INTO concedii (tip, datainceput, datasfarsit, idangajat)
    VALUES ('concediu medical', '2008-8-5', '2008-8-10', 14);
INSERT INTO concedii (tip, datainceput, datasfarsit, idangajat)
    VALUES ('concediu de odihna', '2008-9-5', '2008-9-10', 14);

/* tabela ce descrie numarul de zile de concediu al unui angajat */
INSERT INTO zile (idangajat) VALUES (5);
INSERT INTO zile (idangajat) VALUES (6);
INSERT INTO zile (idangajat) VALUES (7);
INSERT INTO zile (idangajat) VALUES (8);
INSERT INTO zile (idangajat) VALUES (9);
INSERT INTO zile (idangajat) VALUES (10);
INSERT INTO zile (idangajat) VALUES (11);
INSERT INTO zile (idangajat) VALUES (12);
INSERT INTO zile (idangajat) VALUES (13);
INSERT INTO zile (idangajat) VALUES (14);

INSERT INTO proiecte (denumire, descriere)
    VALUES ('RosiaMonatana', 'website rosiamontana.ro');
INSERT INTO proiecte (denumire, descriere)
    VALUES ('RMGC', 'website rmgc.ro');

INSERT INTO versiuni (denumire, deadline, idproiect)
    VALUES ('0.0.0.1', '2008-1-6', 1);
INSERT INTO  versiuni (denumire, deadline, idproiect)
    VALUES ('1.0.0.1', '2008-8-6', 1);
INSERT INTO versiuni (denumire, deadline, idproiect)
    VALUES ('0.0.0.1', '2008-1-6', 2);
INSERT INTO  versiuni (denumire, deadline, idproiect)
    VALUES ('0.0.0.2', '2008-2-6', 2);
INSERT INTO versiuni (denumire, deadline, idproiect)
    VALUES ('0.0.1.1', '2008-3-6', 2);
INSERT INTO  versiuni (denumire, deadline, idproiect)
    VALUES ('1.0.0.1', '2008-4-6', 2);
INSERT INTO  versiuni (denumire, deadline, idproiect)
    VALUES ('1.0.1.0', '2008-4-6', 2);
INSERT INTO  versiuni (denumire, deadline, idproiect)
    VALUES ('2.0.0.1', '2008-4-6', 2);

/* echipe programare */
INSERT INTO echipe (denumire, idresponsabil, iddepartament, idproiect)
    VALUES ('programare1', 11, 3, 1);
INSERT INTO echipe (denumire, idresponsabil, iddepartament, idproiect)
    VALUES ('programare2', 10, 3, 2);

/* componenta echipa programare 1 */
INSERT INTO componente (datainceput, datasfarsit, idmembru, idechipa)
    VALUES ('2008-8-6', '2008-9-5', 9, 1);
INSERT INTO componente (datainceput, datasfarsit, idmembru, idechipa)
    VALUES ('2008-8-6', '2008-9-5', 11, 1);

/* componenta echipa programare 2 */
INSERT INTO componente (datainceput, datasfarsit, idmembru, idechipa)
    VALUES ('2008-8-6', '2008-9-5', 10, 2);



/* echipe asigurarea calitatii */
INSERT INTO echipe (denumire, idresponsabil, iddepartament, idproiect)
    VALUES ('qa3', 13, 4, 2);
INSERT INTO echipe (denumire, idresponsabil, iddepartament, idproiect)
    VALUES ('qa4', 14, 4, 2);

/* componenta echipa qa 1 */
INSERT INTO componente (datainceput, datasfarsit, idmembru, idechipa)
    VALUES ('2008-8-6', '2008-9-5', 12, 4);
INSERT INTO componente (datainceput, datasfarsit, idmembru, idechipa)
    VALUES ('2008-8-6', '2008-9-5', 14, 4);



INSERT INTO defecte (denumire, severitate, descriere, reproductibilitate, statut, rezultat, comentarii, datamodif, idversiune, idangajat) VALUES ('[F][B] error line 10', 1, '-', '-', 'neanalizat', 'defect nou', '-', '2008-1-3', 1, 1);
INSERT INTO defecte (denumire, severitate, descriere, reproductibilitate, statut, rezultat, comentarii, datamodif, idversiune, idangajat) VALUES ('[F][B] error line 11', 2, '-', '-', 'neanalizat', 'defect nou', '-', '2008-5-3', 1, 1);
INSERT INTO defecte (denumire, severitate, descriere, reproductibilitate, statut, rezultat, comentarii, datamodif, idversiune, idangajat) VALUES ('[F][B] login bad url', 3, '-', '-', 'neanalizat', 'defect nou', '-', '2008-6-3', 4, 14);
INSERT INTO defecte (denumire, severitate, descriere, reproductibilitate, statut, rezultat, comentarii, datamodif, idversiune, idangajat) VALUES ('[F][B] error line 323', 3, '-', '-', 'neanalizat', 'defect nou', '-', '2008-7-3', 4, 14);


/* activitati */

/* activitati 5 */
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-2', '9:00', '18:00', 5);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-3', '9:00', '18:00', 5);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-4', '9:00', '18:00', 5);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-11', '9:00', '18:00', 5);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-12', '9:00', '18:00', 5);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-13', '9:00', '18:00', 5);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-14', '9:00', '18:00', 5);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-15', '9:00', '18:00', 5);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-16', '9:00', '18:00', 5);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-17', '9:00', '18:00', 5);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-18', '9:00', '18:00', 5);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-19', '9:00', '18:00', 5);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-20', '9:00', '18:00', 5);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-21', '9:00', '18:00', 5);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-22', '9:00', '18:00', 5);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-23', '9:00', '18:00', 5);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-24', '9:00', '18:00', 5);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-25', '9:00', '18:00', 5);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-26', '9:00', '18:00', 5);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-27', '9:00', '18:00', 5);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-28', '9:00', '18:00', 5);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-29', '9:00', '18:00', 5);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-30', '9:00', '18:00', 5);

/* activitati 6 */
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-6', '9:00', '18:00', 6);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-7', '9:00', '18:00', 6);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-8', '9:00', '18:00', 6);
/* activitati 7 */
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-6', '9:00', '18:00', 7);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-7', '9:00', '18:00', 7);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-8', '9:00', '18:00', 7);
/* activitati 8 */
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-6', '9:00', '18:00', 8);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-7', '9:00', '18:00', 8);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-8', '9:00', '18:00', 8);
/* activitati 9 */
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-01-6', '9:15', '18:00', 9);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-01-7', '9:00', '18:20', 9);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-01-8', '10:00', '18:00', 9);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-01-9', '9:00', '20:00', 9);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-01-10', '9:00', '14:00', 9);

INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-6', '9:15', '18:00', 9);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-7', '9:00', '18:20', 9);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-8', '10:00', '18:00', 9);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-9', '9:00', '20:00', 9);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-10', '9:00', '14:00', 9);
/* activitati 10 */
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-6', '9:00', '18:00', 10);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-7', '9:00', '18:00', 10);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-8', '9:00', '18:00', 10);
/* activitati 11 */
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-6', '9:00', '18:00', 11);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-7', '9:00', '18:00', 11);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-8', '9:00', '18:00', 11);
/* activitati 12 */
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-6', '9:00', '18:00', 12);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-7', '9:00', '18:00', 12);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-8', '9:00', '18:00', 12);
/* activitati 13 */
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-6', '9:00', '18:00', 13);
/* activitati 14 */
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-6', '9:00', '18:00', 14);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-7', '9:00', '18:00', 14);
INSERT INTO activitati (data, orasosire, oraplecare, idangajat)
    VALUES ('2008-09-8', '9:00', '18:00', 14);


/* intrari (facturi proiecte) */
/* intrari proiect 1 */
INSERT INTO intrari (data, suma, idproiect) VALUES ('2008-1-6', 1000, 1);
INSERT INTO intrari (data, suma, idproiect) VALUES ('2008-2-6', 2000, 1);
INSERT INTO intrari (data, suma, idproiect) VALUES ('2008-3-6', 8000, 1);
INSERT INTO intrari (data, suma, idproiect) VALUES ('2008-4-6', 1000, 1);
INSERT INTO intrari (data, suma, idproiect) VALUES ('2008-5-6', 1500, 1);
INSERT INTO intrari (data, suma, idproiect) VALUES ('2008-6-6', 2000, 1);
INSERT INTO intrari (data, suma, idproiect) VALUES ('2008-7-6', 1000, 1);
INSERT INTO intrari (data, suma, idproiect) VALUES ('2008-8-6', 6000, 1);
INSERT INTO intrari (data, suma, idproiect) VALUES ('2008-9-6', 9000, 1);
INSERT INTO intrari (data, suma, idproiect) VALUES ('2008-10-6', 9000, 1);
INSERT INTO intrari (data, suma, idproiect) VALUES ('2008-11-6', 1000, 1);
INSERT INTO intrari (data, suma, idproiect) VALUES ('2008-12-6', 5000, 1);
/* intrari proiect 2 */
INSERT INTO intrari (data, suma, idproiect) VALUES ('2008-1-6', 2000, 2);
INSERT INTO intrari (data, suma, idproiect) VALUES ('2008-2-6', 1000, 2);
INSERT INTO intrari (data, suma, idproiect) VALUES ('2008-3-6', 9000, 2);

/* profit luna */
INSERT INTO profitluna (data) VALUES ('2008-1-6');
INSERT INTO profitluna (data) VALUES ('2008-2-6');
INSERT INTO profitluna (data) VALUES ('2008-3-6');
INSERT INTO profitluna (data) VALUES ('2008-4-6');
INSERT INTO profitluna (data) VALUES ('2008-5-6');
INSERT INTO profitluna (data) VALUES ('2008-6-6');
INSERT INTO profitluna (data) VALUES ('2008-7-6');
INSERT INTO profitluna (data) VALUES ('2008-8-6');
INSERT INTO profitluna (data) VALUES ('2008-9-6');
INSERT INTO profitluna (data) VALUES ('2008-10-6');
INSERT INTO profitluna (data) VALUES ('2008-11-6');
INSERT INTO profitluna (data) VALUES ('2008-12-6');

 
/* venituri per proiect */
INSERT INTO venitproiecte () VALUES ();
INSERT INTO venitproiecte () VALUES ();

/* salarii (salarii angajati) */
/* salarii angajat 5 */
INSERT INTO salarii (data, idangajat) VALUES ('2008-1-5', 5);
INSERT INTO salarii (data, idangajat) VALUES ('2008-2-5', 5);
INSERT INTO salarii (data, idangajat) VALUES ('2008-3-5', 5);
INSERT INTO salarii (data, idangajat) VALUES ('2008-4-5', 5);
INSERT INTO salarii (data, idangajat) VALUES ('2008-5-5', 5);
INSERT INTO salarii (data, idangajat) VALUES ('2008-6-5', 5);
INSERT INTO salarii (data, idangajat) VALUES ('2008-7-5', 5);
INSERT INTO salarii (data, idangajat) VALUES ('2008-8-5', 5);
INSERT INTO salarii (data, idangajat) VALUES ('2008-9-5', 5);
INSERT INTO salarii (data, idangajat) VALUES ('2008-10-5', 5);
INSERT INTO salarii (data, idangajat) VALUES ('2008-11-5', 5);
INSERT INTO salarii (data, idangajat) VALUES ('2008-12-5', 5);
/* salarii angajat 6 */
INSERT INTO salarii (data, idangajat) VALUES ('2008-1-5', 6);
INSERT INTO salarii (data, idangajat) VALUES ('2008-2-5', 6);
INSERT INTO salarii (data, idangajat) VALUES ('2008-3-5', 6);
INSERT INTO salarii (data, idangajat) VALUES ('2008-4-5', 6);
INSERT INTO salarii (data, idangajat) VALUES ('2008-5-5', 6);
INSERT INTO salarii (data, idangajat) VALUES ('2008-6-5', 6);
INSERT INTO salarii (data, idangajat) VALUES ('2008-7-5', 6);
INSERT INTO salarii (data, idangajat) VALUES ('2008-8-5', 6);
INSERT INTO salarii (data, idangajat) VALUES ('2008-9-5', 6);
INSERT INTO salarii (data, idangajat) VALUES ('2008-10-5', 6);
INSERT INTO salarii (data, idangajat) VALUES ('2008-11-5', 6);
INSERT INTO salarii (data, idangajat) VALUES ('2008-12-5', 6);
/* salarii angajat 7 */
INSERT INTO salarii (data, idangajat) VALUES ('2008-1-5', 7);
INSERT INTO salarii (data, idangajat) VALUES ('2008-2-5', 7);
INSERT INTO salarii (data, idangajat) VALUES ('2008-3-5', 7);
INSERT INTO salarii (data, idangajat) VALUES ('2008-4-5', 7);
INSERT INTO salarii (data, idangajat) VALUES ('2008-5-5', 7);
INSERT INTO salarii (data, idangajat) VALUES ('2008-6-5', 7);
INSERT INTO salarii (data, idangajat) VALUES ('2008-7-5', 7);
INSERT INTO salarii (data, idangajat) VALUES ('2008-8-5', 7);
INSERT INTO salarii (data, idangajat) VALUES ('2008-9-5', 7);
INSERT INTO salarii (data, idangajat) VALUES ('2008-10-5', 7);
INSERT INTO salarii (data, idangajat) VALUES ('2008-11-5', 7);
INSERT INTO salarii (data, idangajat) VALUES ('2008-12-5', 7);
/* salarii angajat 8 */
INSERT INTO salarii (data, idangajat) VALUES ('2008-1-5', 8);
INSERT INTO salarii (data, idangajat) VALUES ('2008-2-5', 8);
INSERT INTO salarii (data, idangajat) VALUES ('2008-3-5', 8);
INSERT INTO salarii (data, idangajat) VALUES ('2008-4-5', 8);
INSERT INTO salarii (data, idangajat) VALUES ('2008-5-5', 8);
INSERT INTO salarii (data, idangajat) VALUES ('2008-6-5', 8);
INSERT INTO salarii (data, idangajat) VALUES ('2008-7-5', 8);
INSERT INTO salarii (data, idangajat) VALUES ('2008-8-5', 8);
INSERT INTO salarii (data, idangajat) VALUES ('2008-9-5', 8);
INSERT INTO salarii (data, idangajat) VALUES ('2008-10-5', 8);
INSERT INTO salarii (data, idangajat) VALUES ('2008-11-5', 8);
INSERT INTO salarii (data, idangajat) VALUES ('2008-12-5', 8);
/* salarii angajat 9 */
INSERT INTO salarii (data, idangajat) VALUES ('2008-1-5', 9);
INSERT INTO salarii (data, idangajat) VALUES ('2008-2-5', 9);
INSERT INTO salarii (data, idangajat) VALUES ('2008-3-5denumire', 9);
INSERT INTO salarii (data, idangajat) VALUES ('2008-4-5', 9);
INSERT INTO salarii (data, idangajat) VALUES ('2008-5-5', 9);
INSERT INTO salarii (data, idangajat) VALUES ('2008-6-5', 9);
INSERT INTO salarii (data, idangajat) VALUES ('2008-7-5', 9);
INSERT INTO salarii (data, idangajat) VALUES ('2008-8-5', 9);
INSERT INTO salarii (data, idangajat) VALUES ('2008-9-5', 9);
INSERT INTO salarii (data, idangajat) VALUES ('2008-10-5', 9);
INSERT INTO salarii (data, idangajat) VALUES ('2008-11-5', 9);
INSERT INTO salarii (data, idangajat) VALUES ('2008-12-5', 9);
/* salarii angajat 10 */
INSERT INTO salarii (data, idangajat) VALUES ('2008-1-5', 10);
INSERT INTO salarii (data, idangajat) VALUES ('2008-2-5', 10);
INSERT INTO salarii (data, idangajat) VALUES ('2008-3-5', 10);
INSERT INTO salarii (data, idangajat) VALUES ('2008-4-5', 10);
INSERT INTO salarii (data, idangajat) VALUES ('2008-5-5', 10);
INSERT INTO salarii (data, idangajat) VALUES ('2008-6-5', 10);
INSERT INTO salarii (data, idangajat) VALUES ('2008-7-5', 10);
INSERT INTO salarii (data, idangajat) VALUES ('2008-8-5', 10);
INSERT INTO salarii (data, idangajat) VALUES ('2008-9-5', 10);
INSERT INTO salarii (data, idangajat) VALUES ('2008-10-5', 10);
INSERT INTO salarii (data, idangajat) VALUES ('2008-11-5', 10);
INSERT INTO salarii (data, idangajat) VALUES ('2008-12-5', 10);
/* salarii angajat 11 */
INSERT INTO salarii (data, idangajat) VALUES ('2008-1-5', 11);
INSERT INTO salarii (data, idangajat) VALUES ('2008-2-5', 11);
INSERT INTO salarii (data, idangajat) VALUES ('2008-3-5', 11);
INSERT INTO salarii (data, idangajat) VALUES ('2008-4-5', 11);
INSERT INTO salarii (data, idangajat) VALUES ('2008-5-5', 11);
INSERT INTO salarii (data, idangajat) VALUES ('2008-6-5', 11);
INSERT INTO salarii (data, idangajat) VALUES ('2008-7-5', 11);
INSERT INTO salarii (data, idangajat) VALUES ('2008-8-5', 11);
INSERT INTO salarii (data, idangajat) VALUES ('2008-9-5', 11);
INSERT INTO salarii (data, idangajat) VALUES ('2008-10-5', 11);
INSERT INTO salarii (data, idangajat) VALUES ('2008-11-5', 11);
INSERT INTO salarii (data, idangajat) VALUES ('2008-12-5', 11);
/* salarii angajat 12 */
INSERT INTO salarii (data, idangajat) VALUES ('2008-1-5', 12);
INSERT INTO salarii (data, idangajat) VALUES ('2008-2-5', 12);
INSERT INTO salarii (data, idangajat) VALUES ('2008-3-5', 12);
INSERT INTO salarii (data, idangajat) VALUES ('2008-4-5', 12);
INSERT INTO salarii (data, idangajat) VALUES ('2008-5-5', 12);
INSERT INTO salarii (data, idangajat) VALUES ('2008-6-5', 12);
INSERT INTO salarii (data, idangajat) VALUES ('2008-7-5', 12);
INSERT INTO salarii (data, idangajat) VALUES ('2008-8-5', 12);
INSERT INTO salarii (data, idangajat) VALUES ('2008-9-5', 12);
INSERT INTO salarii (data, idangajat) VALUES ('2008-10-5', 12);
INSERT INTO salarii (data, idangajat) VALUES ('2008-11-5', 12);
INSERT INTO salarii (data, idangajat) VALUES ('2008-12-5', 12);
/* salarii angajat 13 */
INSERT INTO salarii (data, idangajat) VALUES ('2008-1-5', 13);
INSERT INTO salarii (data, idangajat) VALUES ('2008-2-5', 13);
INSERT INTO salarii (data, idangajat) VALUES ('2008-3-5', 13);
INSERT INTO salarii (data, idangajat) VALUES ('2008-4-5', 13);
INSERT INTO salarii (data, idangajat) VALUES ('2008-5-5', 13);
INSERT INTO salarii (data, idangajat) VALUES ('2008-6-5', 13);
INSERT INTO salarii (data, idangajat) VALUES ('2008-7-5', 13);
INSERT INTO salarii (data, idangajat) VALUES ('2008-8-5', 13);
INSERT INTO salarii (data, idangajat) VALUES ('2008-9-5', 13);
INSERT INTO salarii (data, idangajat) VALUES ('2008-10-5', 13);
INSERT INTO salarii (data, idangajat) VALUES ('2008-11-5', 13);
INSERT INTO salarii (data, idangajat) VALUES ('2008-12-5', 13);
/* salarii angajat 14 */
INSERT INTO salarii (data, idangajat) VALUES ('2008-1-5', 14);
INSERT INTO salarii (data, idangajat) VALUES ('2008-2-5', 14);
INSERT INTO salarii (data, idangajat) VALUES ('2008-3-5', 14);
INSERT INTO salarii (data, idangajat) VALUES ('2008-4-5', 14);
INSERT INTO salarii (data, idangajat) VALUES ('2008-5-5', 14);
INSERT INTO salarii (data, idangajat) VALUES ('2008-6-5', 14);
INSERT INTO salarii (data, idangajat) VALUES ('2008-7-5', 14);
INSERT INTO salarii (data, idangajat) VALUES ('2008-8-5', 14);
INSERT INTO salarii (data, idangajat) VALUES ('2008-9-5', 14);
INSERT INTO salarii (data, idangajat) VALUES ('2008-10-5', 14);
INSERT INTO salarii (data, idangajat) VALUES ('2008-11-5', 14);
INSERT INTO salarii (data, idangajat) VALUES ('2008-12-5', 14);


/* cheltuieli per angajat */
INSERT INTO cheltuieliangajat() VALUES ();
INSERT INTO cheltuieliangajat() VALUES ();
INSERT INTO cheltuieliangajat() VALUES ();
INSERT INTO cheltuieliangajat() VALUES ();
INSERT INTO cheltuieliangajat() VALUES ();
INSERT INTO cheltuieliangajat() VALUES ();
INSERT INTO cheltuieliangajat() VALUES ();
INSERT INTO cheltuieliangajat() VALUES ();
INSERT INTO cheltuieliangajat() VALUES ();
INSERT INTO cheltuieliangajat() VALUES ();
INSERT INTO cheltuieliangajat() VALUES ();
INSERT INTO cheltuieliangajat() VALUES ();
INSERT INTO cheltuieliangajat() VALUES ();
INSERT INTO cheltuieliangajat() VALUES ();

/* cheltuieli per departament */
INSERT INTO cheltuielidepartament(id) VALUES (0);
INSERT INTO cheltuielidepartament(id) VALUES (1);
INSERT INTO cheltuielidepartament(id) VALUES (2);
INSERT INTO cheltuielidepartament(id) VALUES (3);
INSERT INTO cheltuielidepartament(id) VALUES (4);


/* constante */
/* ora de inceput a programului de lucru */
INSERT INTO constante (cheie, valoare) VALUES ('orainceput', 9);
/* ora de sfarsit a programului de lucru */
INSERT INTO constante (cheie, valoare) VALUES ('orasfarsit', 18);
/* numar zile de concediu pe an */
INSERT INTO constante (cheie, valoare) VALUES ('zileconcediu', 21);
/* data curenta */
INSERT INTO constante (cheie, valoare) VALUES ('zi', 31);
INSERT INTO constante (cheie, valoare) VALUES ('luna', 12);
INSERT INTO constante (cheie, valoare) VALUES ('an', 2008);
/* retineri */
INSERT INTO constante (cheie, valoare) VALUES ('asigurari sociale', 10.5);
INSERT INTO constante (cheie, valoare) VALUES ('ajutor somaj', 0.5);
INSERT INTO constante (cheie, valoare) VALUES ('asigurari sanatate', 5.5);
INSERT INTO constante (cheie, valoare) VALUES ('impozit', 16);

