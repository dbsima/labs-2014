DROP DATABASE crm;

CREATE DATABASE crm;

USE crm;

/* customers */
CREATE TABLE customers (
    id          INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY NOT NULL,
    username    VARCHAR(30) UNIQUE KEY NOT NULL,
    password    VARCHAR(30) NOT NULL,   
    email       VARCHAR(60) NOT NULL,    
    firstname   VARCHAR(30) NOT NULL,
    lastname    VARCHAR(30) NOT NULL,
    address     VARCHAR(100) NOT NULL,
    phone       INT(10) NOT NULL,
    IBAN        VARCHAR(100) NOT NULL,
    CNP         BIGINT(13) UNSIGNED UNIQUE KEY NOT NULL,
    amount      INT(10) DEFAULT 0,
    status      VARCHAR(30) DEFAULT "NEW"
);

DELIMITER $$
CREATE TRIGGER `test_customers` BEFORE INSERT ON `customers`
FOR EACH ROW
BEGIN
    IF NEW.username = '' THEN
    SIGNAL SQLSTATE '12345'
        SET MESSAGE_TEXT = 'null username';
    END IF;
    IF NEW.password = '' THEN
    SIGNAL SQLSTATE '12345'
        SET MESSAGE_TEXT = 'null password';
    END IF;
    IF NEW.email NOT LIKE '%@%.%' THEN
    SIGNAL SQLSTATE '12345'
        SET MESSAGE_TEXT = 'not a valid email';
    END IF;
    IF NEW.firstname = '' THEN
    SIGNAL SQLSTATE '12345'
        SET MESSAGE_TEXT = 'null firstname';
    END IF;
    IF NEW.lastname = '' THEN
    SIGNAL SQLSTATE '12345'
        SET MESSAGE_TEXT = 'null lastname';
    END IF;
    IF NEW.address = '' THEN
    SIGNAL SQLSTATE '12345'
        SET MESSAGE_TEXT = 'null address';
    END IF;
    IF NEW.phone = '' THEN
    SIGNAL SQLSTATE '12345'
        SET MESSAGE_TEXT = 'null phone';
    END IF;
    IF NEW.iban = '' THEN
    SIGNAL SQLSTATE '12345'
        SET MESSAGE_TEXT = 'null address';
    END IF;
    IF NEW.cnp = '' THEN
    SIGNAL SQLSTATE '12345'
        SET MESSAGE_TEXT = 'null cnp';
    END IF;
END$$   
DELIMITER ; 


/* employee */
CREATE TABLE employees (
    id          INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY NOT NULL,
    username    VARCHAR(30) UNIQUE KEY NOT NULL,
    password    VARCHAR(30) NOT NULL,   
    email       VARCHAR(60) NOT NULL,    
    firstname   VARCHAR(30) DEFAULT "",
    lastname    VARCHAR(30) DEFAULT "",
    job         VARCHAR(30) NOT NULL
);

DELIMITER $$
CREATE TRIGGER `test_employees` BEFORE INSERT ON `employees`
FOR EACH ROW
BEGIN
    IF NEW.username = '' THEN
    SIGNAL SQLSTATE '12345'
        SET MESSAGE_TEXT = 'null username';
    END IF;
    IF NEW.password = '' THEN
    SIGNAL SQLSTATE '12345'
        SET MESSAGE_TEXT = 'null password';
    END IF;
    IF NEW.email NOT LIKE '%@%.%' THEN
    SIGNAL SQLSTATE '12345'
        SET MESSAGE_TEXT = 'not a valid email';
    END IF;
    IF NEW.firstname = '' THEN
    SIGNAL SQLSTATE '12345'
        SET MESSAGE_TEXT = 'null firstname';
    END IF;
    IF NEW.lastname = '' THEN
    SIGNAL SQLSTATE '12345'
        SET MESSAGE_TEXT = 'null lastname';
    END IF;
    IF NEW.job NOT IN ('software engineer', 'qa engineer', 'admin', 'support', 'sales') THEN
    SIGNAL SQLSTATE '12345'
        SET MESSAGE_TEXT = 'not a valid job';
    END IF;
END$$   
DELIMITER ; 


/* contracts */
CREATE TABLE contracts (
    id          INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY NOT NULL,
    employeeID  INT(10) UNSIGNED NOT NULL,
    salary      INT(10) UNSIGNED NOT NULL,
    FOREIGN KEY (employeeID) REFERENCES employees(id) ON UPDATE CASCADE ON DELETE CASCADE
);

DELIMITER $$
CREATE TRIGGER `test_contracts` BEFORE INSERT ON `contracts`
FOR EACH ROW
BEGIN
    IF NEW.employeeID = '' THEN
    SIGNAL SQLSTATE '12345'
        SET MESSAGE_TEXT = 'not a valid employeeID';
    END IF;
    IF NEW.salary = '' or NEW.salary < 0 THEN
    SIGNAL SQLSTATE '12345'
        SET MESSAGE_TEXT = 'not a valid salary';
    END IF;
END$$   
DELIMITER ; 


/* projects */
CREATE TABLE projects (
    id          INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY NOT NULL,
    name        VARCHAR(100) NOT NULL,
    description VARCHAR(1000),
    category    VARCHAR(30)
);

DELIMITER $$
CREATE TRIGGER `test_projects` BEFORE INSERT ON `projects`
FOR EACH ROW
BEGIN
    IF NEW.name = '' THEN
    SIGNAL SQLSTATE '12345'
        SET MESSAGE_TEXT = 'not a valid name';
    END IF;
END$$   
DELIMITER ; 

/* products */
CREATE TABLE products (
    id              INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY NOT NULL,
    name            VARCHAR(100) NOT NULL,
    description     VARCHAR(1000),
    date            DATE NOT NULL,
    price           FLOAT DEFAULT 0,
    availability    VARCHAR(10) NOT NULL,
    rate            FLOAT DEFAULT 0,
    category        VARCHAR(30) DEFAULT "" 
);

CREATE TABLE ratings (
    id          INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY NOT NULL,
    customerID  INT(10) UNSIGNED NOT NULL,
    productID   INT(10) UNSIGNED NOT NULL,
    rate        int(10) UNSIGNED NOT NULL,
    FOREIGN KEY (customerID) REFERENCES customers(id) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (productID) REFERENCES products(id) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE tags (
    id          INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY NOT NULL,
    projectID   INT(10) UNSIGNED NOT NULL,
    tag         VARCHAR(10) NOT NULL,
    FOREIGN KEY (projectID) REFERENCES projects(id) ON UPDATE CASCADE ON DELETE CASCADE
);

/* team */
CREATE TABLE teams (
    id          INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY NOT NULL,
    name        VARCHAR(30) NOT NULL,
    projectID   INT(10) UNSIGNED NOT NULL,
    FOREIGN KEY (projectID) REFERENCES projects(id) ON UPDATE CASCADE ON DELETE CASCADE
);

DELIMITER $$
CREATE TRIGGER `test_teams` BEFORE INSERT ON `teams`
FOR EACH ROW
BEGIN
    IF NEW.name = '' THEN
    SIGNAL SQLSTATE '12345'
        SET MESSAGE_TEXT = 'not a valid name';
    END IF;
    IF NEW.projectID = '' THEN
    SIGNAL SQLSTATE '12345'
        SET MESSAGE_TEXT = 'not a valid projectID';
    END IF;
END$$   
DELIMITER ;


/* teams composition*/
CREATE TABLE teams_composition (
    id              INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY NOT NULL,
    teamID          INT(10) UNSIGNED NOT NULL,
    teamMemberID    INT(10) UNSIGNED NOT NULL,
    startDate       DATE NOT NULL,
    finishDate      DATE NOT NULL,
    FOREIGN KEY (teamMemberID) REFERENCES employees(id) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (teamID) REFERENCES teams(id) ON UPDATE CASCADE ON DELETE CASCADE
);

DELIMITER $$
CREATE TRIGGER `test_teams_composition` BEFORE INSERT ON `teams_composition`
FOR EACH ROW
BEGIN
    IF NEW.teamID = '' THEN
    SIGNAL SQLSTATE '12345'
        SET MESSAGE_TEXT = 'not a valid teamID';
    END IF;
    IF NEW.teamMemberID = '' THEN
    SIGNAL SQLSTATE '12345'
        SET MESSAGE_TEXT = 'not a valid teamMemberID';
    END IF;
    IF NEW.startDate = '' THEN
    SIGNAL SQLSTATE '12345'
        SET MESSAGE_TEXT = 'not a valid startDate';
    END IF;
    IF NEW.finishDate = '' THEN
    SIGNAL SQLSTATE '12345'
        SET MESSAGE_TEXT = 'not a valid finishDate';
    END IF;
END$$   
DELIMITER ;

/* invoices */
CREATE TABLE invoices (
    customerID  INT(10) UNSIGNED NOT NULL,
    number  VARCHAR(10) PRIMARY KEY NOT NULL,
    date    DATETIME NOT NULL,
    amount  FLOAT NOT NULL,
    status  VARCHAR(30) NOT NULL DEFAULT 'issued',
    FOREIGN KEY (customerID) REFERENCES customers(id) ON UPDATE CASCADE ON DELETE CASCADE
);

DELIMITER $$
CREATE TRIGGER `test_invoices` BEFORE INSERT ON `invoices`
FOR EACH ROW
BEGIN
    IF NEW.number = '' THEN
    SIGNAL SQLSTATE '12345'
        SET MESSAGE_TEXT = 'null number';
    END IF;
    IF NEW.date = '' THEN
    SIGNAL SQLSTATE '12345'
        SET MESSAGE_TEXT = 'null number';
    END IF;
    IF NEW.amount = '' or NEW.amount < 0 THEN
    SIGNAL SQLSTATE '12345'
        SET MESSAGE_TEXT = 'not a valid amount';
    END IF;
    IF NEW.status NOT IN ('issued', 'paid', 'canceled') THEN
    SIGNAL SQLSTATE '12345'
        SET MESSAGE_TEXT = 'not a valid status';
    END IF;
    IF NEW.customerID = '' THEN
    SIGNAL SQLSTATE '12345'
        SET MESSAGE_TEXT = 'not a valid customerID';
    END IF;
END$$   
DELIMITER ; 


/* details invoices */
CREATE TABLE details_invoices (
    id          INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY NOT NULL,
    invoiceNumber  VARCHAR(10) NOT NULL,
    productID   INT(10) UNSIGNED NOT NULL,
    items       INT(4) UNSIGNED NOT NULL,
    FOREIGN KEY (invoiceNumber) REFERENCES invoices (number) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (productID) REFERENCES projects (id) ON UPDATE CASCADE ON DELETE CASCADE
);

DELIMITER $$
CREATE TRIGGER `test_details_invoices` BEFORE INSERT ON `details_invoices`
FOR EACH ROW
BEGIN
    IF NEW.invoiceNumber = '' THEN
    SIGNAL SQLSTATE '12345'
        SET MESSAGE_TEXT = 'not a valid invoiceID';
    END IF;
    IF NEW.productID = '' THEN
    SIGNAL SQLSTATE '12345'
        SET MESSAGE_TEXT = 'not a valid productID';
    END IF;
    IF NEW.items = '' or NEW.items < 0 THEN
    SIGNAL SQLSTATE '12345'
        SET MESSAGE_TEXT = 'not a valid item';
    END IF;
END$$   
DELIMITER ;

/* problems */
CREATE TABLE problems (
    id          INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY NOT NULL,
    customerID  INT(10) UNSIGNED NOT NULL,
    productID   INT(10) UNSIGNED NOT NULL,
    invoiceNumber  VARCHAR(10) NOT NULL,
    message     VARCHAR(120) NOT NULL,
    status      VARCHAR(30) NOT NULL DEFAULT 'open',
    date        DATETIME NOT NULL,
    priority    INT(10) UNSIGNED DEFAULT 3,
    FOREIGN KEY (customerID) REFERENCES customers(id) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (invoiceNumber) REFERENCES invoices (number) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (productID) REFERENCES projects (id) ON UPDATE CASCADE ON DELETE CASCADE
);

/* messages */
CREATE TABLE messages (
    id          INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY NOT NULL,
    employeeID  INT(10) UNSIGNED NOT NULL,
    problemID   INT(10) UNSIGNED NOT NULL,
    message     VARCHAR(120) NOT NULL,
    FOREIGN KEY (employeeID) REFERENCES employees(id) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (problemID) REFERENCES problems(id) ON UPDATE CASCADE ON DELETE CASCADE
);

/* constants */
CREATE TABLE constants (
    id      INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY NOT NULL,
    cKey     VARCHAR(30) NOT NULL,
    cValue   VARCHAR(30) NOT NULL
);


/* populate tables */

/* customers */
INSERT INTO customers (username, password, email, lastname, address, phone, IBAN, CNP, amount)
    VALUES ('zota.daniel', '-', 'zota.daniel@gmail.com', 'Zota', 'Rahovei 18', '0764536213', 'RO101', '1910125324312', '1231');

INSERT INTO customers (username, password, email, firstname, lastname, address, phone, IBAN, CNP, amount, status)
    VALUES ('zota.daniel', '-', 'zota.daniel@gmail.com', 'Daniel', 'Zota', 'Rahovei 18', '0764536213', 'RO101', '1910125324312', '120000', 'OLD');
INSERT INTO customers (username, password, email, firstname, lastname, address, phone, IBAN, CNP, amount, status)
    VALUES ('chitac.marin', '-', 'chitac.marin@gmail.com', 'Marin', 'Chitac', 'Brasov 24', '0764536213', 'RO102', '1910125324318', '120', 'OLD');
INSERT INTO customers (username, password, email, firstname, lastname, address, phone, IBAN, CNP, amount)
    VALUES ('ion.barbu', '-', 'ion.barbu@gmail.com', 'Ion', 'Barbu', 'W. Maracineanu 22', '0764536213', 'RO103', '1910125324319', '120000');

/* employees */
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('dbsima', '-', 'dbsima@gmail.com', 'Dragos-Bogdan', 'Sima', 'dsada');
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('dbsima', '-', 'dbsima@gmailcom', 'Dragos-Bogdan', 'Sima', 'software engineer');

/* admins*/
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('admin', '-', 'admin@gmail.com', 'Adminel', 'admin', 'admin');

INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('dbsima', '-', 'dbsima@gmail.com', 'Dragos-Bogdan', 'Sima', 'software engineer');
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('opetcu', '-', 'opetcu@gmail.com', 'Ovidiu', 'Petcu', 'software engineer');
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('apitac', '-', 'apitac@gmail.com', 'Alexandru', 'Pitac', 'software engineer');
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('mcaruta', '-', 'mcaruta@gmail.com', 'Mariana', 'Caruta', 'qa engineer');
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('dguita', '-', 'dguita@gmail.com', 'Diana', 'Guita', 'qa engineer');
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('agheorghita', '-', 'agheorghita@gmail.com', 'Alina', 'Gheorghita', 'qa engineer');

INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('icreanga', '-', 'dbsima@gmail.com', 'Dragos-Bogdan', 'Sima', 'software engineer');
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('meminescu', '-', 'opetcu@gmail.com', 'Ovidiu', 'Petcu', 'software engineer');
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('gbacovia', '-', 'apitac@gmail.com', 'Alexandru', 'Pitac', 'software engineer');
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('ogoga', '-', 'mcaruta@gmail.com', 'Mariana', 'Caruta', 'qa engineer');
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('ilcaragiale', '-', 'dguita@gmail.com', 'Diana', 'Guita', 'qa engineer');
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('ibarbu', '-', 'agheorghita@gmail.com', 'Alina', 'Gheorghita', 'qa engineer');

INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('amutu', '-', 'agheorghita@gmail.com', 'Alina', 'Gheorghita', 'qa engineer');
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('cchivu', '-', 'dbsima@gmail.com', 'Dragos-Bogdan', 'Sima', 'software engineer');
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('gpopescu', '-', 'opetcu@gmail.com', 'Ovidiu', 'Petcu', 'software engineer');
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('ghagi', '-', 'apitac@gmail.com', 'Alexandru', 'Pitac', 'software engineer');
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('bstelea', '-', 'mcaruta@gmail.com', 'Mariana', 'Caruta', 'qa engineer');
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('blobont', '-', 'dguita@gmail.com', 'Diana', 'Guita', 'qa engineer');
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('siovan', '-', 'agheorghita@gmail.com', 'Alina', 'Gheorghita', 'qa engineer');

INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('cmonet', '-', 'agheorghita@gmail.com', 'Alina', 'Gheorghita', 'qa engineer');
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('cporumbescu', '-', 'dbsima@gmail.com', 'Dragos-Bogdan', 'Sima', 'software engineer');
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('vvg', '-', 'opetcu@gmail.com', 'Ovidiu', 'Petcu', 'software engineer');
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('ppicasso', '-', 'apitac@gmail.com', 'Alexandru', 'Pitac', 'software engineer');
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('gbrancusi', '-', 'mcaruta@gmail.com', 'Mariana', 'Caruta', 'qa engineer');
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('rodin', '-', 'dguita@gmail.com', 'Diana', 'Guita', 'qa engineer');
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('polock', '-', 'agheorghita@gmail.com', 'Alina', 'Gheorghita', 'qa engineer');

INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('mcyrus', '-', 'agheorghita@gmail.com', 'Alina', 'Gheorghita', 'qa engineer');
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('jbieber', '-', 'dbsima@gmail.com', 'Dragos-Bogdan', 'Sima', 'software engineer');
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('brhymes', '-', 'opetcu@gmail.com', 'Ovidiu', 'Petcu', 'software engineer');
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('sdog', '-', 'apitac@gmail.com', 'Alexandru', 'Pitac', 'software engineer');
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('cbrown', '-', 'mcaruta@gmail.com', 'Mariana', 'Caruta', 'qa engineer');
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('rihanna', '-', 'dguita@gmail.com', 'Diana', 'Guita', 'qa engineer');
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('eminem', '-', 'agheorghita@gmail.com', 'Alina', 'Gheorghita', 'qa engineer');

/* support */
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('gdinica', '-', 'gdinica@gmail.com', 'Gheorghe', 'Dinica', 'support');
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('tcaragiu', '-', 'tcaragiu@gmail.com', 'Toma', 'Caragiu', 'support');

/* sales */
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('mmoraru', '-', 'mmoraru@gmail.com', 'Marin', 'Moraru', 'sales');
INSERT INTO employees (username, password, email, firstname, lastname, job)
    VALUES ('apelea', '-', 'apelea@gmail.com', 'Amza', 'Pelea', 'sales');


/* contracts */
INSERT INTO contracts (salary, employeeID) VALUES ('', '3');
INSERT INTO contracts (salary, employeeID) VALUES ('-1', '2');
INSERT INTO contracts (salary, employeeID) VALUES ('3213', '');
INSERT INTO contracts (salary, employeeID) VALUES ('200', '2');
INSERT INTO contracts (salary, employeeID) VALUES ('100', '3');
INSERT INTO contracts (salary, employeeID) VALUES ('400', '4');
INSERT INTO contracts (salary, employeeID) VALUES ('250', '5');
INSERT INTO contracts (salary, employeeID) VALUES ('300', '6');
INSERT INTO contracts (salary, employeeID) VALUES ('600', '7');
INSERT INTO contracts (salary, employeeID) VALUES ('220', '8');
INSERT INTO contracts (salary, employeeID) VALUES ('110', '9');
INSERT INTO contracts (salary, employeeID) VALUES ('410', '10');
INSERT INTO contracts (salary, employeeID) VALUES ('260', '11');
INSERT INTO contracts (salary, employeeID) VALUES ('310', '12');
INSERT INTO contracts (salary, employeeID) VALUES ('610', '13');
INSERT INTO contracts (salary, employeeID) VALUES ('210', '14');
INSERT INTO contracts (salary, employeeID) VALUES ('140', '15');
INSERT INTO contracts (salary, employeeID) VALUES ('440', '16');
INSERT INTO contracts (salary, employeeID) VALUES ('240', '17');
INSERT INTO contracts (salary, employeeID) VALUES ('340', '18');
INSERT INTO contracts (salary, employeeID) VALUES ('640', '19');

/* projects */
INSERT INTO projects (name, description, category) VALUES ('Adobe Illustrator CS6', 'Adobe Illustrator CS6, Multiple Platforms, English, 1 User, 1 Year' ,'Editing');
INSERT INTO projects (name, description, category) VALUES ('Adobe Photoshop CS6', 'Adobe Photoshop CS6, Multiple Platforms, English, 1 User, 1 Year', 'Editing');
INSERT INTO projects (name, description, category) VALUES ('ESET NOD32 Antivirus V6', 'ESET NOD32 Antivirus V6, 1 year', 'Antivirus');
INSERT INTO projects (name, description, category) VALUES ('Panda Antivirus Pro 2014', 'Panda Antivirus Pro 2014, 3 Computers, 1 User, 1 Year', 'Antivirus');
INSERT INTO projects (name, description, category) VALUES ('Norton 360 21', 'Norton 360 21, 1 Computer, 3 Users, 1 Year', 'Antivirus');
INSERT INTO projects (name, description, category) VALUES ('Avira Internet Security 2013,', 'Avira Internet Security 2013, 1 Year, 1 User', 'Antivirus');
INSERT INTO projects (name, description, category) VALUES ('Bitdefender Internet Security', 'Bitdefender Internet Security (new version), 1 Year, 3 Users', 'Antivirus');
INSERT INTO projects (name, description, category) VALUES ('Kaspersky Internet Security Multi-Device 2014', 'Kaspersky Internet Security Multi-Device 2014, EEMEA Edition, 3 Desktop, 1 Year', 'Antivirus');
INSERT INTO projects (name, description, category) VALUES ('HP Microsoft Windows Server 2012', 'HP Microsoft Windows Server 2012 Standard ROK English', 'Operating System');
INSERT INTO projects (name, description, category) VALUES ('Microsoft Windows 8 Professional', 'Microsoft Windows 8 Professional, 64 bit, English OEM', 'Operating System');
INSERT INTO projects (name, description, category) VALUES ('Microsoft Windows 7 Professional', 'Microsoft Windows 7 Professional 64 bit English OEM SP1', 'Operating System');

INSERT INTO tags (projectID, tag) VALUES ('1', 'adobe');
INSERT INTO tags (projectID, tag) VALUES ('1', 'cs6');
INSERT INTO tags (projectID, tag) VALUES ('1', 'illustrator');
INSERT INTO tags (projectID, tag) VALUES ('2', 'adobe');
INSERT INTO tags (projectID, tag) VALUES ('2', 'cs6');
INSERT INTO tags (projectID, tag) VALUES ('2', 'photoshop');
INSERT INTO tags (projectID, tag) VALUES ('3', 'eset');
INSERT INTO tags (projectID, tag) VALUES ('3', 'nod32');
INSERT INTO tags (projectID, tag) VALUES ('3', 'antivirus');
INSERT INTO tags (projectID, tag) VALUES ('4', 'panda');
INSERT INTO tags (projectID, tag) VALUES ('4', 'antivirus');
INSERT INTO tags (projectID, tag) VALUES ('4', '2014');
INSERT INTO tags (projectID, tag) VALUES ('5', 'norton');
INSERT INTO tags (projectID, tag) VALUES ('5', 'antivirus');
INSERT INTO tags (projectID, tag) VALUES ('5', '360');
INSERT INTO tags (projectID, tag) VALUES ('6', 'antivirus');
INSERT INTO tags (projectID, tag) VALUES ('6', 'avira');
INSERT INTO tags (projectID, tag) VALUES ('4', '2013');
INSERT INTO tags (projectID, tag) VALUES ('6', 'internet');
INSERT INTO tags (projectID, tag) VALUES ('7', 'antivirus');
INSERT INTO tags (projectID, tag) VALUES ('7', 'bitdefender');
INSERT INTO tags (projectID, tag) VALUES ('7', 'internet');
INSERT INTO tags (projectID, tag) VALUES ('8', 'antivirus');
INSERT INTO tags (projectID, tag) VALUES ('8', 'kaspersky');
INSERT INTO tags (projectID, tag) VALUES ('8', 'internet');
INSERT INTO tags (projectID, tag) VALUES ('8', '2014');
INSERT INTO tags (projectID, tag) VALUES ('9', 'hp');
INSERT INTO tags (projectID, tag) VALUES ('9', 'microsoft');
INSERT INTO tags (projectID, tag) VALUES ('9', 'server');
INSERT INTO tags (projectID, tag) VALUES ('9', 'windows');
INSERT INTO tags (projectID, tag) VALUES ('10', 'microsoft');
INSERT INTO tags (projectID, tag) VALUES ('10', 'windows 8');
INSERT INTO tags (projectID, tag) VALUES ('10', 'professional');
INSERT INTO tags (projectID, tag) VALUES ('11', 'microsoft');
INSERT INTO tags (projectID, tag) VALUES ('11', 'windows 7');
INSERT INTO tags (projectID, tag) VALUES ('11', 'professional');

/*  
INSERT INTO products (name, description, date, price, availability) VALUES ('Samsung I8190 Galaxy S3 Mini', 'Samsung I8190 Galaxy S3 Mini, Metalic Blue', '2014-1-1', '1023', 'yes');
INSERT INTO products (name, description, date, price, availability) VALUES ('HTC One Mini 4G', 'HTC One Mini 4G, 16GB, Black', '2014-1-1', '2023', 'yes');
INSERT INTO products (name, description, date, price, availability) VALUES ('Apple iPhone 5S,', 'Apple iPhone 5S, 16GB, Gold', '2014-1-1', '1000', 'soon');
INSERT INTO products (name, description, date, price, availability) VALUES ('Google Nexus 4', 'Google Nexus 4, 16GB, Black', '2014-1-1', '3211', 'yes');
INSERT INTO products (name, description, date, price, availability) VALUES ('Sony Xperia Z 4G', 'Sony Xperia Z 4G, Black', '2014-1-1', '2', 'yes');
*/
/* teams */
INSERT INTO teams (name, projectID) VALUES ('AII1', '2');
INSERT INTO teams (name, projectID) VALUES ('AII2', '1');
INSERT INTO teams (name, projectID) VALUES ('AII3', '2');
INSERT INTO teams (name, projectID) VALUES ('AII4', '3');
INSERT INTO teams (name, projectID) VALUES ('AII5', '4');
INSERT INTO teams (name, projectID) VALUES ('AII6', '5');
INSERT INTO teams (name, projectID) VALUES ('AII7', '6');
INSERT INTO teams (name, projectID) VALUES ('AII8', '7');
INSERT INTO teams (name, projectID) VALUES ('AII9', '8');
INSERT INTO teams (name, projectID) VALUES ('AII10', '9');
INSERT INTO teams (name, projectID) VALUES ('AII11', '10');
INSERT INTO teams (name, projectID) VALUES ('AII12', '11');
INSERT INTO teams (name, projectID) VALUES ('AII13', '11');

/* teams_composition */
/* team AII1 */
INSERT INTO teams_composition (teamID, teamMemberID, startDate, finishDate) VALUES ('1', '2', '2013-1-2', '2013-3-30');
INSERT INTO teams_composition (teamID, teamMemberID, startDate, finishDate) VALUES ('1', '3', '2013-1-1', '2013-3-29');
INSERT INTO teams_composition (teamID, teamMemberID, startDate, finishDate) VALUES ('1', '4', '2013-2-4', '2013-3-13');
/* team AII2 */
INSERT INTO teams_composition (teamID, teamMemberID, startDate, finishDate) VALUES ('2', '5', '2013-1-3', '2013-3-12');
INSERT INTO teams_composition (teamID, teamMemberID, startDate, finishDate) VALUES ('2', '6', '2013-1-1', '2013-3-24');
/* team AII3 */
INSERT INTO teams_composition (teamID, teamMemberID, startDate, finishDate) VALUES ('3', '7', '2013-1-5', '2013-3-25');
/* team AII4 */
INSERT INTO teams_composition (teamID, teamMemberID, startDate, finishDate) VALUES ('4', '2', '2013-4-2', '2013-5-27');
INSERT INTO teams_composition (teamID, teamMemberID, startDate, finishDate) VALUES ('4', '3', '2013-4-1', '2013-5-26');
INSERT INTO teams_composition (teamID, teamMemberID, startDate, finishDate) VALUES ('4', '5', '2013-4-4', '2013-5-13');
/* team AII5 */
INSERT INTO teams_composition (teamID, teamMemberID, startDate, finishDate) VALUES ('5', '4', '2013-4-3', '2013-5-12');
INSERT INTO teams_composition (teamID, teamMemberID, startDate, finishDate) VALUES ('5', '6', '2013-4-1', '2013-5-24');
/* team AII6 */
INSERT INTO teams_composition (teamID, teamMemberID, startDate, finishDate) VALUES ('6', '2', '2013-6-2', '2013-7-27');
INSERT INTO teams_composition (teamID, teamMemberID, startDate, finishDate) VALUES ('6', '3', '2013-6-1', '2013-7-26');
INSERT INTO teams_composition (teamID, teamMemberID, startDate, finishDate) VALUES ('6', '5', '2013-6-4', '2013-7-13');
/* team AII7 */
INSERT INTO teams_composition (teamID, teamMemberID, startDate, finishDate) VALUES ('7', '4', '2013-6-3', '2013-7-12');
INSERT INTO teams_composition (teamID, teamMemberID, startDate, finishDate) VALUES ('7', '6', '2013-6-1', '2013-7-24');
/* team AII8 */
INSERT INTO teams_composition (teamID, teamMemberID, startDate, finishDate) VALUES ('8', '7', '2014-1-5', '2014-1-27');
/* team AII9 */
INSERT INTO teams_composition (teamID, teamMemberID, startDate, finishDate) VALUES ('9', '7', '2014-3-5', '2014-4-25');
/* team AII10 */
INSERT INTO teams_composition (teamID, teamMemberID, startDate, finishDate) VALUES ('10', '7', '2014-5-5', '2014-6-25');
/* team AII11 */
INSERT INTO teams_composition (teamID, teamMemberID, startDate, finishDate) VALUES ('11', '2', '2014-10-2', '2014-11-30');
INSERT INTO teams_composition (teamID, teamMemberID, startDate, finishDate) VALUES ('11', '3', '2014-10-1', '2014-11-29');
INSERT INTO teams_composition (teamID, teamMemberID, startDate, finishDate) VALUES ('11', '4', '2014-10-4', '2014-12-13');
/* team AII12 */
INSERT INTO teams_composition (teamID, teamMemberID, startDate, finishDate) VALUES ('12', '8', '2013-1-3', '2013-3-12');
INSERT INTO teams_composition (teamID, teamMemberID, startDate, finishDate) VALUES ('12', '9', '2013-1-1', '2013-3-24');
INSERT INTO teams_composition (teamID, teamMemberID, startDate, finishDate) VALUES ('12', '10', '2013-2-1', '2013-3-24');
INSERT INTO teams_composition (teamID, teamMemberID, startDate, finishDate) VALUES ('12', '11', '2013-1-3', '2013-3-12');
INSERT INTO teams_composition (teamID, teamMemberID, startDate, finishDate) VALUES ('12', '12', '2013-2-1', '2013-3-24');
INSERT INTO teams_composition (teamID, teamMemberID, startDate, finishDate) VALUES ('12', '13', '2013-1-1', '2013-3-24');
/* team AII13 */
INSERT INTO teams_composition (teamID, teamMemberID, startDate, finishDate) VALUES ('13', '14', '2013-2-3', '2013-4-12');
INSERT INTO teams_composition (teamID, teamMemberID, startDate, finishDate) VALUES ('13', '15', '2013-1-1', '2013-3-24');
INSERT INTO teams_composition (teamID, teamMemberID, startDate, finishDate) VALUES ('13', '16', '2013-2-1', '2013-4-14');
INSERT INTO teams_composition (teamID, teamMemberID, startDate, finishDate) VALUES ('13', '17', '2013-3-3', '2013-5-12');
INSERT INTO teams_composition (teamID, teamMemberID, startDate, finishDate) VALUES ('13', '18', '2013-2-1', '2013-3-27');
INSERT INTO teams_composition (teamID, teamMemberID, startDate, finishDate) VALUES ('13', '19', '2013-1-1', '2013-5-24');


/* constants */
INSERT INTO constants (cKey, cValue) VALUES ('invoiceDaysToDeath', '5');
INSERT INTO constants (cKey, cValue) VALUES ('productDaysToSoon', '10');

