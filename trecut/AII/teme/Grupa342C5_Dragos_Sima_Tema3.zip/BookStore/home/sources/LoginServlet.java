import dataaccess.DataBaseConnection;
import general.Constants;
import graphicuserinterface.LoginGraphicUserInterface;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.joda.time.DateTime;
import org.joda.time.Days;

public class LoginServlet extends HttpServlet {
    final public static long serialVersionUID = 10001000L;
    
    public String userName = "", userPassword = "", userType = "", userTable = "";
    
    public String jobType = "";
    private String email = "";
    private String firstname = "";
    private String lastname = "";
    private String address = "";
    private String telephone = "";
    private String iban = "";
    private String cnp = "";
 
    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        try {
            DataBaseConnection.openConnection();
        } catch (SQLException exception) {
            System.out.println("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }
    }

    @Override
    public void destroy() {
        try {
            DataBaseConnection.closeConnection();
        } catch (SQLException exception) {
            System.out.println("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }
    }
    
    public boolean isLoginError(String userName, String userPassword, String userTable) {
        return (userName != null && !userName.isEmpty() && userPassword != null && !userPassword.isEmpty() && getUserID(userName,userPassword, userTable).equals(Constants.USER_NONE));
    }
    
    
    public String getUserID(String userName, String userPassword, String userTable) {
        String result = Constants.USER_NONE;
        try {
            String whereClause = Constants.USER_NAME+"=\'"+userName+"\' AND "+Constants.USER_PASSWORD+"=\'"+userPassword+"\'";
            
            if (userTable.equals("employees")) {
                whereClause += " AND job = '" + userType + "'";
            }
            else {
                whereClause += " AND status = 'OLD'";
            }
            
            ArrayList<String> attributes = new ArrayList<>();
            attributes.add("id");
            ArrayList<ArrayList<Object>> id = DataBaseConnection.getTableContent(userTable, attributes, whereClause, null, null);
            if (id != null && !id.isEmpty() && id.get(0) != null && id.get(0).get(0) != null){
                return id.get(0).get(0).toString();
            }
        } catch (SQLException exception) {
            System.out.println("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }
        return result;
    }

    public String getUserDisplayName(String userName, String userPassword, String userTable) {
        String result = new String();
        try {
            ArrayList<String> attributes = new ArrayList<>();
            attributes.add(DataBaseConnection.getTableDescription(userTable));
            ArrayList<ArrayList<Object>> displayName = DataBaseConnection.getTableContent(userTable, attributes, Constants.USER_NAME+"=\'"+userName+"\' AND "+Constants.USER_PASSWORD+"=\'"+userPassword+"\'", null, null);
            //System.out.println(displayName);
            if (displayName != null)
                return displayName.get(0).get(0).toString();
        } catch (SQLException exception) {
            System.out.println("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }
        return result;
    }
    
    public ArrayList<String> getUserAccountSettings(String userName, String userPassword, String userTable) {
        ArrayList<String> result = new ArrayList<>();

        try {
            ArrayList<String> attributes = new ArrayList<>();
            attributes.add("username");
            attributes.add("password");
            attributes.add("email");
            attributes.add("firstname");
            attributes.add("lastname");
            attributes.add("address");
            attributes.add("phone");
            attributes.add("IBAN");
            attributes.add("CNP");
            attributes.add("amount");
            ArrayList<ArrayList<Object>> account = DataBaseConnection.getTableContent(userTable, attributes, Constants.USER_NAME+"=\'"+userName+"\' AND "+Constants.USER_PASSWORD+"=\'"+userPassword+"\'", null, null);
            //System.out.println(account);
            if (account != null){
                for (int i = 0; i < account.get(0).size(); i++)
                    result.add(account.get(0).get(i).toString());
                //System.out.println(result);
                return result;
            }
        } catch (SQLException exception) {
            System.out.println("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }
        return result;
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Enumeration parameters = request.getParameterNames();
        boolean found = false;
        while(parameters.hasMoreElements()) {
            String parameter = (String)parameters.nextElement();
            if (parameter.equals(Constants.USER_NAME)) {
                userName = request.getParameter(parameter);
            }
            if (parameter.equals(Constants.USER_PASSWORD)) {
                userPassword = request.getParameter(parameter);
            }
            if (parameter.equals("email") && !request.getParameter(parameter).equals("")) {
                email = request.getParameter(parameter);
            }
            if (parameter.equals("firstname") && !request.getParameter(parameter).equals("")) {
                firstname = request.getParameter(parameter);
            }
            if (parameter.equals("lastname") && !request.getParameter(parameter).equals("")) {
                lastname = request.getParameter(parameter);
            }
            if (parameter.equals("address") && !request.getParameter(parameter).equals("")) {
                address = request.getParameter(parameter);
            }
            if (parameter.equals("telephone") && !request.getParameter(parameter).equals("")) {
                telephone = request.getParameter(parameter);
            }
            if (parameter.equals("iban") && !request.getParameter(parameter).equals("")) {
                iban = request.getParameter(parameter);
            }
            if (parameter.equals("cnp") && !request.getParameter(parameter).equals("")) {
                cnp = request.getParameter(parameter);
            }
            if (parameter.equals("userType")) {
                userType = request.getParameter(parameter);
                
                //System.out.println(userType);
                if (userType.equals("customer"))
                    userTable = "customers";
                else
                    userTable = "employees";    
            }
        }

        
        response.setContentType("text/html");
        try (PrintWriter printWriter = new PrintWriter(response.getWriter())) {
            if (!userName.equals("") && !userPassword.equals("") && userType.equals("customer") && !email.equals("") && !firstname.equals("") && !lastname.equals("") && !address.equals("") && !telephone.equals("") && !iban.equals("") && !cnp.equals("")) {
                System.out.println("sing up");
                
                ArrayList<String> attributes = new ArrayList<>();
                attributes.add("username");
                attributes.add("password");
                attributes.add("email");
                attributes.add("firstname");
                attributes.add("lastname");
                attributes.add("address");
                attributes.add("phone");
                attributes.add("IBAN");
                attributes.add("CNP");
                
                ArrayList<String> values = new ArrayList<>();
                values.add(userName);
                values.add(userPassword);
                values.add(email);
                values.add(firstname);
                values.add(lastname);
                values.add(address);
                values.add(telephone);
                values.add(iban);
                values.add(cnp);
                
                DataBaseConnection.insertValuesIntoTable("customers", attributes, values, true);  
                LoginGraphicUserInterface.displayLoginGraphicUserInterface(false, printWriter);
                            
            }
            else if (!userName.equals("") && !userPassword.equals("") && !userType.equals("")) {
                String userId = getUserID(userName, userPassword, userTable);
                if (!userId.equals(Constants.USER_NONE)) {
                    HttpSession session = request.getSession(true);
                    session.setAttribute(Constants.IDENTIFIER, getUserDisplayName(userName, userPassword, userTable));
                    RequestDispatcher requestDispatcher = null;
                    //System.out.println("req");
                    switch(userType) {
                        case "admin":
                            requestDispatcher = getServletContext().getRequestDispatcher("/AdministratorServlet");
                            break;
                        case "support":
                            session.setAttribute(Constants.ID, userId);
                            requestDispatcher = getServletContext().getRequestDispatcher("/SupportMessagesServlet");
                            break;
                        case "sales":
                            session.setAttribute(Constants.ID, userId);
                            requestDispatcher = getServletContext().getRequestDispatcher("/SalesOrdersServlet");
                            break;
                        case "customer":
                            //getProjects();

                            ArrayList<String> result = getUserAccountSettings(userName, userPassword, userTable);
                            session.setAttribute(Constants.ID, userId);
                            session.setAttribute(Constants.USERNAME, result.get(0));
                            session.setAttribute(Constants.PASSWORD, result.get(1));
                            session.setAttribute(Constants.EMAIL, result.get(2));
                            session.setAttribute(Constants.FIRSTNAME, result.get(3));
                            session.setAttribute(Constants.LASTNAME, result.get(4));
                            session.setAttribute(Constants.ADDRESS, result.get(5));
                            session.setAttribute(Constants.TELEPHONE, result.get(6));
                            session.setAttribute(Constants.IBAN, result.get(7));
                            session.setAttribute(Constants.CNP, result.get(8));
                            session.setAttribute(Constants.AMOUNT, result.get(9));

                            requestDispatcher = getServletContext().getRequestDispatcher("/ClientServlet");
                            break;
                    }
                    if (requestDispatcher!=null) {
                        requestDispatcher.forward(request,response);
                    }
                }
                LoginGraphicUserInterface.displayLoginGraphicUserInterface(isLoginError(userName, userPassword, userTable), printWriter);
           }
            
            else {
                LoginGraphicUserInterface.displayLoginGraphicUserInterface(false, printWriter);
            }
            
        } catch (Exception ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        try (PrintWriter printWriter = new PrintWriter(response.getWriter())) {
            LoginGraphicUserInterface.displayLoginGraphicUserInterface(isLoginError(userName,userPassword, userTable), printWriter);
        }
    }      	 
}
