import dataaccess.DataBaseConnection;
import entities.Record;
import general.Constants;
import graphicuserinterface.AdministratorGraphicUserInterface;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.joda.time.DateTime;
import org.joda.time.Days;

public class AdministratorServlet extends HttpServlet {
    final public static long    serialVersionUID = 10011001L;
    
    private ArrayList<String>   dataBaseStructure;
    private String              selectedTable = "customers";
    private String              userDisplayName;
 
    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        try {
            DataBaseConnection.openConnection();
            dataBaseStructure   = DataBaseConnection.getTableNames();
            selectedTable       = dataBaseStructure.get(0);
        } catch (SQLException exception) {
            System.out.println("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }
    }

    @Override
    public void destroy() {
        try {
            DataBaseConnection.closeConnection();
        } catch (SQLException exception) {
            System.out.println("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }
    }

    public ArrayList<String> getAttributes(ArrayList<Record> records) {
        ArrayList<String> result = new ArrayList<>();
        for (Record record: records) {
            result.add(record.getAttribute());
        }
        return result;
    }

    public ArrayList<String> getValues(String tableName, ArrayList<Record> records) {
        ArrayList<String> result        = new ArrayList<>();       
        ArrayList<String> attributes    = getAttributes(records);
        for (String attribute:attributes) {
            for (Record record: records) {
                if (attribute.equals(record.getAttribute())) {
                    String value = record.getValue();
                    if (value == null || value.equals("")) {
                        value = Constants.INVALID_VALUE;
                    }
                    result.add(value);
                }
            }
        }
        return result;      
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ArrayList<Record> insertRecords  = new ArrayList<>();
        ArrayList<Record> updateRecords  = new ArrayList<>();
        ArrayList<Record> deleteRecords  = new ArrayList<>();
        ArrayList<Record> genericRecords = new ArrayList<>();
        Enumeration parameters = request.getParameterNames();        
        int operation = Constants.OPERATION_NONE;
        String primaryKeyAttribute = new String();
        try {
            primaryKeyAttribute = DataBaseConnection.getTablePrimaryKey(selectedTable);
        } catch (SQLException exception) {
            System.out.println ("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }
        String primaryKeyValue = new String();
        while(parameters.hasMoreElements()) {
            String parameter = (String)parameters.nextElement();
            if (parameter.equals(Constants.LOGOUT.toLowerCase())) {
                operation = Constants.OPERATION_LOGOUT;
            }
            if (parameter.equals(Constants.ADD_BUTTON_NAME.toLowerCase())) {
                operation = Constants.OPERATION_INSERT;
            }
            else if (parameter.contains(Constants.UPDATE_BUTTON_NAME.toLowerCase()+"1_")) {
                operation = Constants.OPERATION_UPDATE_PHASE1;
                primaryKeyValue = parameter.substring(parameter.indexOf("_")+1);
            }
            else if (parameter.contains(Constants.UPDATE_BUTTON_NAME.toLowerCase()+"2_")) {
                operation = Constants.OPERATION_UPDATE_PHASE2;
                primaryKeyValue = parameter.substring(parameter.indexOf("_")+1);
            }            
            else if (parameter.contains(Constants.DELETE_BUTTON_NAME.toLowerCase())) {
                operation = Constants.OPERATION_DELETE;
                primaryKeyValue = parameter.substring(parameter.indexOf("_")+1);
                deleteRecords.add(new Record(primaryKeyAttribute,primaryKeyValue));
            }
            else {
                genericRecords.add(new Record(parameter,request.getParameter(parameter)));
            }
            if (parameter.equals(Constants.SELECTED_TABLE)) {
                selectedTable = request.getParameter(parameter);
            }
            if (parameter.equals("compute")) {
                operation = Constants.OPERATION_COMPUTE;
            }
        }
        response.setContentType("text/html");
        try (PrintWriter printWriter = new PrintWriter(response.getWriter())) {
            switch (operation) {
                case Constants.OPERATION_INSERT:
                    for (Record record:genericRecords) {
                        String attribute = record.getAttribute();
                        String value     = record.getValue();
                        if (attribute.endsWith("_"+Constants.ADD_BUTTON_NAME.toLowerCase())) {
                            insertRecords.add(new Record(attribute.substring(0,attribute.indexOf("_")),value));
                        }
                    }
                    try {
                        DataBaseConnection.insertValuesIntoTable(selectedTable,getAttributes(insertRecords),getValues(selectedTable,insertRecords),false);
                    } catch (Exception exception) {
                        System.out.println ("exceptie: "+exception.getMessage());
                        if (Constants.DEBUG)
                            exception.printStackTrace();
                    }
                    break;
                case Constants.OPERATION_UPDATE_PHASE2:
                    String whereClause = new String();
                    for (Record record:genericRecords) {
                        String attribute = record.getAttribute();
                        String value     = record.getValue();
                        if (attribute.endsWith("_"+primaryKeyValue)) {
                            if (attribute.startsWith(primaryKeyAttribute))
                                whereClause += primaryKeyAttribute + "=\'"+ primaryKeyValue + "\'";
                            else
                                updateRecords.add(new Record(attribute.substring(0,attribute.indexOf("_")),value));
                        }
                    }    
                    try {
                        if (whereClause.isEmpty())
                            whereClause += primaryKeyAttribute + "=\'"+ primaryKeyValue + "\'";
                        DataBaseConnection.updateRecordsIntoTable(selectedTable,getAttributes(updateRecords),getValues(selectedTable,updateRecords),whereClause);
                    } catch (Exception exception) {
                        System.out.println ("exceptie: "+exception.getMessage());
                        if (Constants.DEBUG)
                            exception.printStackTrace();
                    }
                    break;
                case Constants.OPERATION_DELETE:
                    try {
                        DataBaseConnection.deleteRecordsFromTable(selectedTable,getAttributes(deleteRecords),getValues(selectedTable,deleteRecords),null);
                    } catch (Exception exception) {
                        System.out.println ("exceptie: "+exception.getMessage());
                        if (Constants.DEBUG)
                            exception.printStackTrace();
                    }
                    break;
                case Constants.OPERATION_COMPUTE:
                    String query;
                    
                    query = "SELECT AVG(c.salary) FROM contracts c, employees e where e.id = c.employeeID AND e.job = 'qa engineer'";
                    ArrayList<ArrayList<Object>> tableContent = DataBaseConnection.getTableContent2(1, query);
                    float avg_qa = Float.parseFloat(tableContent.get(0).get(0).toString());
                                        
                    query = "SELECT AVG(c.salary) FROM contracts c, employees e where e.id = c.employeeID AND e.job = 'software engineer'";
                    tableContent = DataBaseConnection.getTableContent2(1, query);
                    float avg_se = Float.parseFloat(tableContent.get(0).get(0).toString());
                    
                    query = "SELECT a.id, a.name, a.description, a.category, IFNULL(b.noQA, 0) as noQA, IFNULL(c.noSE, 0) as noSE, GREATEST(IFNULL(b.finish, 0), IFNULL(c.finish, 0)) AS date, GREATEST(IFNULL(b.dif, 0), IFNULL(c.dif, 0)) as days FROM projects a LEFT outer join (SELECT p.id as id, max(tc.finishDate) as finish, DATEDIFF(max(tc.finishDate), min(startDate)) as dif, COUNT(tc.teamMemberID) as noQA FROM projects p, teams t, teams_composition tc, employees e WHERE p.id = t.projectID AND tc.teamID = t.id AND e.id = tc.teamMemberID AND e.job='qa engineer' GROUP BY p.id) b on a.id = b.id left outer join (SELECT p.id as id, max(tc.finishDate) as finish, DATEDIFF(max(tc.finishDate), min(tc.startDate)) as dif, COUNT(tc.teamMemberID) as noSE FROM projects p, teams t, teams_composition tc, employees e WHERE p.id = t.projectID AND tc.teamID = t.id AND e.id = tc.teamMemberID AND e.job='software engineer' GROUP BY p.id) c on a.id = c.id;";
                    tableContent = DataBaseConnection.getTableContent2(8, query);
                    
                    ArrayList<String> attributes = new ArrayList<>();
                    attributes.add("id");
                    attributes.add("availability");
                    ArrayList<ArrayList<Object>> currentProducts = DataBaseConnection.getTableContent("products", attributes, null,null,null);
                    
                    for (ArrayList<Object> tableRow:tableContent) {
                        String id = tableRow.get(0).toString();
                        String name = tableRow.get(1).toString();
                        String description = tableRow.get(2).toString();
                        String category = tableRow.get(3).toString();
                        Integer noQA = Integer.parseInt(tableRow.get(4).toString());
                        Integer noSE = Integer.parseInt(tableRow.get(5).toString());
                        String date = tableRow.get(6).toString();
                        Integer days = Integer.parseInt(tableRow.get(7).toString());
                        
                        String price = String.valueOf(Math.round(days*(noSE*avg_se + noQA*avg_se)/100));
                        System.out.println(tableRow + "==="+price);
                        
                        
                        
                        DateTime productDate = new DateTime(date);
                        
                        boolean isNew = true;
                        
                        String availability = "yes";
                        if (productDate.isAfterNow()){
                            DateTime dt = DateTime.now();
                            int daysBetween = Days.daysBetween(dt, productDate).getDays() + 1;
                            
                            attributes = new ArrayList<>();
                            attributes.add("cValue");
                            ArrayList<ArrayList<Object>> constantsTable = DataBaseConnection.getTableContent("constants", attributes, "cKey = 'productDaysToSoon'",null,null);
                            int productDaysToSoon = Integer.parseInt(constantsTable.get(0).get(0).toString());
                            
                            System.out.println(daysBetween+"-"+productDaysToSoon);
                            
                            if (daysBetween < productDaysToSoon)
                                availability = "soon";
                            else
                                isNew = false;
                        }
                        
                        // 
                        attributes = new ArrayList<>();
                        attributes.add("name");
                        attributes.add("description");
                        attributes.add("date");
                        attributes.add("price");
                        attributes.add("category"); 
                        attributes.add("availability");
                        ArrayList<String> values = new ArrayList<>();
                        values.add(name);
                        values.add(description);
                        values.add(date);
                        values.add(price);
                        values.add(category);    
                        values.add(availability);
                        
                        
                        if (currentProducts!=null && !currentProducts.isEmpty()) {
                            for (ArrayList<Object> product: currentProducts) {
                                String productID = product.get(0).toString();
                                String productAvailability = product.get(1).toString();
                                if (id.equals(productID)){
                                    isNew = false;
                                    if (productAvailability.equals("soon")){
                                        DataBaseConnection.updateRecordsIntoTable("products", attributes, values, null);
                                    }
                                }
                            } 
                        }
                        
                        if (isNew)
                            DataBaseConnection.insertValuesIntoTable("products", attributes, values, true);
                    }  
                    
                    System.out.println("----");
                    break;
                case Constants.OPERATION_LOGOUT:
                    // TO DO (exercise 12): add logic for administrator logout
                    HttpSession session = request.getSession(true);
                    session.invalidate();
                    RequestDispatcher requestDispatcher = null;
                    requestDispatcher = getServletContext().getRequestDispatcher("/");
                    requestDispatcher.forward(request,response);
                    return;
                
            } 	
            
            HttpSession session = request.getSession(true);
            userDisplayName = session.getAttribute(Constants.IDENTIFIER).toString();        
            if (operation == Constants.OPERATION_UPDATE_PHASE1) {
                AdministratorGraphicUserInterface.displayAdministratorGraphicUserInterface(userDisplayName, dataBaseStructure, selectedTable, primaryKeyValue, printWriter);
            }
            else {
                AdministratorGraphicUserInterface.displayAdministratorGraphicUserInterface(userDisplayName, dataBaseStructure, selectedTable, null, printWriter);
            }
        } catch (SQLException ex) {
            Logger.getLogger(AdministratorServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex) {
            Logger.getLogger(AdministratorServlet.class.getName()).log(Level.SEVERE, null, ex);
        }	
    }     

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(true);
        userDisplayName = session.getAttribute(Constants.IDENTIFIER).toString();       
        response.setContentType("text/html");
        try (PrintWriter printWriter = new PrintWriter(response.getWriter())) {
            AdministratorGraphicUserInterface.displayAdministratorGraphicUserInterface(userDisplayName, dataBaseStructure, selectedTable, null, printWriter);
        }
    }  	 
}
