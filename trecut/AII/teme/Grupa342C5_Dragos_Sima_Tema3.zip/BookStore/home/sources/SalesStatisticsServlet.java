import dataaccess.DataBaseConnection;
import entities.Record;
import general.Constants;
import general.Utilities;
import graphicuserinterface.ClientOrdersGUI;
import graphicuserinterface.SalesOrdersGUI;
import graphicuserinterface.SalesStatisticsGUI;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class SalesStatisticsServlet extends HttpServlet {
    final public static long    serialVersionUID = 10021004L;
    
    public String               selectedTable, statisticsType="";
    public String               userDisplayName, userID;
    
    public ArrayList<Record>	shoppingCart;
 
    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        try {
            DataBaseConnection.openConnection();
            selectedTable       = Constants.BOOKS_TABLE;

        } catch (SQLException exception) {
            System.out.println("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }
    }

    @Override
    public void destroy() {
        try {
            DataBaseConnection.closeConnection();
        } catch (SQLException exception) {
            System.out.println("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {       
        HttpSession session = request.getSession(true);
        try (PrintWriter printWriter = new PrintWriter(response.getWriter())) {
            userDisplayName = session.getAttribute(Constants.IDENTIFIER).toString();
            
            userID = session.getAttribute(Constants.ID).toString();
            
            shoppingCart = (ArrayList<Record>)session.getAttribute(Utilities.removeSpaces(Constants.SHOPPING_CART.toLowerCase()));
            if (shoppingCart == null) {
                shoppingCart = new ArrayList<>();
            }            
            String errorMessage = "good";
            Enumeration parameters = request.getParameterNames();
            while(parameters.hasMoreElements()) {
                String parameter = (String)parameters.nextElement();                
                
                // cancel an order that has expired
                if (parameter.contains("cancel") && !request.getParameter(parameter).equals(""))
                {
                    String invoiceNumber = parameter.split("_")[1];
                         
                    ArrayList<String> attributes = new ArrayList<>();
                    attributes.add("status");
                    
                    ArrayList<String> values = new ArrayList<>();
                    values.add("canceled");
                    
                    try {
                        System.out.println(attributes);
                        System.out.println(values);
                        DataBaseConnection.updateRecordsIntoTable("invoices", attributes, values, "number = '" + invoiceNumber + "'");

                    } catch (Exception ex) {
                        Logger.getLogger(ClientAccountServlet.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                
                // logic for getting bought products
                if (parameter.equals("orders")) {
                    //session.invalidate();
                    System.out.println("orders");
                    RequestDispatcher requestDispatcher = null;
                    requestDispatcher = request.getRequestDispatcher("/SalesOrdersServlet");
                    if (requestDispatcher!=null) {
                        requestDispatcher.forward(request,response);
                    }
                    return;
                }
                
                // logic for logout
                if (parameter.equals("deautentificare")) {
                    session.invalidate();
                    RequestDispatcher requestDispatcher = null;
                    requestDispatcher = getServletContext().getRequestDispatcher("/");
                    requestDispatcher.forward(request,response);
                    return;
                }
                
                //
                if (parameter.equals("clientProducts")) {
                    statisticsType = "clientProducts";
                    //System.out.println("clientProducts");
                }
                
                //
                if (parameter.equals("clientAmounts")) {
                    statisticsType = "clientAmounts";
                   // System.out.println("clientAmounts");
                }
                
                //
                if (parameter.equals("products")) {
                    statisticsType = "products";
                    //System.out.println("products");
                }
                
            }
            
            session.setAttribute(Utilities.removeSpaces(Constants.SHOPPING_CART.toLowerCase()), shoppingCart);
            
            response.setContentType("text/html");
            SalesStatisticsGUI.displayClientGraphicUserInterface(userID, errorMessage, selectedTable, statisticsType, shoppingCart,printWriter);
        }
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(true);
        userDisplayName = session.getAttribute(Constants.IDENTIFIER).toString();
        shoppingCart = (ArrayList<Record>)session.getAttribute(Utilities.removeSpaces(Constants.SHOPPING_CART.toLowerCase()));

        response.setContentType("text/html");
        try (PrintWriter printWriter = new PrintWriter(response.getWriter())) {
            SalesStatisticsGUI.displayClientGraphicUserInterface(userDisplayName, null, selectedTable, statisticsType, shoppingCart, printWriter);
        }
    }     	 
}
