package graphicuserinterface;

import dataaccess.DataBaseConnection;
import entities.Record;
import general.Constants;
import general.Utilities;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SalesStatisticsGUI {
    
    public SalesStatisticsGUI() { }
       
    public static String getProductRating(String productID) {
        float result = 0;
        
        try {
            ArrayList<String> attributes = new ArrayList<>();
            attributes.add("rate");
            ArrayList<ArrayList<Object>> tableContent = DataBaseConnection.getTableContent("ratings", attributes, "productID=\'"+productID+"\'",null,null);
            if (tableContent == null || tableContent.get(0) == null || tableContent.get(0).get(0) == null)
                return "-";
            else {
                for (ArrayList<Object> tableRow:tableContent)
                    result += Float.parseFloat(tableRow.get(0).toString());
                result /= tableContent.size();
                return String.valueOf(result);
            }
                
        } catch (SQLException exception) {
            System.out.println("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }  
        return "-";
    }
   
    
    public static void displayClientGraphicUserInterface(String userID, String errorMessage, String currentTableName, String statisticsType, ArrayList<Record> shoppingCart, PrintWriter printWriter) {
        
        System.out.println(statisticsType);
        
        String content = new String();
        content += "<html>\n";
        content += "<head>\n";
        content += "<meta http-equiv=\"content-type\" content=\"text/html; charset=ISO-8859-1\" /><title>CRM</title>\n";
        content += "<link rel=\"stylesheet\" type=\"text/css\" href=\"css/bookstore.css\" />\n";  
        content += "<link rel=\"stylesheet\" href=\"css/bookstore.css\" media=\"screen\" type=\"text/css\" />\n";
        content += "</head>\n";   
        
        content += "    <form name=\"formular\" action=\"SalesStatisticsServlet\" method=\"POST\">\n";
        content += "        <input type=\"submit\" name=\"orders\" value=\"Orders\" />";
        content += "        <input type=\"submit\" name=\"clientProducts\" value=\"Clients with many products bought\" />";
        content += "        <input type=\"submit\" name=\"clientAmounts\" value=\"Clients with largest amounts spent\" />";
        content += "        <input type=\"submit\" name=\"products\" value=\"Most bought products\" />";
        content += "        <input type=\"submit\" name=\"deautentificare\" value=\"Log Out\" />";
        content += "    </form>\n";
        
        content += "<body>\n";
              
        content += "<center>\n";
        
        

        content += "    <form name=\"formular\" action=\"SalesStatisticsServlet\" method=\"POST\">\n";
        content += "        <table  bgcolor=\"#ffffff\" border=\"0\" cellpadding=\"4\" cellspacing=\"1\"><tbody>\n";
        content += "            <tr>\n";
        content += "                <td align=\"left\" valign=\"top\"></td>\n";
        content += "                <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>\n";
        content += "                <td width=\"60%\" align=\"center\">\n";
        try {
            if (errorMessage != null)
                content += errorMessage + "<br/><br/>\n";
            ArrayList<String> attributes = new ArrayList<>();
            switch (statisticsType) {
                case "clientAmounts":
                    attributes.add("c.firstname");
                    attributes.add("c.lastname");
                    attributes.add("SUM(d.items*p.price) as product");
                    String whereClause = "d.invoiceNumber=i.number AND c.id = i.customerID AND i.status='paid' and p.id = d.productID";
                    String orderByClause = "product DESC";
                    String groupByClause = "i.customerID";
                    ArrayList<ArrayList<Object>> tableContent = DataBaseConnection.getTableContent("details_invoices d, invoices i, customers c, products p",attributes,whereClause,orderByClause,groupByClause);
                    content += "<table  bgcolor=\"#ffffff\" border=\"0\" cellpadding=\"4\" cellspacing=\"1\"><tbody>\n";
                    for (ArrayList<Object> tableRow:tableContent) {
                        //String currentPrimaryKey = tableRow.get(0).toString();
                        content += "<tr>\n";
                        content += "<td bgcolor=\"#ebebeb\">\n";

                        content += "First Name: "+tableRow.get(0).toString()+"<br/>\n";
                        content += "Last Name: "+tableRow.get(1).toString()+"<br/>\n";
                        content += "Amount: "+tableRow.get(2).toString()+"<br/>\n";

                        content += "</td>\n";
                        content += "</tr><tr><td colspan=\"3\">&nbsp;</td></tr>\n";
                    }   
                    content += "</tbody></table>\n";
                    content += "</td>\n";
                    content += "<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>\n";
                    content += "<td align=\"left\" valign=\"top\">\n";
                    break;
                case "products":
                    attributes.add("p.name");
                    attributes.add("SUM(d.items) as sum");
                    whereClause = "d.invoiceNumber=i.number AND i.status='paid' and p.id = d.productID";
                    orderByClause = "sum DESC";
                    groupByClause = "d.productID";
                    tableContent = DataBaseConnection.getTableContent("details_invoices d, invoices i, products p",attributes,whereClause,orderByClause,groupByClause);
                    content += "<table  bgcolor=\"#ffffff\" border=\"0\" cellpadding=\"4\" cellspacing=\"1\"><tbody>\n";
                    for (ArrayList<Object> tableRow:tableContent) {
                        content += "<tr>\n";
                        content += "<td bgcolor=\"#ebebeb\">\n";

                        content += "Name: "+tableRow.get(0).toString()+"<br/>\n";
                        content += "No items: "+tableRow.get(1).toString()+"<br/>\n";

                        content += "</td>\n";
                        content += "</tr><tr><td colspan=\"3\">&nbsp;</td></tr>\n";
                    }   
                    content += "</tbody></table>\n";
                    content += "</td>\n";
                    content += "<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>\n";
                    content += "<td align=\"left\" valign=\"top\">\n";
                    break;
                default:
                    attributes.add("c.firstname");
                    attributes.add("c.lastname");
                    attributes.add("SUM(d.items) as items");
                    whereClause = "d.invoiceNumber=i.number and i.status='paid' and c.id = i.customerID";
                    orderByClause = "items DESC";
                    groupByClause = "i.customerID";
                    tableContent = DataBaseConnection.getTableContent("details_invoices d, invoices i, customers c",attributes,whereClause,orderByClause,groupByClause);
                    content += "<table  bgcolor=\"#ffffff\" border=\"0\" cellpadding=\"4\" cellspacing=\"1\"><tbody>\n";
                    for (ArrayList<Object> tableRow:tableContent) {
                        //String currentPrimaryKey = tableRow.get(0).toString();
                        content += "<tr>\n";
                        content += "<td bgcolor=\"#ebebeb\">\n";

                        content += "First Name: "+tableRow.get(0).toString()+"<br/>\n";
                        content += "Last Name: "+tableRow.get(1).toString()+"<br/>\n";
                        content += "No of items: "+tableRow.get(2).toString()+"<br/>\n";

                        content += "</td>\n";
                        content += "</tr><tr><td colspan=\"3\">&nbsp;</td></tr>\n";
                    }   
                    content += "</tbody></table>\n";
                    content += "</td>\n";
                    content += "<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>\n";
                    content += "<td align=\"left\" valign=\"top\">\n";
                    break;
            }
            
            

        } catch (SQLException exception) {
            System.out.println ("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }  
            
        content += "</form>\n";
        content += "</center>\n";
        content += "</body>\n";
        content += "</html>";  
        printWriter.println(content);
    }    
}
