package graphicuserinterface;

import dataaccess.DataBaseConnection;
import entities.Record;
import general.Constants;
import general.Utilities;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class ClientProductsGUI {
    
    public ClientProductsGUI() { }
    
    public static String getProductRating(String productID) {
        float result = 0;
        
        try {
            ArrayList<String> attributes = new ArrayList<>();
            attributes.add("rate");
            ArrayList<ArrayList<Object>> tableContent = DataBaseConnection.getTableContent("ratings", attributes, "productID=\'"+productID+"\'",null,null);
            if (tableContent == null || tableContent.get(0) == null || tableContent.get(0).get(0) == null)
                return "-";
            else {
                for (ArrayList<Object> tableRow:tableContent)
                    result += Float.parseFloat(tableRow.get(0).toString());
                result /= tableContent.size();
                return String.valueOf(result);
            }
                
        } catch (SQLException exception) {
            System.out.println("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }  
        return "-";
    }
    
    public static void displayClientGraphicUserInterface(String userID, String errorMessage, String currentTableName, String searchTokens, String selectedOrder,  ArrayList<Record> shoppingCart, PrintWriter printWriter) {
        currentTableName = "products";
        String content = new String();
        content += "<html>\n";
        content += "<head>\n";
        content += "<meta http-equiv=\"content-type\" content=\"text/html; charset=ISO-8859-1\" /><title>CRM</title>\n";
        content += "<link rel=\"stylesheet\" type=\"text/css\" href=\"css/bookstore.css\" />\n";  
        content += "<link rel=\"stylesheet\" href=\"css/bookstore.css\" media=\"screen\" type=\"text/css\" />\n";
        content += "</head>\n";   
        
        content += "    <form name=\"formular\" action=\"ClientProductsServlet\" method=\"POST\">\n";
        content += "        <input type=\"submit\" name=\"shop\" value=\"Shop\" />";
        content += "        <input type=\"submit\" name=\"orders\" value=\"Orders\" />";
        content += "        <input type=\"submit\" name=\"settings\" value=\"Settings\" />";
        content += "        <input type=\"submit\" name=\"account\" value=\"Account\" />";
        content += "        <input type=\"submit\" name=\"products\" value=\"Products\" />";
        content += "        <input type=\"submit\" name=\"deautentificare\" value=\"Log Out\" />";
        content += "    </form>\n";
        
        content += "<body>\n";
              
        content += "<center>\n";
        
        content += "    <form name=\"formularX\" action=\"ClientProductsServlet\" method=\"POST\">\n";
        content += "        Search <input type=\"search\" name=\"search\"><br>";
        content += "        <select name=\"selectedOrder\" onchange=\"document.formularX.submit()\">\n";
        content += "            <option value=\"byName\" SELECTED>Name</option>\n";
        content += "            <option value=\"byPriceAsc\">Price ASC</option>\n";
        content += "            <option value=\"byPriceDesc\">Price DESC</option>\n";
        content += "            <option value=\"byRating\">Rating</option>\n";
        content += "        </select>\n";
        content += "    </form>\n";
        
        content += "    <form name=\"formularZ\" action=\"ClientProductsServlet\" method=\"POST\" id=\"usrform\">\n";
        content += "<table  bgcolor=\"#ffffff\" border=\"0\" cellpadding=\"4\" cellspacing=\"1\"><tbody>\n";
        content += "<tr>\n";
        content += "<td align=\"left\" valign=\"top\">\n";

        content += "</td>\n";
        content += "<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>\n";
        content += "<td width=\"60%\" align=\"center\">\n";
        try {
            if (errorMessage != null)
                content += errorMessage + "<br/><br/>\n";
            ArrayList<String> attributes = DataBaseConnection.getTableAttributes(currentTableName);
            String whereClause = "availability=\"yes\"";
            
            String orderByClause = new String();

            // construct orderClause to display products in the wanted order
            if (selectedOrder.equals("byName"))
                orderByClause = "name";
            else if (selectedOrder.equals("byPriceAsc"))
                orderByClause = "price ASC";
            else if (selectedOrder.equals("byPriceDesc"))
                 orderByClause = "price DESC";
            else if (selectedOrder.equals("byRating"))
                orderByClause = "rate DESC";
            
            // construct whereClause to display products containing certain words
            System.out.println(searchTokens);
            
            if (!searchTokens.equals("")){
                ArrayList<String> tokens = new ArrayList<>();
                if (searchTokens.contains(" ")){
                    String[] array = searchTokens.split("\\s+");
                    for(String str : array)
                    {
                        tokens.add(str);
                        //whereClause += " like '%Adobe%' or name like '%Microsoft%'";
                    }
                }
                else
                    tokens.add(searchTokens);
                
                whereClause += " AND ";
                for (int j = 0; j < tokens.size(); j++) {
                    whereClause += "name like '%" + tokens.get(j) + "%'";
                    if (j < tokens.size() - 1)
                        whereClause += " OR ";
                }
            }
            
            System.out.println(whereClause);
            
            ArrayList<ArrayList<Object>> tableContent = DataBaseConnection.getTableContent(currentTableName,attributes,(whereClause.length()!=0?whereClause:null),(orderByClause.length()!=0?orderByClause:null),null);
            content += "<table  bgcolor=\"#ffffff\" border=\"0\" cellpadding=\"4\" cellspacing=\"1\"><tbody>\n";
            for (ArrayList<Object> tableRow:tableContent) {
                String currentPrimaryKey = tableRow.get(0).toString();
                String rating = tableRow.get(6).toString();
               
                
                attributes = new ArrayList<>();
                attributes.add("rate");
                
                boolean isProductBought = false;
                ArrayList<ArrayList<Object>> result =  new ArrayList<>();
                try {
                    ArrayList<ArrayList<Object>> rate = DataBaseConnection.getTableContent("ratings", attributes, "customerID = '"+userID+"' AND productID = '"+currentPrimaryKey+"'",null,null);
                    if (rate != null && rate.size() != 0){
                        isProductBought = true;
                    }
                                       
                    String tables = "invoices i, details_invoices di";
                    attributes = new ArrayList<>();
                    attributes.add("di.productID"); 
                    attributes.add("di.invoiceNumber");
                    result = DataBaseConnection.getTableContent(tables, attributes, "i.customerID = '"+userID+"' AND i.status = 'paid' AND di.productID = '"+currentPrimaryKey+"' AND di.invoiceNumber = i.number",null,null);

                    if (result != null && result.size() != 0){
                        isProductBought = true;
                    }
                    
                } catch (Exception exception) {
                    System.out.println ("exceptie: "+exception.getMessage());
                    if (Constants.DEBUG){
                        exception.printStackTrace();
                        errorMessage =  exception.toString();
                    }
                }
                
                if (isProductBought){
                     content += "<tr>\n";
                    content += "<td valign=\"left\"><img src=\"images/"+Utilities.removeSpaces(tableRow.get(DataBaseConnection.getAttributeIndexInTable(currentTableName, "id")).toString().toLowerCase())+".jpg\" height=\"100\" width=\"100\"/></td>\n";
                    content += "<td>&nbsp</td>\n";
                    content += "<td bgcolor=\"#ebebeb\">\n";

                    content += tableRow.get(1).toString()+"<br/>\n";
                    content += tableRow.get(2).toString()+"<br/>\n";
                    content += tableRow.get(4).toString()+" &euro;<br/>\n";

                    if (rating.equals("0"))
                        rating = "-";
                    content += rating + " stars<br/>\n";
                
                    content += "Rate it: <input type=\"radio\" name=\"rate_" + currentPrimaryKey + "\" value=\"1\">1";
                    content += "        <input type=\"radio\" name=\"rate_" + currentPrimaryKey + "\" value=\"2\">2";
                    content += "        <input type=\"radio\" name=\"rate_" + currentPrimaryKey + "\" value=\"3\">3";
                    content += "        <input type=\"radio\" name=\"rate_" + currentPrimaryKey + "\" value=\"4\">4";
                    content += "        <input type=\"radio\" name=\"rate_" + currentPrimaryKey + "\" value=\"5\">5";
                    content += "<input type=\"submit\" name=\"rateIt\" value=\"Rate\"/><br/>\n";
                    
                    System.out.println("aici");
                    for (ArrayList<Object> row : result){
                        String invoiceID = row.get(1).toString();
                        System.out.println(invoiceID);
                        
                    
                        attributes = new ArrayList<>();
                        attributes.add("message");
                        attributes.add("date");
                        attributes.add("status");
                        attributes.add("id");
                        
                        ArrayList<ArrayList<Object>> problems = DataBaseConnection.getTableContent("problems", attributes, "customerID = '"+userID+"' AND productID = '" + currentPrimaryKey + "' AND invoiceNumber = '" + invoiceID +"'",null,null);
                        
                        if (problems != null && problems.size() != 0) {
                            System.out.println(problems);
                            content += "<br/>Issue "+ problems.get(0).get(2).toString().toUpperCase() +" at " + problems.get(0).get(1) + " for " + invoiceID + "<br/>";
                            content += "You said: '" + problems.get(0).get(0) + "'<br/>";
                            
                            String problemID = problems.get(0).get(3).toString();
                            
                            attributes = new ArrayList<>();
                            attributes.add("employeeID");
                            attributes.add("problemID");
                            attributes.add("message");
                            ArrayList<ArrayList<Object>> messages = DataBaseConnection.getTableContent("messages", attributes, "problemID = '"+problemID+"'",null,null);
                            
                            if (messages != null && messages.size() != 0) {
                                String employeeID = messages.get(0).get(0).toString();
                                String message = messages.get(0).get(2).toString();
                                
                                
                                 attributes = new ArrayList<>();
                                 attributes.add("username");
                                 ArrayList<ArrayList<Object>> employees = DataBaseConnection.getTableContent("employees", attributes, "id = '"+employeeID+"'",null,null);
                                 
                                 String employee = employees.get(0).get(0).toString();
                                 
                                content += employee + " answered: '" + message + "'<br/>";
                            }
                        } 
                        else {
                            content += "<textarea rows=\"4\" cols=\"50\" name=\"comment_" + currentPrimaryKey +"_"+invoiceID +" form=\"usrform\"></textarea><br/>";
                            content += "<input type=\"submit\" name=\"report_"+currentPrimaryKey+"\" value=\"Send\"/>\n";
                            content += "for invoice " + invoiceID + "<br/>";
                        }
                    }                     
                }
 
                content += "</td>\n";
                content += "</tr><tr><td colspan=\"3\">&nbsp;</td></tr>\n";
            }
            content += "</tbody></table>\n";
            content += "</td>\n";
            content += "<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>\n";
            content += "<td align=\"left\" valign=\"top\">\n";
 
            content += "</td>\n";
            content += "</tr>\n";
            content += "</tbody></table>\n";

        } catch (SQLException exception) {
            System.out.println ("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }       
        content += "</form>\n";
        content += "</center>\n";
        content += "</body>\n";
        content += "</html>";  
        printWriter.println(content);
    }    
}
