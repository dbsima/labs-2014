package graphicuserinterface;

import dataaccess.DataBaseConnection;
import entities.Record;
import general.Constants;
import general.Utilities;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SalesOrdersGUI {
    
    public SalesOrdersGUI() { }
       
    public static String getProductRating(String productID) {
        float result = 0;
        
        try {
            ArrayList<String> attributes = new ArrayList<>();
            attributes.add("rate");
            ArrayList<ArrayList<Object>> tableContent = DataBaseConnection.getTableContent("ratings", attributes, "productID=\'"+productID+"\'",null,null);
            if (tableContent == null || tableContent.get(0) == null || tableContent.get(0).get(0) == null)
                return "-";
            else {
                for (ArrayList<Object> tableRow:tableContent)
                    result += Float.parseFloat(tableRow.get(0).toString());
                result /= tableContent.size();
                return String.valueOf(result);
            }
                
        } catch (SQLException exception) {
            System.out.println("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }  
        return "-";
    }
   
    
    public static void displayClientGraphicUserInterface(String userID, String errorMessage, String currentTableName, String selectedOrder, ArrayList<Record> shoppingCart, PrintWriter printWriter) {
        
        System.out.println("hereeeeeeeee");
        
        currentTableName = "invoices";
        String content = new String();
        content += "<html>\n";
        content += "<head>\n";
        content += "<meta http-equiv=\"content-type\" content=\"text/html; charset=ISO-8859-1\" /><title>CRM</title>\n";
        content += "<link rel=\"stylesheet\" type=\"text/css\" href=\"css/bookstore.css\" />\n";  
        content += "<link rel=\"stylesheet\" href=\"css/bookstore.css\" media=\"screen\" type=\"text/css\" />\n";
        content += "</head>\n";   
        
        content += "    <form name=\"formular\" action=\"SalesOrdersServlet\" method=\"POST\">\n";
        content += "        <input type=\"submit\" name=\"statistics\" value=\"Statistics\" />";
        content += "        <input type=\"submit\" name=\"deautentificare\" value=\"Log Out\" />";
        content += "    </form>\n";
        
        content += "<body>\n";
              
        content += "<center>\n";
        
        ArrayList<String> attributes = new ArrayList<>();

        content += "    <form name=\"formular\" action=\"SalesOrdersServlet\" method=\"POST\">\n";
        content += "        <table  bgcolor=\"#ffffff\" border=\"0\" cellpadding=\"4\" cellspacing=\"1\"><tbody>\n";
        content += "            <tr>\n";
        content += "                <td align=\"left\" valign=\"top\"></td>\n";
        content += "                <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>\n";
        content += "                <td width=\"60%\" align=\"center\">\n";
        try {
            if (errorMessage != null)
                content += errorMessage + "<br/><br/>\n";
            attributes.add("DATE_ADD(date, INTERVAL cValue DAY) < NOW()");
            attributes.add("number");
            attributes.add("date");
            attributes.add("amount");           
            attributes.add("customerID");
            
            String whereClause = "status = 'issued' AND cKey = 'invoiceDaysToDeath'";
            String orderByClause = "";
                    
            ArrayList<ArrayList<Object>> tableContent = DataBaseConnection.getTableContent("invoices, constants",attributes,whereClause,null,null);
            
            content += "<table  bgcolor=\"#ffffff\" border=\"0\" cellpadding=\"4\" cellspacing=\"1\"><tbody>\n";
            for (ArrayList<Object> tableRow:tableContent) {
                //String currentPrimaryKey = tableRow.get(0).toString();
                String expired = tableRow.get(0).toString();
                if (expired.equals("1"))
                {
                    content += "<tr>\n";
                    content += "<td bgcolor=\"#ebebeb\">\n";
                    String number = tableRow.get(1).toString();

                    content += "Number: "+number+"<br/>\n";
                    content += "Date: "+tableRow.get(2).toString()+"<br/>\n";
                    content += "Amount: "+tableRow.get(3).toString()+"&euro;<br/>\n";

                    attributes = new ArrayList<>();
                    attributes.add("d.items");
                    attributes.add("p.name");
                    attributes.add("p.price");

                    ArrayList<ArrayList<Object>> detailsContent = DataBaseConnection.getTableContent("details_invoices d, products p",attributes,"d.productID=p.id and  invoiceNumber='" + number+"'",(orderByClause.length()!=0?orderByClause:null),null);

                    content += "Details: <br/>\n";
                    for (ArrayList<Object> detail:detailsContent) {
                        String items = detail.get(0).toString();
                        String name = detail.get(1).toString();
                        String price = detail.get(2).toString();
                        content += "&nbsp;&nbsp;&nbsp;" + items + " x " + name + " at " + price + "&euro;<br/>";
                    }
                    content += "<input type=\"submit\" name=\"cancel_"+number+"\" value=\"Cancel\"/><br/>\n";

                    content += "</td>\n";
                    content += "</tr><tr><td colspan=\"3\">&nbsp;</td></tr>\n";
                }
            }
            content += "</tbody></table>\n";
            content += "</td>\n";
            content += "<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>\n";
            content += "<td align=\"left\" valign=\"top\">\n";
            

        } catch (SQLException exception) {
            System.out.println ("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }       
        content += "</form>\n";
        content += "</center>\n";
        content += "</body>\n";
        content += "</html>";  
        printWriter.println(content);
    }    
}
