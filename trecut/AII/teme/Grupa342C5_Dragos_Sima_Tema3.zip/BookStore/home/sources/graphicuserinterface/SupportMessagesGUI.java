package graphicuserinterface;

import dataaccess.DataBaseConnection;
import entities.Record;
import general.Constants;
import general.Utilities;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class SupportMessagesGUI {
    
    public SupportMessagesGUI() { }
    
    public static String getProductRating(String productID) {
        float result = 0;
        
        try {
            ArrayList<String> attributes = new ArrayList<>();
            attributes.add("rate");
            ArrayList<ArrayList<Object>> tableContent = DataBaseConnection.getTableContent("ratings", attributes, "productID=\'"+productID+"\'",null,null);
            if (tableContent == null || tableContent.get(0) == null || tableContent.get(0).get(0) == null)
                return "-";
            else {
                for (ArrayList<Object> tableRow:tableContent)
                    result += Float.parseFloat(tableRow.get(0).toString());
                result /= tableContent.size();
                return String.valueOf(result);
            }
                
        } catch (SQLException exception) {
            System.out.println("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }  
        return "-";
    }
    
    public static void displayClientGraphicUserInterface(String userID, String errorMessage, String currentTableName, String searchTokens, String selectedOrder,  ArrayList<Record> shoppingCart, PrintWriter printWriter) {
        currentTableName = "problems";
        String content = new String();
        content += "<html>\n";
        content += "<head>\n";
        content += "<meta http-equiv=\"content-type\" content=\"text/html; charset=ISO-8859-1\" /><title>CRM</title>\n";
        content += "<link rel=\"stylesheet\" type=\"text/css\" href=\"css/bookstore.css\" />\n";  
        content += "<link rel=\"stylesheet\" href=\"css/bookstore.css\" media=\"screen\" type=\"text/css\" />\n";
        content += "</head>\n";   
        
        content += "    <form name=\"formular\" action=\"SupportMessagesServlet\" method=\"POST\">\n";
        content += "        <input type=\"submit\" name=\"deautentificare\" value=\"Log Out\" />";
        content += "    </form>\n";
        
        content += "<body>\n";
              
        content += "<center>\n";
        
        
        content += "    <form name=\"formularZ\" action=\"SupportMessagesServlet\" method=\"POST\" id=\"usrform\">\n";
        content += "<table  bgcolor=\"#ffffff\" border=\"0\" cellpadding=\"4\" cellspacing=\"1\"><tbody>\n";
        content += "<tr>\n";
        content += "<td align=\"left\" valign=\"top\">\n";

        content += "</td>\n";
        content += "<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>\n";
        content += "<td width=\"60%\" align=\"center\">\n";
        try {
            if (errorMessage != null)
                content += errorMessage + "<br/><br/>\n";
            ArrayList<String> attributes = new ArrayList<>();
            attributes.add("id");
            attributes.add("customerID");
            attributes.add("productID");
            attributes.add("invoiceNumber   ");
            attributes.add("message");
            attributes.add("date");
            attributes.add("status");
            attributes.add("priority");
            
            String orderByClause = "priority DESC, date DESC";
            
            ArrayList<ArrayList<Object>> tableContent = DataBaseConnection.getTableContent(currentTableName,attributes,null,orderByClause,null);
            content += "<table  bgcolor=\"#ffffff\" border=\"0\" cellpadding=\"4\" cellspacing=\"1\"><tbody>\n";
            for (ArrayList<Object> tableRow:tableContent) {
                String problemID = tableRow.get(0).toString();
                content += "<tr>\n";
                content += "<td bgcolor=\"#ebebeb\">\n";
                
                content += "CusomerID: " + tableRow.get(1).toString()+"<br/>\n";
                content += "ProductID: " + tableRow.get(2).toString()+"<br/>\n";
                content += "InvoiceNumber: " + tableRow.get(3).toString()+"<br/>\n";
                content += "Date: " + tableRow.get(5).toString()+"<br/>\n";
                String status = tableRow.get(6).toString();
                content += "Status: " + status +"<br/>\n";
                content += "Priority: " + tableRow.get(7).toString()+"<br/>\n";
                content += "Message: " + tableRow.get(4).toString()+"<br/>\n";
                
                if (status.equals("open")) {
                    content += "Priority new level: <input type=\"radio\" name=\"level_" + problemID + "\" value=\"1\">1";
                    content += "        <input type=\"radio\" name=\"level_" + problemID + "\" value=\"2\">2";
                    content += "        <input type=\"radio\" name=\"level_" + problemID + "\" value=\"3\">3";
                    content += "<input type=\"submit\" name=\"modifyLevel\" value=\"Modify\"/><br/>\n";
                
                    content += "<textarea rows=\"4\" cols=\"50\" name=\"comment_" + problemID +" form=\"usrform\"></textarea><br/>";
                    content += "<input type=\"submit\" name=\"report_"+problemID+"\" value=\"Send\"/>\n";
                }
                else {
                    attributes = new ArrayList<>();
                    attributes.add("employeeID");
                    attributes.add("message");
                    ArrayList<ArrayList<Object>> messages = DataBaseConnection.getTableContent("messages", attributes, "problemID = '"+problemID+"'",null,null);

                    if (messages != null && messages.size() != 0) {
                         String employeeID = messages.get(0).get(0).toString();
                         String message = messages.get(0).get(1).toString();
                         
                         if (employeeID.equals(userID)) {
                             content += "You answered: '" + message + "'<br/>";
                         }
                         else {
                            attributes = new ArrayList<>();
                            attributes.add("username");
                            ArrayList<ArrayList<Object>> employees = DataBaseConnection.getTableContent("employees", attributes, "id = '"+employeeID+"'",null,null);

                            String employee = employees.get(0).get(0).toString();
                            content += employee + " answered: '" + message + "'<br/>";
                         }
                    }
                }
                content += "</td>\n";
                content += "</tr><tr><td colspan=\"3\">&nbsp;</td></tr>\n";
            }
            content += "</tbody></table>\n";
            content += "</td>\n";
            content += "<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>\n";
            content += "<td align=\"left\" valign=\"top\">\n";
 
            content += "</td>\n";
            content += "</tr>\n";
            content += "</tbody></table>\n";

        } catch (SQLException exception) {
            System.out.println ("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }       
        content += "</form>\n";
        content += "</center>\n";
        content += "</body>\n";
        content += "</html>";  
        printWriter.println(content);
    }    
}
