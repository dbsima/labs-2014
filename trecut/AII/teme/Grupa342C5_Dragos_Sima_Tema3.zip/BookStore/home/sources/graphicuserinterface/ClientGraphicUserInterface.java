package graphicuserinterface;

import dataaccess.DataBaseConnection;
import entities.Record;
import general.Constants;
import general.Utilities;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class ClientGraphicUserInterface {
    
    public ClientGraphicUserInterface() { }
    
    public static String getProductRating(String productID) {
        float result = 0;
        
        try {
            ArrayList<String> attributes = new ArrayList<>();
            attributes.add("rate");
            ArrayList<ArrayList<Object>> tableContent = DataBaseConnection.getTableContent("ratings", attributes, "productID=\'"+productID+"\'",null,null);
            if (tableContent == null || tableContent.get(0) == null || tableContent.get(0).get(0) == null)
                return "-";
            else {
                for (ArrayList<Object> tableRow:tableContent)
                    result += Float.parseFloat(tableRow.get(0).toString());
                result /= tableContent.size();
                return String.valueOf(result);
            }
                
        } catch (SQLException exception) {
            System.out.println("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }  
        return "-";
    }
    
    public static void displayClientGraphicUserInterface(String userID, String errorMessage, String currentTableName, String searchTokens, String selectedOrder,  ArrayList<Record> shoppingCart, PrintWriter printWriter) {
        currentTableName = "products";
        String content = new String();
        content += "<html>\n";
        content += "<head>\n";
        content += "<meta http-equiv=\"content-type\" content=\"text/html; charset=ISO-8859-1\" /><title>CRM</title>\n";
        content += "<link rel=\"stylesheet\" type=\"text/css\" href=\"css/bookstore.css\" />\n";  
        content += "<link rel=\"stylesheet\" href=\"css/bookstore.css\" media=\"screen\" type=\"text/css\" />\n";
        content += "</head>\n";   
        
        content += "    <form name=\"formular\" action=\"ClientServlet\" method=\"POST\">\n";
        content += "        <input type=\"submit\" name=\"shop\" value=\"Shop\" />";
        content += "        <input type=\"submit\" name=\"orders\" value=\"Orders\" />";
        content += "        <input type=\"submit\" name=\"settings\" value=\"Settings\" />";
        content += "        <input type=\"submit\" name=\"account\" value=\"Account\" />";
        content += "        <input type=\"submit\" name=\"products\" value=\"Products\" />";
        content += "        <input type=\"submit\" name=\"deautentificare\" value=\"Log Out\" />";
        content += "    </form>\n";
        
        content += "<body>\n";
              
        content += "<center>\n";
        
        content += "    <form name=\"formularX\" action=\"ClientServlet\" method=\"POST\">\n";
        content += "        Search <input type=\"search\" name=\"search\"><br>";
        content += "        <select name=\"selectedOrder\" onchange=\"document.formularX.submit()\">\n";
        content += "            <option value=\"byName\" SELECTED>Name</option>\n";
        content += "            <option value=\"byPriceAsc\">Price ASC</option>\n";
        content += "            <option value=\"byPriceDesc\">Price DESC</option>\n";
        content += "            <option value=\"byRating\">Rating</option>\n";
        content += "        </select>\n";
        content += "    </form>\n";
        
        content += "    <form name=\"formular\" action=\"ClientServlet\" method=\"POST\">\n";
        content += "<table  bgcolor=\"#ffffff\" border=\"0\" cellpadding=\"4\" cellspacing=\"1\"><tbody>\n";
        content += "<tr>\n";
        content += "<td align=\"left\" valign=\"top\">\n";

        content += "</td>\n";
        content += "<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>\n";
        content += "<td width=\"60%\" align=\"center\">\n";
        try {
            if (errorMessage != null)
                content += errorMessage + "<br/><br/>\n";
            
            ArrayList<String> attributes = new ArrayList<>();
            attributes.add("category");
            attributes.add("SUM(d.items) as sum");
            
            String orderByClause = "sum DESC";
            String groupByClause = "p.category";
            ArrayList<ArrayList<Object>> categoryTable = DataBaseConnection.getTableContent("details_invoices d, invoices i, customers c, products p", attributes, "d.invoiceNumber=i.number and i.status='paid' and c.id = i.customerID and d.id = p.id and c.id = '"+userID+"'",orderByClause,groupByClause);
            
            

            attributes = DataBaseConnection.getTableAttributes(currentTableName);
            String whereClause = "availability=\"yes\"";
            
            orderByClause = "category";

            // construct orderClause to display products in the wanted order
            if (selectedOrder.equals("byName"))
                orderByClause = "name";
            else if (selectedOrder.equals("byPriceAsc"))
                orderByClause = "price ASC";
            else if (selectedOrder.equals("byPriceDesc"))
                 orderByClause = "price DESC";
            else if (selectedOrder.equals("byRating"))
                orderByClause = "rate DESC";
            
            // construct whereClause to display products containing certain words
            System.out.println(searchTokens);
            
            if (!searchTokens.equals("")){
                ArrayList<String> tokens = new ArrayList<>();
                if (searchTokens.contains(" ")){
                    String[] array = searchTokens.split("\\s+");
                    for(String str : array)
                    {
                        tokens.add(str);
                        //whereClause += " like '%Adobe%' or name like '%Microsoft%'";
                    }
                }
                else
                    tokens.add(searchTokens);
                
                whereClause += " AND ";
                for (int j = 0; j < tokens.size(); j++) {
                    whereClause += "name like '%" + tokens.get(j) + "%'";
                    if (j < tokens.size() - 1)
                        whereClause += " OR ";
                }
            }
            
            System.out.println(whereClause);
            
            ArrayList<ArrayList<Object>> tableContent = DataBaseConnection.getTableContent(currentTableName,attributes,(whereClause.length()!=0?whereClause:null),(orderByClause.length()!=0?orderByClause:null),null);
            //int primayKeyIndex = DataBaseConnection.getAttributeIndexInTable(currentTableName, DataBaseConnection.getTablePrimaryKey(currentTableName));
            content += "<table  bgcolor=\"#ffffff\" border=\"0\" cellpadding=\"4\" cellspacing=\"1\"><tbody>\n";
            
            if (categoryTable!=null && !categoryTable.isEmpty()){
                for (ArrayList<Object> row: categoryTable){
                    
                    String category = row.get(0).toString();
                    System.out.println(category);
                    for (ArrayList<Object> tableRow:tableContent) {
                        
                        String pCategory = tableRow.get(7).toString();
                        if (pCategory.equals(category)){
                        
                        String currentPrimaryKey = tableRow.get(0).toString();
                        content += "<tr>\n";
                        content += "<td valign=\"left\"><img src=\"images/"+Utilities.removeSpaces(tableRow.get(DataBaseConnection.getAttributeIndexInTable(currentTableName, "id")).toString().toLowerCase())+".jpg\" height=\"100\" width=\"100\"/></td>\n";
                        content += "<td>&nbsp</td>\n";
                        content += "<td bgcolor=\"#ebebeb\">\n";

                        content += "Name: "+tableRow.get(1).toString()+"<br/>\n";
                        content += "Description: "+tableRow.get(2).toString()+"<br/>\n";
                        content += "Price: "+tableRow.get(4).toString()+" &euro;<br/>\n";
                        String rating = tableRow.get(6).toString();
                        if (rating.equals("0"))
                            rating = "-";
                        content += "Rating: "+rating+"<br/>\n";

                        attributes = new ArrayList<>();
                        attributes.add("rate");
                        try {
                            ArrayList<ArrayList<Object>> rate = DataBaseConnection.getTableContent("ratings", attributes, "customerID = '"+userID+"' AND productID = '"+currentPrimaryKey+"'",null,null);
                            if (rate != null && rate.size() != 0){
                                content += "Rated at: "+rate.get(0).get(0).toString()+"<br/>\n";
                                content += "Rate it again: <input type=\"radio\" name=\"rate_" + currentPrimaryKey + "\" value=\"1\">1";
                                content += "        <input type=\"radio\" name=\"rate_" + currentPrimaryKey + "\" value=\"2\">2";
                                content += "        <input type=\"radio\" name=\"rate_" + currentPrimaryKey + "\" value=\"3\">3";
                                content += "        <input type=\"radio\" name=\"rate_" + currentPrimaryKey + "\" value=\"4\">4";
                                content += "        <input type=\"radio\" name=\"rate_" + currentPrimaryKey + "\" value=\"5\">5";
                                content += "<input type=\"submit\" name=\"rateIt\" value=\"Rate\"/><br/>\n";
                            }
                            else {                    
                                String tables = "invoices i, details_invoices di";
                                attributes = new ArrayList<>();
                                attributes.add("di.productID");          
                                ArrayList<ArrayList<Object>> result = DataBaseConnection.getTableContent(tables, attributes, "i.customerID = '"+userID+"' AND i.status = 'paid' AND di.productID = '"+currentPrimaryKey+"' AND di.invoiceNumber = i.number",null,null);

                                if (result != null && result.size() != 0){
                                    content += "Rate it: <input type=\"radio\" name=\"rate_" + currentPrimaryKey + "\" value=\"1\">1";
                                    content += "        <input type=\"radio\" name=\"rate_" + currentPrimaryKey + "\" value=\"2\">2";
                                    content += "        <input type=\"radio\" name=\"rate_" + currentPrimaryKey + "\" value=\"3\">3";
                                    content += "        <input type=\"radio\" name=\"rate_" + currentPrimaryKey + "\" value=\"4\">4";
                                    content += "        <input type=\"radio\" name=\"rate_" + currentPrimaryKey + "\" value=\"5\">5";
                                    content += "<input type=\"submit\" name=\"rateIt\" value=\"Rate\"/><br/>\n";
                                }

                            }

                        } catch (Exception exception) {
                            System.out.println ("exceptie: "+exception.getMessage());
                            if (Constants.DEBUG){
                                exception.printStackTrace();
                                errorMessage =  exception.toString();
                            }
                        }


                        content += "Licences: <input type=\"text\" name=\"add_"+currentPrimaryKey+"\" size=\"3\"/><br/>\n";
                        content += "<input type=\"submit\" name=\"buy_"+currentPrimaryKey+"\" value=\"Buy\"/><br/>\n";
                        content += "</td>\n";
                        content += "</tr><tr><td colspan=\"3\">&nbsp;</td></tr>\n";
                    }
                    }
                    
                }
            }
            //else
            //{
                boolean test = false;
                for (ArrayList<Object> tableRow:tableContent) {
                    
                    
                    String pCategory = tableRow.get(7).toString();
                    System.out.println(pCategory);
                    test = false;
                    for (ArrayList<Object> row: categoryTable){
                    
                        String category = row.get(0).toString();
                        if (category.equals(pCategory))
                            test = true;
                    }
                    if (!test)
                    {
                
                String currentPrimaryKey = tableRow.get(0).toString();
                content += "<tr>\n";
                content += "<td valign=\"left\"><img src=\"images/"+Utilities.removeSpaces(tableRow.get(DataBaseConnection.getAttributeIndexInTable(currentTableName, "id")).toString().toLowerCase())+".jpg\" height=\"100\" width=\"100\"/></td>\n";
                content += "<td>&nbsp</td>\n";
                content += "<td bgcolor=\"#ebebeb\">\n";
                
                content += "Name: "+tableRow.get(1).toString()+"<br/>\n";
                content += "Description: "+tableRow.get(2).toString()+"<br/>\n";
                content += "Price: "+tableRow.get(4).toString()+" &euro;<br/>\n";
                String rating = tableRow.get(6).toString();
                if (rating.equals("0"))
                    rating = "-";
                content += "Rating: "+rating+"<br/>\n";
                
                attributes = new ArrayList<>();
                attributes.add("rate");
                try {
                    ArrayList<ArrayList<Object>> rate = DataBaseConnection.getTableContent("ratings", attributes, "customerID = '"+userID+"' AND productID = '"+currentPrimaryKey+"'",null,null);
                    if (rate != null && rate.size() != 0){
                        content += "Rated at: "+rate.get(0).get(0).toString()+"<br/>\n";
                        content += "Rate it again: <input type=\"radio\" name=\"rate_" + currentPrimaryKey + "\" value=\"1\">1";
                        content += "        <input type=\"radio\" name=\"rate_" + currentPrimaryKey + "\" value=\"2\">2";
                        content += "        <input type=\"radio\" name=\"rate_" + currentPrimaryKey + "\" value=\"3\">3";
                        content += "        <input type=\"radio\" name=\"rate_" + currentPrimaryKey + "\" value=\"4\">4";
                        content += "        <input type=\"radio\" name=\"rate_" + currentPrimaryKey + "\" value=\"5\">5";
                        content += "<input type=\"submit\" name=\"rateIt\" value=\"Rate\"/><br/>\n";
                    }
                    else {                    
                        String tables = "invoices i, details_invoices di";
                        attributes = new ArrayList<>();
                        attributes.add("di.productID");          
                        ArrayList<ArrayList<Object>> result = DataBaseConnection.getTableContent(tables, attributes, "i.customerID = '"+userID+"' AND i.status = 'paid' AND di.productID = '"+currentPrimaryKey+"' AND di.invoiceNumber = i.number",null,null);

                        if (result != null && result.size() != 0){
                            content += "Rate it: <input type=\"radio\" name=\"rate_" + currentPrimaryKey + "\" value=\"1\">1";
                            content += "        <input type=\"radio\" name=\"rate_" + currentPrimaryKey + "\" value=\"2\">2";
                            content += "        <input type=\"radio\" name=\"rate_" + currentPrimaryKey + "\" value=\"3\">3";
                            content += "        <input type=\"radio\" name=\"rate_" + currentPrimaryKey + "\" value=\"4\">4";
                            content += "        <input type=\"radio\" name=\"rate_" + currentPrimaryKey + "\" value=\"5\">5";
                            content += "<input type=\"submit\" name=\"rateIt\" value=\"Rate\"/><br/>\n";
                        }

                    }
                
                } catch (Exception exception) {
                    System.out.println ("exceptie: "+exception.getMessage());
                    if (Constants.DEBUG){
                        exception.printStackTrace();
                        errorMessage =  exception.toString();
                    }
                }
                
                
                content += "Licences: <input type=\"text\" name=\"add_"+currentPrimaryKey+"\" size=\"3\"/><br/>\n";
                content += "<input type=\"submit\" name=\"buy_"+currentPrimaryKey+"\" value=\"Buy\"/><br/>\n";
                content += "</td>\n";
                content += "</tr><tr><td colspan=\"3\">&nbsp;</td></tr>\n";
            }
            }
        //}
            content += "</tbody></table>\n";
            content += "</td>\n";
            content += "<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>\n";
            content += "<td align=\"left\" valign=\"top\">\n";
            content += "<table><tr><td valign=\"center\"><img src=\"images/cart.jpg\" height=\"50\" width=\"50\" /></td></tr></table><br/>\n";
            if (shoppingCart != null && !shoppingCart.isEmpty()) {
                // get shopping cart content and display it
                float total = 0;
                content += "<table>";
                for (Record r: shoppingCart){
                    attributes = new ArrayList<>();
                    attributes.add("name");
                    attributes.add("description");
                    attributes.add("price");
                                        
                    tableContent = DataBaseConnection.getTableContent("products", attributes, "id = '" + r.getAttribute() + "'", null, null);               
                    String name = tableContent.get(0).get(0).toString();
                    String description = tableContent.get(0).get(1).toString();
                    String price = tableContent.get(0).get(2).toString();
                    
                                       
                    float subtotal = Integer.parseInt(r.getValue()) * Float.parseFloat(price);
                    total += subtotal;
                    content += "<tr>";
                    content += "<td>" + r.getValue() +" x " + name + " = " + subtotal + "&euro;</td>";
                    content += "<td><input type=\"submit\" name=\"remove_"+r.getAttribute()+"\" value=\"X\"/></td>\n";
                    content += "</tr>";
                }
                
                content += "</table>";
                content += "<br/>Total: " + total + " &euro;";
                
                // TO DO (exercise 10): add controls for finalizing and canceling command
                content += "<br/>";
                content += "<input type=\"submit\" name=\"emptyCart\" value=\"Empty Cart\"/>\n";
                content += "<input type=\"submit\" name=\"finishOrder\" value=\"Finish Order\"/>\n";
                content += "<br/>";
                
            } else {
                content += Constants.EMPTY_CART+"<br/>\n";
            } 
            content += "</td>\n";
            content += "</tr>\n";
            content += "</tbody></table>\n";

        } catch (SQLException exception) {
            System.out.println ("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }       
        content += "</form>\n";
        content += "</center>\n";
        content += "</body>\n";
        content += "</html>";  
        printWriter.println(content);
    }    
}
