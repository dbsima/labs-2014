package graphicuserinterface;

import dataaccess.DataBaseConnection;
import entities.Record;
import general.Constants;
import general.Utilities;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;

public class ClientAccountSettingsGUI {
    
    public ClientAccountSettingsGUI() { }
      
    public static void displayClientGraphicUserInterface(String userName, String password, String email, String firstName, String lastName, String address, String phone, String iban, String cnp, String amount, PrintWriter printWriter) {
        
        System.out.println("here2");
        
        String content = new String();
        content += "<html>\n";
        content += "<head>\n";
        content += "<meta http-equiv=\"content-type\" content=\"text/html; charset=ISO-8859-1\" /><title>Librarie Virtuala</title>\n";
        content += "<link rel=\"stylesheet\" type=\"text/css\" href=\"css/bookstore.css\" />\n";  
        content += "<link rel=\"stylesheet\" href=\"css/accordion.css\" media=\"screen\" type=\"text/css\" />\n";
        content += "</head>\n"; 
        
        content += "    <form name=\"formular\" action=\"ClientServlet\" method=\"POST\">\n";
        content += "        <input type=\"submit\" name=\"shop\" value=\"Shop\" />";
        content += "        <input type=\"submit\" name=\"orders\" value=\"Orders\" />";
        content += "        <input type=\"submit\" name=\"settings\" value=\"Settings\" />";
        content += "        <input type=\"submit\" name=\"account\" value=\"Account\" />";
        content += "        <input type=\"submit\" name=\"products\" value=\"Products\" />";
        content += "        <input type=\"submit\" name=\"deautentificare\" value=\"Log Out\" />";
        content += "    </form>\n";
        
        content += "    <body>\n";
        content +=  "       <div class=\"acc-btn\">"+
                    "           <h1>Username: " + userName + "</h1>"+
                    "       </div>\n" +
                    "           <div class=\"acc-content\">\n" +
                    "               <div class=\"acc-content-inner\">\n" +
                    "                   <form method=\"POST\" action=\"ClientAccountServlet\" accept-charset=\"UTF-8\">\n" +
                    "                       <table>" +
                    "                           <tr><td>User Name</td><td><input placeholder=\""+ userName +"\" name=\"userName\" type=\"text\" /></td>" +
                    "                           <tr><td>To save, enter password: </td><td><input placeholder=\"******\" name=\"password\" type=\"text\" /></td>" +
                    "                       </table>" + 
                    "                       <input id=\"save-username\" type=\"submit\" name=\"save-username\" value=\"Save\" />\n" +
                    "                       <input id=\"cancel\" type=\"submit\" name=\"cancel\" value=\"Cancel\" />\n" +
                    "                   </form>\n" +
                    "               </div>\n" +
                    "           </div>\n" +

                    "       <div class=\"acc-btn\">"+
                    "           <h1>Password</h1>"+
                    "       </div>\n" +
                    "       <div class=\"acc-content\">\n" +
                    "           <div class=\"acc-content-inner\">\n" +
                    "                   <form method=\"POST\" action=\"ClientAccountServlet\" accept-charset=\"UTF-8\">\n" +
                    "                       <table>" +
                    "                           <tr><td>Old password</td><td><input placeholder=\"******\" name=\"oldPassword\" type=\"password\" /></td>" +
                    "                           <tr><td>New password</td><td><input name=\"newPassword\" type=\"password\" /></td>" +
                    "                           <tr><td>Re-type password</td><td><input name=\"retypePassword\" type=\"password\" /></td>" +
                    "                       </table>" +
                    "                       <input id=\"save-password\" type=\"submit\" name=\"save-password\" value=\"Save\" />\n" +
                    "                       <input id=\"cancel\" type=\"submit\" name=\"cancel\" value=\"Cancel\" />\n" +
                    "                   </form>\n" +
                    "           </div>\n" +
                    "       </div>\n" +

                    "       <div class=\"acc-btn\">" +
                    "           <h1>Email: " + email + "</h1>"+
                    "         </div>\n" +
                    "           <div class=\"acc-content\">\n" +
                    "               <div class=\"acc-content-inner\">\n" +
                    "                   <form method=\"POST\" action=\"ClientAccountServlet\" accept-charset=\"UTF-8\">\n" +
                    "                       <table>" +
                    "                           <tr><td>E-mail</td><td><input placeholder=\""+ email +"\" name=\"email\" type=\"email\" /></td>" +
                    "                           <tr><td>To save, enter password: </td><td><input placeholder=\"******\" name=\"password\" type=\"text\" /></td>" +
                    "                       </table>" + 
                    "                       <input id=\"save-email\" type=\"submit\" name=\"save-email\" value=\"Save\" />\n" +
                    "                       <input id=\"cancel\" type=\"submit\" name=\"cancel\" value=\"Cancel\" />\n" +
                    "                   </form>\n" +
                    "               </div>\n" +
                    "           </div>\n" +

                    "       <div class=\"acc-btn\">"+
                    "           <h1>Details </h1>"+
                    "       </div>\n" +
                    "       <div class=\"acc-content\">\n" +
                    "           <div class=\"acc-content-inner\">\n" +
                    "                   <form method=\"POST\" action=\"ClientAccountServlet\" accept-charset=\"UTF-8\">\n" +
                    "                       <table>" +
                    "                           <tr><td>First Name</td><td><input placeholder=\""+ firstName +"\" name=\"firstName\" type=\"text\" /></td>" +
                    "                           <tr><td>Last Name</td><td><input placeholder=\""+ lastName +"\" name=\"lastName\" type=\"text\" /></td>" +
                    "                           <tr><td>Address</td><td><input placeholder=\""+ address +"\" name=\"address\" type=\"text\" /></td>" +
                    "                           <tr><td>Phone</td><td><input placeholder=\""+ phone +"\" name=\"phone\" type=\"tel\" /></td>" +
                    "                           <tr><td>IBAM</td><td><input placeholder=\""+ iban +"\" name=\"iban\" type=\"text\" /></td>" +
                    "                           <tr><td>CNP</td><td><input placeholder=\""+ cnp +"\" name=\"cnp\" type=\"text\" /></td>" +
                    "                           <tr><td>To save, enter password: </td><td><input placeholder=\"******\" name=\"password\" type=\"text\" /></td>" +
                    "                       </table>" + 
                    "                       <input id=\"save-details\" type=\"submit\" name=\"save-details\" value=\"Save\" />\n" +
                    "                       <input id=\"cancel\" type=\"submit\" name=\"cancel\" value=\"Cancel\" />\n" +
                    "                   </form>\n" +
                    "           </div>\n" +
                    "       </div>"+
      
                    "       <div class=\"acc-btn\">"+
                    "           <h1>Amount = " + amount + "</h1>"+
                    "       </div>\n" +
                    "       <div class=\"acc-content\">\n" +
                    "           <div class=\"acc-content-inner\">\n" +
                    "               <p>You have " + amount +" in your account.</p>" + 
                    "           </div>\n" +
                    "       </div>";
 
        content +=      "<script src='http://codepen.io/assets/libs/fullpage/jquery.js'></script>";
        content +=      "<script src=\"js/accordion.js\"></script>\n";
        
        content += "    </body>\n";
        content += "</html>";  
        printWriter.println(content);
    }    
}
