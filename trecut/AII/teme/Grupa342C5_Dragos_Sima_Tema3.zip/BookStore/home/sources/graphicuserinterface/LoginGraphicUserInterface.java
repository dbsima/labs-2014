package graphicuserinterface;

import general.Constants;
import java.io.PrintWriter;

public class LoginGraphicUserInterface {
    
    public LoginGraphicUserInterface() { }
    
    public static void displayLoginGraphicUserInterface(boolean isLoginError, PrintWriter printWriter) {
        String content = new String();
        content += "<html>\n";
        
        content += "<head>\n";
        content +=      "<meta charset=\"UTF-8\">\n";
        content +=      "<title>CRM</title>\n";
        content +=      "<link rel=\"stylesheet\" href=\"css/normalize.css\">\n"; 
        content +=      "<link rel=\"stylesheet\" href=\"css/style.css\" media=\"screen\" type=\"text/css\" />\n";
        content += "</head>\n";
        
        content += "<body>\n";
        content +=      "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1\">\n";
        content +=      "<div class=\"landing\">\n";
        content +=          "<section class=\"topslot\">\n";
        content +=              "<div class=\"wrapper\">\n";
        content +=                  "<div class=\"brief\">\n";
        content +=                      "<h1>CRM</h1>\n";
        content +=                      "<p><span id=\"verb\">continue</span> your adventure</p>\n";
        content +=                  "</div>\n";
        content +=              "</div>\n";
        content +=          "</section>\n";
        
        content +=          "<section>\n";
        content +=              "<div class=\"main\">\n";
        content +=                  "<form method=\"POST\" action=\"LoginServlet\" accept-charset=\"UTF-8\">\n";
        content +=                      "<input placeholder=\"username\" name=\"" + Constants.USER_NAME +"\" type=\"text\" />\n";
        content +=                      "<input placeholder=\"password\" name=\""+ Constants.USER_PASSWORD +"\" type=\"password\" value=\"\" />\n";
        
        content +=                      "<div class=\"signup-fields\">\n";
        content +=                          "<input id=\"email\" placeholder=\"email\" name=\"email\" type=\"email\" value=\"\" />\n";
        content +=                          "<input id=\"firstname\" placeholder=\"firstname\" name=\"firstname\" type=\"text\" />\n";
        content +=                          "<input id=\"lastname\" placeholder=\"lastname\" name=\"lastname\" type=\"text\" />\n";
        content +=                          "<input id=\"address\" placeholder=\"address\" name=\"address\" type=\"text\" />\n";
        content +=                          "<input id=\"telephone\" placeholder=\"telephone\" name=\"telephone\" type=\"tel\" />\n";
        content +=                          "<input id=\"iban\" placeholder=\"IBAN\" name=\"iban\" type=\"text\" />\n";
        content +=                          "<input id=\"cnp\" placeholder=\"CNP\" name=\"cnp\" type=\"text\" />\n";
        content +=                      "</div>\n";
        
        content +=                      "<div>";
        content +=                          "<input id='radio-1' type=\"radio\" name='userType' value=\"customer\" checked=\"checked\"/>";
        content +=                          "<label for=\"radio-1\">Customer</label>";
        content +=                          "<br>";
        content +=                          "<input id='radio-2' type=\"radio\" name='userType'  value=\"admin\"/>";
        content +=                          "<label for=\"radio-2\">Admin</label>";
        content +=                          "<br>";
        content +=                          "<input id='radio-3' type=\"radio\" name='userType'  value=\"sales\"/>";
        content +=                          "<label for=\"radio-3\">Sales</label>";
        content +=                          "<br>";
        content +=                          "<input id='radio-4' type=\"radio\" name='userType'  value=\"support\"/>";
        content +=                          "<label for=\"radio-4\">Support</label>";
        content +=                          "<br>";
        content +=                      "</div>\n";
        content +=                      "<br>";
        content +=                      "<input id=\"submit\" type=\"submit\" name=\"" + Constants.LOGIN.toLowerCase() +"\" value=\"" + Constants.LOGIN.toLowerCase() + "\" />\n";
        
        
        content +=                  "</form>\n";

        content +=                  "<div class=\"extras\">\n";
        content +=                      "<a id=\"signup\" href=\"#\">sign up</a>\n";
        content +=                  "</div>\n";
        content +=              "</div>\n";
        content +=          "</section>\n";
        content +=      "</div>\n";
        
        content +=      "<script src='http://codepen.io/assets/libs/fullpage/jquery.js'></script>\n";
        content +=      "<script src=\"js/index.js\"></script>\n";
        
        if (isLoginError)
            content += "<font color=\"red\">"+Constants.LOGIN_ERROR+"</font>\n";
        
        content += "</body>\n";
        content += "</html>\n";
        
        printWriter.println(content);
    }
}
