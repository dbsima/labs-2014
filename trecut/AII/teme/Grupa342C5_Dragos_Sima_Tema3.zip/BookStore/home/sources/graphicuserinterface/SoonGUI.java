package graphicuserinterface;

import dataaccess.DataBaseConnection;
import entities.Record;
import general.Constants;
import general.Utilities;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class SoonGUI {
    
    public SoonGUI() { }
    
    public static String getProductRating(String productID) {
        float result = 0;
        
        try {
            ArrayList<String> attributes = new ArrayList<>();
            attributes.add("rate");
            ArrayList<ArrayList<Object>> tableContent = DataBaseConnection.getTableContent("ratings", attributes, "productID=\'"+productID+"\'",null,null);
            if (tableContent == null || tableContent.get(0) == null || tableContent.get(0).get(0) == null)
                return "-";
            else {
                for (ArrayList<Object> tableRow:tableContent)
                    result += Float.parseFloat(tableRow.get(0).toString());
                result /= tableContent.size();
                return String.valueOf(result);
            }
                
        } catch (SQLException exception) {
            System.out.println("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }  
        return "-";
    }
    
    public static void displayClientGraphicUserInterface(String errorMessage, String searchTokens, String selectedOrder, PrintWriter printWriter) {
        //currentTableName = "products";
        String content = new String();
        content += "<html>\n";
        content += "<head>\n";
        content += "<meta http-equiv=\"content-type\" content=\"text/html; charset=ISO-8859-1\" /><title>CRM</title>\n";
        content += "<link rel=\"stylesheet\" type=\"text/css\" href=\"css/bookstore.css\" />\n";  
        content += "<link rel=\"stylesheet\" href=\"css/bookstore.css\" media=\"screen\" type=\"text/css\" />\n";
        content += "</head>\n";   
        
        content += "    <form name=\"formular\" action=\"SoonServlet\" method=\"POST\">\n";
        content += "        <input type=\"submit\" name=\"firstPage\" value=\"FirstPage\" />";
        content += "        <input type=\"submit\" name=\"logIn\" value=\"Log In\" />";
        content += "    </form>\n";
        
        content += "<body>\n";
              
        content += "<center>\n";
        
        content += "    <form name=\"formularX\" action=\"SoonServlet\" method=\"POST\">\n";
        content += "        Search <input type=\"search\" name=\"search\"><br>";
        content += "        <select name=\"selectedOrder\" onchange=\"document.formularX.submit()\">\n";
        content += "            <option value=\"byName\" SELECTED>Name</option>\n";
        content += "            <option value=\"byPriceAsc\">Price ASC</option>\n";
        content += "            <option value=\"byPriceDesc\">Price DESC</option>\n";
        content += "            <option value=\"byRating\">Rating</option>\n";
        content += "        </select>\n";
        content += "    </form>\n";
        
        content += "    <form name=\"formular\" action=\"SoonServlet\" method=\"POST\">\n";
        content += "<table  bgcolor=\"#ffffff\" border=\"0\" cellpadding=\"4\" cellspacing=\"1\"><tbody>\n";
        content += "<tr>\n";
        content += "<td align=\"left\" valign=\"top\">\n";

        content += "</td>\n";
        content += "<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>\n";
        content += "<td width=\"60%\" align=\"center\">\n";
        try {
            if (errorMessage != null)
                content += errorMessage + "<br/><br/>\n";
            ArrayList<String> attributes = DataBaseConnection.getTableAttributes("products");
            String whereClause = "availability=\"soon\"";
            
            String orderByClause = new String();

            // construct orderClause to display products in the wanted order
            if (selectedOrder.equals("byName"))
                orderByClause = "name";
            else if (selectedOrder.equals("byPriceAsc"))
                orderByClause = "price ASC";
            else if (selectedOrder.equals("byPriceDesc"))
                 orderByClause = "price DESC";
            else if (selectedOrder.equals("byRating"))
                orderByClause = "rate DESC";
            
            // construct whereClause to display products containing certain words
            System.out.println(searchTokens);
            
            if (!searchTokens.equals("")){
                ArrayList<String> tokens = new ArrayList<>();
                if (searchTokens.contains(" ")){
                    String[] array = searchTokens.split("\\s+");
                    for(String str : array)
                    {
                        tokens.add(str);
                        //whereClause += " like '%Adobe%' or name like '%Microsoft%'";
                    }
                }
                else
                    tokens.add(searchTokens);
                
                whereClause += " AND ";
                for (int j = 0; j < tokens.size(); j++) {
                    whereClause += "name like '%" + tokens.get(j) + "%'";
                    if (j < tokens.size() - 1)
                        whereClause += " OR ";
                }
            }
            
            System.out.println(whereClause);
            
            ArrayList<ArrayList<Object>> tableContent = DataBaseConnection.getTableContent("products",attributes,(whereClause.length()!=0?whereClause:null),(orderByClause.length()!=0?orderByClause:null),null);
            //int primayKeyIndex = DataBaseConnection.getAttributeIndexInTable(currentTableName, DataBaseConnection.getTablePrimaryKey(currentTableName));
            content += "<table  bgcolor=\"#ffffff\" border=\"0\" cellpadding=\"4\" cellspacing=\"1\"><tbody>\n";
            for (ArrayList<Object> tableRow:tableContent) {
                String currentPrimaryKey = tableRow.get(0).toString();
                content += "<tr>\n";
                content += "<td valign=\"left\"><img src=\"images/"+Utilities.removeSpaces(tableRow.get(DataBaseConnection.getAttributeIndexInTable("products", "id")).toString().toLowerCase())+".jpg\" height=\"100\" width=\"100\"/></td>\n";
                content += "<td>&nbsp</td>\n";
                content += "<td bgcolor=\"#ebebeb\">\n";
                
                content += "Name: "+tableRow.get(1).toString()+"<br/>\n";
                content += "Description: "+tableRow.get(2).toString()+"<br/>\n";
                content += "Price: "+tableRow.get(4).toString()+" &euro;<br/>\n";
                String rating = tableRow.get(6).toString();
                if (rating.equals("0"))
                    rating = "-";
                content += "Rating: "+rating+"<br/>\n";    
                
                content += "</td>\n";
                content += "</tr><tr><td colspan=\"3\">&nbsp;</td></tr>\n";
            }
            content += "</tbody></table>\n";
            content += "</td>\n";
            content += "<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>\n";
            content += "<td align=\"left\" valign=\"top\">\n";
              
            content += "</td>\n";
            content += "</tr>\n";
            content += "</tbody></table>\n";

        } catch (SQLException exception) {
            System.out.println ("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }       
        content += "</form>\n";
        content += "</center>\n";
        content += "</body>\n";
        content += "</html>";  
        printWriter.println(content);
    }    
}
