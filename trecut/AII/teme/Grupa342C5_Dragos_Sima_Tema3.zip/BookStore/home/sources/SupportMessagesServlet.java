import dataaccess.DataBaseConnection;
import entities.Record;
import general.Constants;
import general.Utilities;
import graphicuserinterface.ClientGraphicUserInterface;
import graphicuserinterface.ClientProductsGUI;
import graphicuserinterface.SupportMessagesGUI;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.Enumeration;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class SupportMessagesServlet extends HttpServlet {
    final public static long    serialVersionUID = 10021002L;
    
    public String               selectedTable, selectedOrder="", searchTokens = "";
    public String               userDisplayName, userID;
    
    public ArrayList<Record>	shoppingCart;
 
    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        try {
            DataBaseConnection.openConnection();
            selectedTable       = Constants.BOOKS_TABLE;

        } catch (SQLException exception) {
            System.out.println("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }
    }

    @Override
    public void destroy() {
        try {
            DataBaseConnection.closeConnection();
        } catch (SQLException exception) {
            System.out.println("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {       
        HttpSession session = request.getSession(true);
        try (PrintWriter printWriter = new PrintWriter(response.getWriter())) {
            userDisplayName = session.getAttribute(Constants.IDENTIFIER).toString();
            userID = session.getAttribute(Constants.ID).toString();
            
            shoppingCart = (ArrayList<Record>)session.getAttribute(Utilities.removeSpaces(Constants.SHOPPING_CART.toLowerCase()));
            if (shoppingCart == null) {
                shoppingCart = new ArrayList<>();
            }            
            String errorMessage = "good";
            Enumeration parameters = request.getParameterNames();
            while(parameters.hasMoreElements()) {
                String parameter = (String)parameters.nextElement();

                
                // set priority
                if (parameter.contains("level_") && !request.getParameter(parameter).equals(""))
                {
                    String problemID = parameter.split("_")[1];
                    String newLevel = request.getParameter(parameter).toString();
                    
                    ArrayList<String> attributes = new ArrayList<>();
                    try {
                            attributes.add("priority");
                            ArrayList<String> values = new ArrayList<>();
                            values.add(newLevel);      
                            DataBaseConnection.updateRecordsIntoTable("problems", attributes, values, "id = '"+problemID+"'");
                     } catch (Exception exception) {
                        System.out.println ("exceptie: "+exception.getMessage());
                        if (Constants.DEBUG){
                            exception.printStackTrace();
                            errorMessage =  exception.toString();
                        }
                    } 
                }              
                // logic for logout
                if (parameter.equals("deautentificare")) {
                    session.invalidate();
                    RequestDispatcher requestDispatcher = null;
                    requestDispatcher = getServletContext().getRequestDispatcher("/");
                    requestDispatcher.forward(request,response);
                    return;
                }
                
                // logic for editing personal data
                if (parameter.equals("account")) {
                    //session.invalidate();
                    System.out.println("acountttt");
                    RequestDispatcher requestDispatcher = null;
                    requestDispatcher = request.getRequestDispatcher("/ClientAccountServlet");
                    if (requestDispatcher!=null) {
                        requestDispatcher.forward(request,response);
                    }
                    return;
                }
                
                // get tonkens for search
                if (parameter.contains("search"))
                {
                    searchTokens = request.getParameter(parameter).toString();  
                }
                
                
                
                // get invoiceID, productID and message
                if (parameter.contains("comment_") && !request.getParameter(parameter).equals(""))
                {
                    String problemID = parameter.split(" ")[0].split("_")[1];  
                    String message = request.getParameter(parameter);
                    System.err.println(" ----" + problemID+ "-"+ message);
                    
                    
                    ArrayList<String> attributes = new ArrayList<>();
                    attributes.add("employeeID");
                    attributes.add("problemID");
                    attributes.add("message");
                    
                    ArrayList<String> values = new ArrayList<>();
                    values.add(userID);
                    values.add(problemID);
                    values.add(message);

                    try {
                        DataBaseConnection.insertValuesIntoTable("messages", attributes, values, true);
                        
                        attributes = new ArrayList<>();
                        attributes.add("status");
                        attributes.add("priority");
                        
                        values = new ArrayList<>();
                        values.add("closed");
                        values.add("0");
                        DataBaseConnection.updateRecordsIntoTable("problems", attributes, values, "id = '"+problemID+"'");
                    } catch (Exception exception) {
                        System.out.println ("exceptie: "+exception.getMessage());
                        if (Constants.DEBUG){
                            exception.printStackTrace();
                            errorMessage =  exception.toString();
                        }
                    } 
                }
                
                // logic for getting orders
                if (parameter.equals("orders")) {
                    //session.invalidate();
                    System.out.println("ordeeeers");
                    RequestDispatcher requestDispatcher = null;
                    requestDispatcher = request.getRequestDispatcher("/ClientOrdersServlet");
                    if (requestDispatcher!=null) {
                        requestDispatcher.forward(request,response);
                    }
                    return;
                }
                
                // get tonkens for search
                if (parameter.contains("products"))
                {
                    searchTokens = "";
                }
            }
            session.setAttribute(Utilities.removeSpaces(Constants.SHOPPING_CART.toLowerCase()), shoppingCart);
            
            response.setContentType("text/html");
            SupportMessagesGUI.displayClientGraphicUserInterface(userID, errorMessage, selectedTable, searchTokens, selectedOrder, shoppingCart,printWriter);
        }
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(true);
        userDisplayName = session.getAttribute(Constants.IDENTIFIER).toString();
        shoppingCart = (ArrayList<Record>)session.getAttribute(Utilities.removeSpaces(Constants.SHOPPING_CART.toLowerCase()));

        response.setContentType("text/html");
        try (PrintWriter printWriter = new PrintWriter(response.getWriter())) {
            SupportMessagesGUI.displayClientGraphicUserInterface(userDisplayName, null, selectedTable, searchTokens, selectedOrder, shoppingCart, printWriter);
        }
    }     	 
}
