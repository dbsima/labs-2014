import dataaccess.DataBaseConnection;
import entities.Record;
import general.Constants;
import general.Utilities;
import graphicuserinterface.ClientGraphicUserInterface;
import graphicuserinterface.FirstPageGUI;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.Enumeration;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class FirstPageServlet extends HttpServlet {
    final public static long    serialVersionUID = 10021002L;
    
    public String               selectedTable, selectedOrder="", searchTokens = "";
    public String               userDisplayName, userID;
    
    public ArrayList<Record>	shoppingCart;
 
    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        try {
            DataBaseConnection.openConnection();
            selectedTable       = Constants.BOOKS_TABLE;

        } catch (SQLException exception) {
            System.out.println("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }
    }

    @Override
    public void destroy() {
        try {
            DataBaseConnection.closeConnection();
        } catch (SQLException exception) {
            System.out.println("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {       
        HttpSession session = request.getSession(true);
        try (PrintWriter printWriter = new PrintWriter(response.getWriter())) {
               
            String errorMessage = "good";
            Enumeration parameters = request.getParameterNames();
            while(parameters.hasMoreElements()) {
                String parameter = (String)parameters.nextElement();
              
                // logic for getting the products in the selected order
                if (parameter.equals("selectedOrder") && !request.getParameter(parameter).equals("")) {
                    selectedOrder = request.getParameter(parameter);
                    errorMessage = selectedOrder;
                }
                
                // get tonkens for search
                if (parameter.contains("search"))
                {
                    searchTokens = request.getParameter(parameter).toString();  
                }
                
                // logic for getting bought products
                if (parameter.equals("logIn")) {
                    System.out.println("logIn");
                    RequestDispatcher requestDispatcher = null;
                    requestDispatcher = request.getRequestDispatcher("/LoginServlet");
                    if (requestDispatcher!=null) {
                        requestDispatcher.forward(request,response);
                    }
                    return;
                }
                
                // logic for getting the products to be released soon
                if (parameter.equals("soon")) {
                    System.out.println("soon");
                    RequestDispatcher requestDispatcher = null;
                    requestDispatcher = request.getRequestDispatcher("/SoonServlet");
                    if (requestDispatcher!=null) {
                        requestDispatcher.forward(request,response);
                    }
                    return;
                }
            }
           
            response.setContentType("text/html");
            FirstPageGUI.displayClientGraphicUserInterface(errorMessage, searchTokens, selectedOrder, printWriter);
        }
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(true);
        //userDisplayName = session.getAttribute(Constants.IDENTIFIER).toString();
        //shoppingCart = (ArrayList<Record>)session.getAttribute(Utilities.removeSpaces(Constants.SHOPPING_CART.toLowerCase()));

        response.setContentType("text/html");
        try (PrintWriter printWriter = new PrintWriter(response.getWriter())) {
            FirstPageGUI.displayClientGraphicUserInterface(null, searchTokens, selectedOrder, printWriter);
        }
    }     	 
}
