import dataaccess.DataBaseConnection;
import entities.Record;
import general.Constants;
import general.Utilities;
import graphicuserinterface.ClientOrdersGUI;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ClientOrdersServlet extends HttpServlet {
    final public static long    serialVersionUID = 10021004L;
    
    public String               selectedTable, selectedOrder="";
    public String               userDisplayName, userID;
    
    public ArrayList<Record>	shoppingCart;
 
    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        try {
            DataBaseConnection.openConnection();
            selectedTable       = Constants.BOOKS_TABLE;

        } catch (SQLException exception) {
            System.out.println("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }
    }

    @Override
    public void destroy() {
        try {
            DataBaseConnection.closeConnection();
        } catch (SQLException exception) {
            System.out.println("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {       
        HttpSession session = request.getSession(true);
        try (PrintWriter printWriter = new PrintWriter(response.getWriter())) {
            userDisplayName = session.getAttribute(Constants.IDENTIFIER).toString();
            
            userID = session.getAttribute(Constants.ID).toString();
            
            shoppingCart = (ArrayList<Record>)session.getAttribute(Utilities.removeSpaces(Constants.SHOPPING_CART.toLowerCase()));
            if (shoppingCart == null) {
                shoppingCart = new ArrayList<>();
            }            
            String errorMessage = "good";
            Enumeration parameters = request.getParameterNames();
            while(parameters.hasMoreElements()) {
                String parameter = (String)parameters.nextElement();                
                
                if (parameter.contains("cancel") && !request.getParameter(parameter).equals(""))
                {
                    String invoiceNumber = parameter.split("_")[1];
                         
                    //errorMessage = nrExemplare;
                    ArrayList<String> attributes = new ArrayList<>();
                    attributes.add("status");
                    
                    ArrayList<String> values = new ArrayList<>();
                    values.add("canceled");
                    
                    try {
                        System.out.println(attributes);
                        System.out.println(values);
                        DataBaseConnection.updateRecordsIntoTable("invoices", attributes, values, "number = '" + invoiceNumber + "'");

                    } catch (Exception ex) {
                        Logger.getLogger(ClientAccountServlet.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                
                // cancel order
                if (parameter.contains("pay") && !request.getParameter(parameter).equals(""))
                {
                    String invoiceNumber = parameter.split("_")[1];
                         
                    //errorMessage = nrExemplare;
                    ArrayList<String> attributes = new ArrayList<>();
                    attributes.add("amount");
                                       
                    try {
                        ArrayList<ArrayList<Object>> customersTable = DataBaseConnection.getTableContent("customers", attributes, "id='" + userID +"'" , null, null);
                        
                        if (customersTable != null && !customersTable.isEmpty()){
                            String userAmount = customersTable.get(0).get(0).toString();
                            if (Integer.parseInt(userAmount) > 0){
                                ArrayList<ArrayList<Object>> invoicesTable = DataBaseConnection.getTableContent("invoices", attributes, "number='" + invoiceNumber +"' AND customerID='" + userID + "'" , null, null);
                                if (customersTable != null && !customersTable.isEmpty()){
                                    String invoiceAmount = invoicesTable.get(0).get(0).toString();
                                    int amountAfterPayment = Integer.parseInt(userAmount) - Integer.parseInt(invoiceAmount);
                                    if (amountAfterPayment >= 0){
                                        attributes = new ArrayList<>();
                                        attributes.add("status");

                                        ArrayList<String> values = new ArrayList<>();
                                        values.add("paid");
                                        System.out.println(attributes);
                                        System.out.println(values);
                                        // the invoice is payed
                                        DataBaseConnection.updateRecordsIntoTable("invoices", attributes, values, "number = '" + invoiceNumber + "'"); 
                                        
                                        // the amount is withdrawn
                                        attributes = new ArrayList<>();
                                        attributes.add("amount");
                                        values = new ArrayList<>();
                                        values.add(String.valueOf(amountAfterPayment));
                                        DataBaseConnection.updateRecordsIntoTable("customers", attributes, values, "id = '" + userID + "'");
                                        
                                        errorMessage = "Order " + invoiceNumber + " paid!";
                                    }
                                    else errorMessage = "Not enough money!";
                                }
                            }  
                        }
                    } catch (Exception ex) {
                        Logger.getLogger(ClientAccountServlet.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
 
                // logic for logout
                if (parameter.equals("deautentificare")) {
                    session.invalidate();
                    RequestDispatcher requestDispatcher = null;
                    requestDispatcher = getServletContext().getRequestDispatcher("/");
                    requestDispatcher.forward(request,response);
                    return;
                }
                
                // logic for editing personal data
                if (parameter.equals("account")) {
                    //session.invalidate();
                    RequestDispatcher requestDispatcher = null;
                    requestDispatcher = request.getRequestDispatcher("/ClientAccountServlet");
                    if (requestDispatcher!=null) {
                        requestDispatcher.forward(request,response);
                    }
                    return;
                }
                
                // logic for editing personal data
                if (parameter.equals("shop")) {
                    //session.invalidate();
                    RequestDispatcher requestDispatcher = null;
                    requestDispatcher = request.getRequestDispatcher("/ClientServlet");
                    if (requestDispatcher!=null) {
                        requestDispatcher.forward(request,response);
                    }
                    return;
                }
                
                // logic for getting bought products
                if (parameter.equals("products")) {
                    //session.invalidate();
                    System.out.println("products");
                    RequestDispatcher requestDispatcher = null;
                    requestDispatcher = request.getRequestDispatcher("/ClientProductsServlet");
                    if (requestDispatcher!=null) {
                        requestDispatcher.forward(request,response);
                    }
                    return;
                }
                
            }
            
            session.setAttribute(Utilities.removeSpaces(Constants.SHOPPING_CART.toLowerCase()), shoppingCart);
            
            response.setContentType("text/html");
            ClientOrdersGUI.displayClientGraphicUserInterface(userID, errorMessage, selectedTable, selectedOrder, shoppingCart,printWriter);
        }
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(true);
        userDisplayName = session.getAttribute(Constants.IDENTIFIER).toString();
        shoppingCart = (ArrayList<Record>)session.getAttribute(Utilities.removeSpaces(Constants.SHOPPING_CART.toLowerCase()));

        response.setContentType("text/html");
        try (PrintWriter printWriter = new PrintWriter(response.getWriter())) {
            ClientOrdersGUI.displayClientGraphicUserInterface(userDisplayName, null, selectedTable, selectedOrder, shoppingCart, printWriter);
        }
    }     	 
}
