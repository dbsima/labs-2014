import dataaccess.DataBaseConnection;
import entities.Record;
import general.Constants;
import general.Utilities;
import graphicuserinterface.ClientAccountSettingsGUI;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ClientAccountServlet extends HttpServlet {
    final public static long    serialVersionUID = 10031003L;
    
    public String               selectedTable, selectedCollection, selectedDomain;
    public String userDisplayName, userID;
    public String userName, password, email, firstName, lastName, address, phone, iban, cnp, amount;
    
    public ArrayList<Record>	shoppingCart;
 
    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        try {
            DataBaseConnection.openConnection();
            selectedTable       = Constants.BOOKS_TABLE;
            selectedCollection  = Constants.ALL;
            selectedDomain      = Constants.ALL;
        } catch (SQLException exception) {
            System.out.println("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }
    }

    @Override
    public void destroy() {
        try {
            DataBaseConnection.closeConnection();
        } catch (SQLException exception) {
            System.out.println("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {       
        HttpSession session = request.getSession(true);
        try (PrintWriter printWriter = new PrintWriter(response.getWriter())) {
            userDisplayName = session.getAttribute(Constants.IDENTIFIER).toString();
            userID = session.getAttribute(Constants.ID).toString();
            
            userName = session.getAttribute(Constants.USERNAME).toString();
            password = session.getAttribute(Constants.PASSWORD).toString();
            email = session.getAttribute(Constants.EMAIL).toString();
            firstName = session.getAttribute(Constants.FIRSTNAME).toString();
            lastName = session.getAttribute(Constants.LASTNAME).toString();
            address = session.getAttribute(Constants.ADDRESS).toString();
            phone = session.getAttribute(Constants.TELEPHONE).toString();
            iban = session.getAttribute(Constants.IBAN).toString();
            cnp = session.getAttribute(Constants.CNP).toString();
            amount = session.getAttribute(Constants.AMOUNT).toString();
            
            shoppingCart = (ArrayList<Record>)session.getAttribute(Utilities.removeSpaces(Constants.SHOPPING_CART.toLowerCase()));
            if (shoppingCart == null) {
                shoppingCart = new ArrayList<>();
            }            
            String errorMessage = "good";
            Enumeration parameters = request.getParameterNames();
            while(parameters.hasMoreElements()) {
                String parameter = (String)parameters.nextElement();                

                
                // accordion forms
                if (parameter.equals("save-username") && request.getParameter(parameter).equals("Save"))
                {
                    String newUserName = "";
                    newUserName = request.getParameter("userName");
                    
                    String password = "";
                    password = request.getParameter("password");
                    
                    if (!newUserName.equals("") && !password.equals("")) {
                        ArrayList<String> attributes = new ArrayList<>();
                        attributes.add("password");
                        try {
                            ArrayList<ArrayList<Object>> tableContent = DataBaseConnection.getTableContent("customers", attributes, "id ='" + userID + "'",null,null);
                            String currentPassword = tableContent.get(0).get(0).toString();
                            if (currentPassword.equals(password)){
                        
                                attributes = new ArrayList<>();
                                attributes.add("username");
                                ArrayList<String> values = new ArrayList<>();
                                values.add(newUserName);
            
                                try {
                                    System.out.println(attributes);
                                    System.out.println(values);
                                    DataBaseConnection.updateRecordsIntoTable("customers", attributes, values, "id ='" + userID + "'");

                                } catch (Exception ex) {
                                    Logger.getLogger(ClientAccountServlet.class.getName()).log(Level.SEVERE, null, ex);
                                }
                            }
                        } catch (Exception ex) {
                            Logger.getLogger(ClientAccountServlet.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
                
                if (parameter.equals("save-password") && request.getParameter(parameter).equals("Save"))
                {
                    String oldPassword = "";
                    String newPassword = "";
                    String retypePassword = "";
                    oldPassword = request.getParameter("oldPassword");
                    newPassword = request.getParameter("newPassword");
                    retypePassword = request.getParameter("retypePassword");
                    
                    if (!oldPassword.equals("") && !newPassword.equals("") && !retypePassword.equals("")) {
                        
                        ArrayList<String> attributes = new ArrayList<>();
                        attributes.add("password");
                        try {
                            ArrayList<ArrayList<Object>> tableContent = DataBaseConnection.getTableContent("customers", attributes, "id ='" + userID + "'",null,null);
                            String currentPassword = tableContent.get(0).get(0).toString();
                            if (currentPassword.equals(oldPassword)){
                                if (newPassword.equals(retypePassword)){
                                    ArrayList<String> values = new ArrayList<>();
                                    values.add(newPassword);
                                    try {
                                        DataBaseConnection.updateRecordsIntoTable("customers", attributes, values, "id ='" + userID + "'");
                                    } catch (Exception ex) {
                                        Logger.getLogger(ClientAccountServlet.class.getName()).log(Level.SEVERE, null, ex);
                                    }
                                }
                            }
                        } catch (Exception ex) {
                            Logger.getLogger(ClientAccountServlet.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    } 
                }
                
                if (parameter.equals("save-email") && request.getParameter(parameter).equals("Save"))
                {
                    String newEmail = "";
                    newEmail = request.getParameter("email");
                    
                    String password = "";
                    password = request.getParameter("password");
                    
                    if (!newEmail.equals("") && !password.equals("")) {
                        ArrayList<String> attributes = new ArrayList<>();
                        attributes.add("password");
                        try {
                            ArrayList<ArrayList<Object>> tableContent = DataBaseConnection.getTableContent("customers", attributes, "id ='" + userID + "'",null,null);
                            String currentPassword = tableContent.get(0).get(0).toString();
                            if (currentPassword.equals(password)){
                        
                                attributes = new ArrayList<>();
                                attributes.add("email");
                                ArrayList<String> values = new ArrayList<>();
                                values.add(newEmail);
            
                                try {
                                    System.out.println(attributes);
                                    System.out.println(values);
                                    DataBaseConnection.updateRecordsIntoTable("customers", attributes, values, "id ='" + userID + "'");

                                } catch (Exception ex) {
                                    Logger.getLogger(ClientAccountServlet.class.getName()).log(Level.SEVERE, null, ex);
                                }
                            }
                        } catch (Exception ex) {
                            Logger.getLogger(ClientAccountServlet.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
                
                
                if (parameter.equals("save-details") && request.getParameter(parameter).equals("Save"))
                {
                    ArrayList<String> attributes = new ArrayList<>();
                    ArrayList<String> values = new ArrayList<>();
                    
                    String newFirstName = "";
                    newFirstName = request.getParameter("firstName");
                    if (!newFirstName.equals("")){
                        attributes.add("firstname");
                        values.add(newFirstName);  
                    }
                    
                    String newLastName = "";
                    newLastName = request.getParameter("lastName");
                    if (!newLastName.equals("")){
                        attributes.add("lastname");
                        values.add(newLastName);  
                    }
                    
                    String newAddress = "";
                    newAddress = request.getParameter("address");
                    if (!newAddress.equals("")){
                        attributes.add("address");
                        values.add(newAddress);  
                    }
                    
                    String newPhone = "";
                    newPhone = request.getParameter("phone");
                    if (!newPhone.equals("")){
                        attributes.add("phone");
                        values.add(newPhone);  
                    }
                    
                    String newIBAN = "";
                    newIBAN = request.getParameter("iban");
                    if (!newIBAN.equals("")){
                        attributes.add("IBAN");
                        values.add(newIBAN);  
                    }
                    
                    String newCNP = "";
                    newCNP = request.getParameter("cnp");
                    if (!newCNP.equals("")){
                        attributes.add("CNP");
                        values.add(newCNP);  
                    }
                    
                    String password = "";
                    password = request.getParameter("password");
                    
                    if (attributes.size() > 0 && !password.equals("")) {
                        ArrayList<String> attr = new ArrayList<>();
                        attr.add("password");
                        try {
                            ArrayList<ArrayList<Object>> tableContent = DataBaseConnection.getTableContent("customers", attr, "id ='" + userID + "'",null,null);
                            String currentPassword = tableContent.get(0).get(0).toString();
                            if (currentPassword.equals(password)){
                                try {
                                    System.out.println(attributes);
                                    System.out.println(values);
                                    DataBaseConnection.updateRecordsIntoTable("customers", attributes, values, "id ='" + userID + "'");

                                } catch (Exception ex) {
                                    Logger.getLogger(ClientAccountServlet.class.getName()).log(Level.SEVERE, null, ex);
                                }
                            }
                        } catch (Exception ex) {
                            Logger.getLogger(ClientAccountServlet.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                }
                
                // menu buttons
                if (parameter.equals("deautentificare")) {
                    session.invalidate();
                    RequestDispatcher requestDispatcher = null;
                    requestDispatcher = getServletContext().getRequestDispatcher("/");
                    requestDispatcher.forward(request,response);
                    return;
                }
                
                // logic for editing personal data
                if (parameter.equals("shop")) {
                    //session.invalidate();
                    RequestDispatcher requestDispatcher = null;
                    requestDispatcher = request.getRequestDispatcher("/ClientServlet");
                    if (requestDispatcher!=null) {
                        requestDispatcher.forward(request,response);
                    }
                    return;
                }
                
                // logic for getting bought products
                if (parameter.equals("products")) {
                    //session.invalidate();
                    System.out.println("products");
                    RequestDispatcher requestDispatcher = null;
                    requestDispatcher = request.getRequestDispatcher("/ClientProductsServlet");
                    if (requestDispatcher!=null) {
                        requestDispatcher.forward(request,response);
                    }
                    return;
                }
            }
            
            session.setAttribute(Utilities.removeSpaces(Constants.SHOPPING_CART.toLowerCase()), shoppingCart);
            
            response.setContentType("text/html");
            ClientAccountSettingsGUI.displayClientGraphicUserInterface(userName, password, email, firstName, lastName, address, phone, iban, cnp, amount, printWriter);
        }
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(true);
        userDisplayName = session.getAttribute(Constants.IDENTIFIER).toString();
        
        userName = session.getAttribute(Constants.USERNAME).toString();
        password = session.getAttribute(Constants.PASSWORD).toString();
        email = session.getAttribute(Constants.EMAIL).toString();
        firstName = session.getAttribute(Constants.FIRSTNAME).toString();
        lastName = session.getAttribute(Constants.LASTNAME).toString();
        address = session.getAttribute(Constants.ADDRESS).toString();
        phone = session.getAttribute(Constants.TELEPHONE).toString();
        iban = session.getAttribute(Constants.IBAN).toString();
        cnp = session.getAttribute(Constants.CNP).toString();
        amount = session.getAttribute(Constants.AMOUNT).toString();
        
        shoppingCart = (ArrayList<Record>)session.getAttribute(Utilities.removeSpaces(Constants.SHOPPING_CART.toLowerCase()));

        response.setContentType("text/html");
        try (PrintWriter printWriter = new PrintWriter(response.getWriter())) {
            ClientAccountSettingsGUI.displayClientGraphicUserInterface(userName, password, email, firstName, lastName, address, phone, iban, cnp, amount, printWriter);
        }
    }     	 
}
