import dataaccess.DataBaseConnection;
import entities.Record;
import general.Constants;
import general.Utilities;
import graphicuserinterface.ClientGraphicUserInterface;
import graphicuserinterface.ClientProductsGUI;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Enumeration;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ClientProductsServlet extends HttpServlet {
    final public static long    serialVersionUID = 10021002L;
    
    public String               selectedTable, selectedOrder="", searchTokens = "";
    public String               userDisplayName, userID;
    
    public ArrayList<Record>	shoppingCart;
 
    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        try {
            DataBaseConnection.openConnection();
            selectedTable       = Constants.BOOKS_TABLE;

        } catch (SQLException exception) {
            System.out.println("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }
    }

    @Override
    public void destroy() {
        try {
            DataBaseConnection.closeConnection();
        } catch (SQLException exception) {
            System.out.println("exceptie: "+exception.getMessage());
            if (Constants.DEBUG)
                exception.printStackTrace();
        }
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {       
        HttpSession session = request.getSession(true);
        try (PrintWriter printWriter = new PrintWriter(response.getWriter())) {
            userDisplayName = session.getAttribute(Constants.IDENTIFIER).toString();
            userID = session.getAttribute(Constants.ID).toString();
            
            shoppingCart = (ArrayList<Record>)session.getAttribute(Utilities.removeSpaces(Constants.SHOPPING_CART.toLowerCase()));
            if (shoppingCart == null) {
                shoppingCart = new ArrayList<>();
            }            
            String errorMessage = "good";
            Enumeration parameters = request.getParameterNames();
            while(parameters.hasMoreElements()) {
                String parameter = (String)parameters.nextElement();

                // logic for getting the products in the selected order
                if (parameter.equals("selectedOrder") && !request.getParameter(parameter).equals("")) {
                    selectedOrder = request.getParameter(parameter);
                    errorMessage = selectedOrder;
                }
                
                // get tonkens for search
                if (parameter.equals("shop"))
                {
                    searchTokens = "";
                    RequestDispatcher requestDispatcher = null;
                    requestDispatcher = request.getRequestDispatcher("/ClientServlet");
                    if (requestDispatcher!=null) {
                        requestDispatcher.forward(request,response);
                    }
                    return;
                }
                
                // rate product
                if (parameter.contains("rate_") && !request.getParameter(parameter).equals(""))
                {
                    String productID = parameter.split("_")[1];
                    String newRate = request.getParameter(parameter).toString();
                    
                    ArrayList<String> attributes = new ArrayList<>();
                    attributes.add("rate");
                    
                    try {
                        ArrayList<ArrayList<Object>> rate = DataBaseConnection.getTableContent("ratings", attributes, "customerID = '"+userID+"' AND productID = '"+productID+"'",null,null);
                        // if it is rated update it
                        if (rate != null && rate.size() != 0){
                            attributes = new ArrayList<>();
                            attributes.add("rate");
                            ArrayList<String> values = new ArrayList<>();
                            values.add(newRate);
                            
                            DataBaseConnection.updateRecordsIntoTable("ratings", attributes, values, "customerID = '"+userID+"' AND productID = '"+productID+"'");
                        }
                        // if is not rated insert a new rate
                        else {
                            attributes = new ArrayList<>();
                            attributes.add("customerID");
                            attributes.add("productID");
                            attributes.add("rate");
                            ArrayList<String> values = new ArrayList<>();
                            values.add(userID);
                            values.add(productID);
                            values.add(newRate);
                            
                            DataBaseConnection.insertValuesIntoTable("ratings", attributes, values, true);  
                        }
                        // update the ratings
                        attributes = new ArrayList<>();
                        attributes.add("products.rate");
                        ArrayList<String> values = new ArrayList<>();
                        values.add("b.rating");

                        DataBaseConnection.updateRecordsIntoTable2("products CROSS JOIN (SELECT p.id AS pid, AVG(r.rate) AS rating FROM ratings r, products p WHERE r.productID = p.id GROUP BY p.id) AS b", attributes, values, "products.id = b.pid");
                        
                     } catch (Exception exception) {
                        System.out.println ("exceptie: "+exception.getMessage());
                        if (Constants.DEBUG){
                            exception.printStackTrace();
                            errorMessage =  exception.toString();
                        }
                    } 
                }              
                // logic for logout
                if (parameter.equals("deautentificare")) {
                    session.invalidate();
                    RequestDispatcher requestDispatcher = null;
                    requestDispatcher = getServletContext().getRequestDispatcher("/");
                    requestDispatcher.forward(request,response);
                    return;
                }
                
                // logic for editing personal data
                if (parameter.equals("account")) {
                    //session.invalidate();
                    System.out.println("acountttt");
                    RequestDispatcher requestDispatcher = null;
                    requestDispatcher = request.getRequestDispatcher("/ClientAccountServlet");
                    if (requestDispatcher!=null) {
                        requestDispatcher.forward(request,response);
                    }
                    return;
                }
                
                // get tonkens for search
                if (parameter.contains("search"))
                {
                    searchTokens = request.getParameter(parameter).toString();  
                }
                
                // get invoiceID, productID and message
                if (parameter.contains("comment_") && !request.getParameter(parameter).equals(""))
                {
                    String productID = parameter.split(" ")[0].split("_")[1];  
                    String invoiceID = parameter.split(" ")[0].split("_")[2];
                    String message = request.getParameter(parameter);
                    System.err.println(" ----" + productID+ "-"+invoiceID + " - " + message);
                    
                    
                    ArrayList<String> attributes = new ArrayList<>();
                    attributes.add("customerID");
                    attributes.add("productID");
                    attributes.add("invoiceNumber");
                    attributes.add("message");
                    attributes.add("date");
                    
                    ArrayList<String> values = new ArrayList<>();
                    values.add(userID);
                    values.add(productID);
                    values.add(invoiceID);
                    values.add(message);
                    values.add("NOW()");

                    try {
                        DataBaseConnection.insertValuesIntoTable("problems", attributes, values, true);
                    } catch (Exception exception) {
                        System.out.println ("exceptie: "+exception.getMessage());
                        if (Constants.DEBUG){
                            exception.printStackTrace();
                            errorMessage =  exception.toString();
                        }
                    } 
                }
                
                // logic for getting orders
                if (parameter.equals("orders")) {
                    //session.invalidate();
                    System.out.println("ordeeeers");
                    RequestDispatcher requestDispatcher = null;
                    requestDispatcher = request.getRequestDispatcher("/ClientOrdersServlet");
                    if (requestDispatcher!=null) {
                        requestDispatcher.forward(request,response);
                    }
                    return;
                }
                
                // get tonkens for search
                if (parameter.contains("products"))
                {
                    searchTokens = "";
                }
            }
            
            session.setAttribute(Utilities.removeSpaces(Constants.SHOPPING_CART.toLowerCase()), shoppingCart);
            
            response.setContentType("text/html");
            ClientProductsGUI.displayClientGraphicUserInterface(userID, errorMessage, selectedTable, searchTokens, selectedOrder, shoppingCart,printWriter);
        }
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(true);
        userDisplayName = session.getAttribute(Constants.IDENTIFIER).toString();
        shoppingCart = (ArrayList<Record>)session.getAttribute(Utilities.removeSpaces(Constants.SHOPPING_CART.toLowerCase()));

        response.setContentType("text/html");
        try (PrintWriter printWriter = new PrintWriter(response.getWriter())) {
            ClientProductsGUI.displayClientGraphicUserInterface(userDisplayName, null, selectedTable, searchTokens, selectedOrder, shoppingCart, printWriter);
        }
    }     	 
}
