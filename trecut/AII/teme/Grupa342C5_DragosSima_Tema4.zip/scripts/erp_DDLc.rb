create 'employees', {NAME=>'identification'}, {NAME=>'department'}

create 'projects', {NAME=>'identification'}, {NAME=>'details'}

create 'defects', {NAME=>'identification'}, {NAME=>'details'}, {NAME=>'reference'}

create 'contributions', {NAME=>'reference'}, {NAME=>'details'}
