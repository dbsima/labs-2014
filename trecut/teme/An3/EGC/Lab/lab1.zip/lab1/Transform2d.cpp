#pragma once
#include "Transform2d.h"
#include "Support2d.h"

void Transform2d::translate(Point2d *pct, float tx, float ty){
}

void Transform2d::rotate(Point2d *pct, float angleInRadians){
	
}

void Transform2d::rotateRelativeToAnotherPoint(Point2d *pct, Point2d *ref, float angleInRadians){
	
}
void Transform2d::scale(Point2d *pct, float sx, float sy){
	
}
void Transform2d::scaleRelativeToAnotherPoint(Point2d *pct, Point2d *ref, float sx, float sy){
	
}
