//programul deseneaza figuri care incep sa se roteasca la apasarea
//butonului din stanga al mouse-ului si se opresc la apasarea
//butonului din dreapta.
#include <cstdlib>
#include "dependente\freeglut.h"
#include <iostream>


GLfloat spin=0.0;
GLfloat aspect = 1;

int win_w = 1, win_h = 1;


void init(void)
{	//specifica valorile r,g,b,a folosite atunci cand se sterge bufferul de culoare cu glClear
	glClearColor(0.0f, 0.0f, 0.1f, 0.0f);
}

//functia de afisare
void display(void)
{
	//initializeaza bufferul de culoare
	glClear(GL_COLOR_BUFFER_BIT);

	int i,j;

	//Desenare matrice de cuburi
	for(i=0;i<3;i++)
		for(j=0;j<3;j++)
		{
			glPushMatrix();
			
			if(i==0)
				//rosu
				glColor3f(1.0, 0.0, 0.0);
			if(i==1)
				//verde
				glColor3f(0.0, 1.0, 0.0);
			if(i==2)
				//cyan
				glColor3f(0.0, 1.0, 1.0);

			//Pozitia initiala a obiectului
			glTranslatef((float)(3-(i*3)),(float)(2-(j*2.5)),5.0f);

			//animatia - data de unghiul spin care se modifica in functia animatieDisplay()
			glRotatef(spin, 0.0, 1.0, 0.0);
			
			//se deseneaza un cub wireframe de latura 1
			glutWireCube(1);
					
			glPopMatrix();
		
		}

	glutSwapBuffers();
}

void animatieDisplay()
{
	
	spin=spin+1;

	if(spin>360.0)
		spin= spin -360.0f;

	
	glutPostRedisplay();
}


void reshape(int w, int h)
{
	//transformarea in poarta de vizualizare
	glViewport(0,0, (GLsizei) w, (GLsizei) h);

	aspect = (GLfloat) w / (GLfloat) h;

	//se lucreaza pe matricea de proiectie
	glMatrixMode(GL_PROJECTION);
	//se porneste de la matricea identitate
	glLoadIdentity();
	//transformarea de proiectie - specifica si volumul de vizualizare
	gluPerspective(90.0f, aspect, 0.1f, 60.0f);

	//se lucreaza pe matricea de modelare vizualizare
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	gluLookAt(0.0, 0.0, 0.0,   //observatorul este in origine
		      0.0, 0.0, 1.0,   //si priveste in directia pozitiva a axei oz
			  0.0, 1.0, 0.0);  

	win_w = w;
	win_h = h;


}

//functie apelata la actionarea mouse-ului
void mouse(int buton, int stare, int x, int y)
{
	switch(buton)
	{
	case GLUT_LEFT_BUTTON:
		if(stare == GLUT_DOWN)
			//functia idle animatieDisplay() se apeleaza oricand nu sunt evenimente
			glutIdleFunc(animatieDisplay);
		break;
	case GLUT_RIGHT_BUTTON:
		if(stare== GLUT_DOWN)
			//functia idle este dezactivata 
			glutIdleFunc(NULL);
		break;
	}
}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE|GLUT_RGB);
	glutInitWindowSize(640,480);
	glutInitWindowPosition(100,100);
	glutCreateWindow("Animatie");
	init();
	
	//functia de afisare se numeste display()
	glutDisplayFunc(display);
	
	//functia reshape() este apelata la redimensionarea ferestrei de afisare 
	//sau cand sistemul determina ca s-a acoperit (partial) fereastra
	glutReshapeFunc(reshape);
	
	//functia mouse() se apeleaza la actionarea mouse-ului
	glutMouseFunc(mouse);

	//contine o bucla in care aplicatia asteapta evenimente
	glutMainLoop();
	return 0;
}