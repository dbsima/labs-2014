#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdlib.h>
#include <omp.h>

//functie ce returneaza minimul dintre doua numere int 
int min(int a, int b) { return (a < b) ? a : b; }

//functie ce returneaza maximul dintre doua numere int
int max(int a, int b) { return (a > b) ? a : b; }

//functie principala
int main(int argc, char *argv[])
{
    /*aflare numar de interatii*/
    int T = atoi(argv[1]);
    
    /*deschidere fisier de intrare*/
	FILE *in = fopen(argv[2], "r");
	
	/*deschidere fisier de iesire*/
	FILE *out = fopen(argv[3], "w");
	
	int *stats;
	stats = (int*) malloc(4 * T * sizeof(int));
	int count = 0;
	
	/*citire prima linie din fisier*/
	int Pmin, Pmax, n;
	fscanf (in, "%d", &Pmin);
	fscanf (in, "%d", &Pmax);
	fscanf (in, "%d", &n);
	
	int i, j;
    int i1, j1;
	
    /*
    *declarare, alocare memorie si citire matrice de tipuri de resurse an curent
    */ 
    int **R;   
	
	R = (int**) malloc (n * sizeof(int*));
    for (i = 0; i < n; i++)
        R[i] = (int*) malloc(n * sizeof(int));
	
	for (i = 0; i < n; i++)
	    for (j = 0; j< n; j++)
	        fscanf (in, "%d", &R[i][j]);
	        
	/*
	*declarare, alocare memorie si citire matrice de tipuri de preturi an curent
	*/
    int **P;
    
    P = (int**) malloc (n * sizeof(int*));
    for (i = 0; i < n; i++)
        P[i]=(int*) malloc(n * sizeof(int));
     
	for (i = 0; i < n; i++)
	    for (j = 0; j< n; j++)
	        fscanf (in, "%d", &P[i][j]);
	
	/*
	**declarare, alocare memorie si citire matrice de tipuri de bugete an curent
	*/
	int **B;
	
	B = (int**) malloc (n * sizeof(int*));
    for (i = 0; i < n; i++)
        B[i]=(int*) malloc(n * sizeof(int));
    
	for (i = 0; i < n; i++)
	    for (j = 0; j< n; j++)
	        fscanf (in, "%d", &B[i][j]);
	
	/*
	*declarare, alocare memorie si citire matrice de tipuri de resurse an viitor
	*/
	int **R1;
	R1 = (int**) malloc (n * sizeof(int*));
    for (i = 0; i < n; i++)
        R1[i] = (int*) malloc(n * sizeof(int));
    
    /*
	*declarare, alocare memorie si citire matrice de tipuri de preturi an viitor
	*/
	int **P1;
    P1 = (int**) malloc (n * sizeof(int*));
    for (i = 0; i < n; i++)
        P1[i] = (int*) malloc(n * sizeof(int));
	
	/*
	**declarare, alocare memorie si citire matrice de tipuri de bugete an viitor
	*/
	int **B1;
	B1 = (int**) malloc (n * sizeof(int*));
    for (i = 0; i < n; i++)
        B1[i] = (int*) malloc(n * sizeof(int));
	
	int k;  //contor interatii
	
	for (k = 0; k < T; k++)
	{
	    int noA  = 0;   //numarul de colonisti care produc resursa A (0)
	    int maxA = 0;   //pretul maxim al resursei A
	    int noB  = 0;   //numarul de colonisti care produc resursa B (1)
	    int maxB = 0;   //pretul maxim al resursei B
	    
	    #pragma omp parallel for private(i, j, i1, j1)
	    for (i = 0; i < n; i++)
	        for (j = 0; j < n; j++)
	        {   
	            int Cost = Pmax;    //initializare cost resursa
	            int CostRes = Pmax; //initializare cost resursa complementara
	            
	            /*
	            **fiecare colonist cauta sa cumpare cea mai ieftina resursa 
	            **complementara (luand in calcul pretul resursei + lungimea dru-
	            **mului pana acolo)
	            */  
	            for (i1 = 0; i1 < n; i1++)
	                for (j1 = 0; j1 < n; j1++)
	                {
	                    //calcul distanta Manhattan
                        int dist = abs(i - i1) + abs(j - j1);
                        
                        //calcul distanta Manhattan + pret resursa
                        int pret = P[i1][j1] + dist;
                        
                        //calcul cost minim resursa de tipul Rij
                        if (pret < CostRes && R[i1][j1] == R[i][j])
                            CostRes = pret;
                            
                        //calcul cost minim resursa complementara 
                        if (pret < Cost && R[i1][j1] == (1 - R[i][j]))
                            Cost = pret;
	                }
	                
	            /*
	            **daca costul resursei complementare depaseste bugetul alocat in
	            **acel an, pentru anul viitor va creste bugetul, dar si pretul 
	            **resursei proprii
	            */
	            if (Cost > B[i][j])
	            {
	                R1[i][j] = R[i][j];
	                B1[i][j] = Cost;
	                P1[i][j] = P[i][j] + Cost - B[i][j];
	                
	                /*
	                **daca pretul devine mai mare decat pretul maxim admis de 
	                **legea tinutului, colonistul se re-specializeaza (produce 
	                **resursa complementara), iar pretul si bugetul se actuali-
	                **zeaza
	                */
	                if (P1[i][j] > Pmax)
	                {
	                    R1[i][j] = 1 - R[i][j];
                        B1[i][j] = Pmax;
                        P1[i][j] = (Pmin + Pmax) / 2;
	                }
	            }
	            
	            /*
	            **daca costul resursei complementare(Costij) este sub bugetul a-
	            **locat in acel an, pentru anul viitor va scadea bugetul(respec-
	            **tand limita minima legala), dar si pretul resursei proprii
	            */ 
	            else if (Cost < B[i][j])
	            {
	                R1[i][j] = R[i][j];
	                B1[i][j] = Cost;
	                
	                /*
	                **daca pretul devine mai mic decat pretul minim admis de le-
	                **gea tinutului, pretul se actualizeaza
	                */
	                P1[i][j] = P[i][j] + (Cost - B[i][j]) / 2;
	                if (P1[i][j] < Pmin)
	                    P1[i][j] = max(P1[i][j], Pmin);
	                
	            }
	            
	            /*
	            **daca costul resursei complementare(Costij) este egal cu buge-
	            **tul alocat in acel an, pentru anul viitor se va modifica numai
	            **pretul resursei proprii, bugetul va ramane la fel
	            */
	            else
	            {
	                R1[i][j] = R[i][j];
	                B1[i][j] = Cost;
	                P1[i][j] = CostRes + 1;
	                
	                /*
	                **daca pretul devine mai mare decat pretul maxim admis de 
	                **legea tinutului, colonistul se re-specializeaza (produce 
	                **resursa complementara), iar pretul si bugetul se actuali-
	                **zeaza
	                */
	                if (P1[i][j] > Pmax)
	                {
	                    R1[i][j] = 1 - R[i][j];
                        B1[i][j] = Pmax;
                        P1[i][j] = (Pmin + Pmax) / 2; 
	                }
	            }    
	        }
	        /*
	        **dupa fiecare an se numara numarul de colonisti ce produc resursa A
	        **si resursa B precum si pretul maxim al fiecarei resurse, iar ma-
	        **tricele din anul viitor vor deveni matricele pentru anul curent
	        */
	        for (i = 0; i < n; i++)
	        {	    
	            for (j = 0; j < n; j++)
	            {   
	                if (R1[i][j] == 0)
	                {
	                    noA++;
	                    if (P1[i][j] > maxA)    maxA = P1[i][j];
	                }
	                else
	                {
	                    noB++;
	                    if (P1[i][j] > maxB)    maxB = P1[i][j];
	                }
	                R[i][j] = R1[i][j];
	                P[i][j] = P1[i][j];
	                B[i][j] = B1[i][j];
	            }
            }
            
            stats[count++] = noA;
            stats[count++] = maxA;
            stats[count++] = noB;
            stats[count++] = maxB;
            
	}
	
	/*
	**se afiseaza pe primele T linii cele 4 valori agregate cerute pentru anii 
	**[1..T] (in ordinea: numarul de colonisti care produc resursa A (codificata
	**cu 0), pretul maxim al resursei A, numarul de colonisti care produc resur-
	**sa B (codificata cu 1), pretul maxim al resursei B)
	*/
	for (i = 0; i < 4 * T; i++)
	{
	    fprintf(out, "%d ", stats[i]);
	    if ((i + 1) % 4 == 0)
	        fprintf(out, "\n");
	}
	
	/*
	**se afiseaza o matrice nxn, cu triplete de forma( Rij,Pij,Bij):n linii cu 
	**cate n triplete fiecare, reprezentand configuratia tipurilor de resurse, 
	**a preturilor si a bugetelor in anul T
	*/
	for (i = 0; i < n; i++)
    {	    
        for (j = 0; j < n; j++)
        {
            fprintf(out, "(%d,%d,%d) ", R1[i][j], P1[i][j], B1[i][j]);
        }  
        fprintf(out,"\n");
    }
    
    fclose(in);     //inchidere fisier intrare
    fclose(out);    //inchidere fisier iesire
    
    /*
    **eliberare memorie
    */
    free(stats);
    for (i = 0; i < n; i++)
    {
        free(R[i]);
        free(R1[i]);
        free(P[i]);
        free(P1[i]);
        free(B[i]);
        free(B1[i]);
    }
    free(R);
    free(R1);
    free(P);
    free(P1);
    free(B);
    free(B1);
    
    	 
    return 1;
}
