import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
/**
 * clasa ce reprezinta un workpool de tipul reduce*/
public class ReduceWorkPool extends WorkPool 
{
	//tabela ce retine pentru un fisier, o alta tabela
	//formata din perechi de tipul (cuvant, numar de ap)
	private Hashtable<Object, Hashtable<Object, Object>> data;
	//vector cu nume de fisier
	private Vector<String> files;
	//interclasor
	private Combine combiner;

	public ReduceWorkPool(int nthreads, Combine combiner) 
	{
		super(nthreads);
		this.files = new Vector<String>();
		this.data = new Hashtable<Object, Hashtable<Object, Object>>();
		this.combiner = combiner;
	}

	/*
	 * metoda ce adauga numele unui fisier in vectorul
	 * de fisiere
	 * */
	public void addFileName(String fileName) {
		this.files.addElement(fileName);
	}
	/*
	 * metoda ce interclaseaza doua hashtable-uri
	 * */
	private void mergeHashtables(Hashtable<Object, Object> source, Hashtable<Object, Object> destination, Combine combiner) 
	{
		Enumeration<Object> sourceKeys = source.keys();

		while (sourceKeys.hasMoreElements())
		{
			Object key = sourceKeys.nextElement();
			//daca in tabela in care se va face interclasarea
			//nu se mai gaseste un anumit cuvant, atunci el 
			//este introdus impreuna cu numarul sau de aparitii,
			//iar altfel se adauga la numarul sau de aparitii 
			//initial si numarul de aparitii din cealalata tabela
			if (destination.containsKey(key))
				destination.put(key, (Integer) combiner.combine(destination.get(key), source.get(key)));
			else
				destination.put(key, source.get(key));
		}
	}
	/*
	 * metoda ce proceseaza o solutie partiala pentru un document
	 * */
	public void appendSolution(ReducePartialSolution ps)
	{
		String fileName = ps.getFileName();
		Hashtable<Object, Object> wordPairs = ps.getWordPairs();

		//un thread va verifica daca in tabela unui reducer un 
		//anumit cuvant are o tabela de perechi si daca nu, atunci
		//i se creaza tabela, altfel i se interclaseaza tabela
		//initiala cu cea primita de la un mapper
		synchronized (files.elementAt(files.indexOf(fileName)))
		{
			if (data.get(fileName) == null)
				data.put(fileName, wordPairs);
			else
				mergeHashtables(wordPairs, data.get(fileName), combiner);
		}
	}
	/*
	 * metoda ce intoarce rezultatul unui reducer
	 * */
	public Hashtable<Object, Hashtable<Object, Object>> getResult() {
		return data;
	}
}