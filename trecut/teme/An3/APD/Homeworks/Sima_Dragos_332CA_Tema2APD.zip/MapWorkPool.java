/**
 * clasa ce repezinta un workpool de tipul map*/
public class MapWorkPool extends WorkPool 
{
	public MapWorkPool(int nthreads) 
	{
		super(nthreads);
	}
}