/**
 * interfata ce contine o metoda ce intoarce rezultatul
 * combinarii a doua obiecte*/
public interface Combine {
	public Object combine(Object o1, Object o2);
}
