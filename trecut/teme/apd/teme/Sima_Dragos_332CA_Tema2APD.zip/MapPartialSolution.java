import java.io.IOException;
import java.io.RandomAccessFile;
import java.text.CharacterIterator;
import java.text.StringCharacterIterator;
import java.util.Hashtable;
import java.util.StringTokenizer;

/**
 * clasa ce reprezinta solutia partiala a unui mapper
 * */
public class MapPartialSolution implements PartialSolution
{
	private RandomAccessFile in;	//fisierul procesat
	private String fileName;		//numele documentului
	private long begin;				//pozitia de inceput a fragmentului
	private long end;				//pozitia finala a fragmentului

	/*
	 * constructor ce initializeaza un fragment cu fisierul din care
	 * face parte si pozitiile sale de inceput, respectiv de sfarsit
	 *  */
	public MapPartialSolution(String fileName, long begin, long end) 
	{
		try
		{
			this.in = new RandomAccessFile(fileName, "rw");
			this.in.seek(begin);
			this.fileName = fileName;
			this.begin = begin;
			this.end = end;
			if (end > in.length())
				this.end = this.in.length();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	/*
	 * functie ce intoarce numele documentului procesat de un mapper
	 */
	public String getFileName()
	{
		return fileName;
	}

	/*
	 * metoda ce intoarce o pozitie valida a unui fragment,
	 * fie ea de inceput, fie de sfarsit avand in vedere 
	 * faptul ca aceasta nu trebuie sa fie undeva in 
	 * interiorul unui cuvant
	 */
	private long nextValidPos(long pos) throws IOException
	{
		if (pos == 0 || pos == this.in.length())
			return pos;
		try 
		{
			in.seek(pos);
			while (Character.isLetter((char) in.readByte()))
				pos++;
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return pos;
	}
	/*
	 * metoda ce intoarce o tabele cu perechi de forma (cuvant, numar de
	 * aparitii) pentru un fragment anume 
	 * */
	public Hashtable<Object, Object> getWordPairs() throws IOException
	{
		Hashtable<Object, Object> table = new Hashtable<Object, Object>();
		byte[] buffer = null;

		begin = nextValidPos(begin); //pozitie valida de inceput
		end   = nextValidPos(end);	 //pozitie valida de sfarsit

		try 
		{
			//citirea fragmentului dintr-un fisier
			buffer = new byte[(int) (end - begin)];
			in.seek(begin);
			in.read(buffer, 0, (int) (end - begin));
			
			//parcurgand fragmentul se transforma fiecare caracter
			//nonliteral intr-un caracter spatiu (" ")
			String buf = new String(buffer);
			StringBuffer s = new StringBuffer(buf.length());
			CharacterIterator it = new StringCharacterIterator(buf);
			for (char ch = it.first(); ch != CharacterIterator.DONE; ch = it.next())
			{
			    if(!Character.isLetter(ch))
			    	s.append(" ");
			    else
			    	s.append(ch);
			}
			buf = s.toString();

			//din fragmentul nou rezultat se extrag cuvintele 
			//delimitate de spatiu
			StringTokenizer strk = new StringTokenizer(buf, " ");		
			while (strk.hasMoreTokens())
			{
				String word = strk.nextToken();
				
				//fiecarui cuvant i se schimba majusculele in minuscule
				word = word.toLowerCase();
				
				//daca cuvantul nou rezultat nu a mai fost intalnit in
				//acest fragment el este retinut, iar daca a mai fost
				//intalnit atunci i se creste numarul de aparitii
				if (table.containsKey(word))
					table.put(word, (Integer) table.get(word) + 1);
				else
					table.put(word, 1);
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return table;
	}
}