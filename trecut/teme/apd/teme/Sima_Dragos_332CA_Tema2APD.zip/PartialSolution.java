/**interfata comunta unei solutii partiale de tipul
 * map, respectiv reduce*/
public interface PartialSolution {
	public String getFileName();
}
