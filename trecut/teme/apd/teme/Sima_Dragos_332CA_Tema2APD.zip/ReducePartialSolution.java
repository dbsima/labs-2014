import java.util.Hashtable;
/**
 * clasa ce reprezinta solutia partiala a unui reducer
 * */
public class ReducePartialSolution implements PartialSolution
{
	private String fileName;	//numele documentului
	
	//lista de perechi de tipul (cuvant, nr aparitii) 
	private Hashtable<Object, Object> wordPairs; 

	/*
	 * constructor ce atribuie unui reducer numele 
	 *documentului asupra caruia va face operatia de 
	 *reduce si o statistica ce cuprinde fiecare cuvant
	 *din acel document impreuna cu numarul sau de aparitii
	 */
	public ReducePartialSolution(Object fileName, Hashtable<Object, Object> wordPairs)
	{
		this.fileName = (String) fileName;
		this.wordPairs = wordPairs;
	}

	/*
	 * functie ce intoarce numele fisierului preprocesat
	 */
	public String getFileName() 
	{
		return fileName;
	}

	/*
	 * metoda ce intoarce lista de perechi (cuvant, numar aparitii)
	 */
	public Hashtable<Object, Object> getWordPairs() 
	{
		return wordPairs;
	}
}
