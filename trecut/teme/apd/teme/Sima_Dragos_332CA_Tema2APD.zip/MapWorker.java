import java.io.IOException;

/**
 * clasa ce repezinta un worker de tipul map
 * */
public class MapWorker extends Worker 
{
	//fiecare mapper worker va avea un reduce workpool
	//nu neaparat unic, deparece pentru fiecare document
	//vor exista cel putin un mapper si un reducer
	private WorkPool reduceWP;

	public MapWorker(WorkPool mapWorkpool, WorkPool reduceWP) {
		super(mapWorkpool);
		this.reduceWP = reduceWP;
	}

	/*
	 * un mapper va preprocesa un fragment si ii va da rezultatul 
	 * reducer-ului fragmentului respectiv
	 * */
	@Override
	void processPartialSolution(PartialSolution ps) throws IOException {
		MapPartialSolution mps = (MapPartialSolution) ps;
		reduceWP.putWork(new ReducePartialSolution(mps.getFileName(), mps.getWordPairs()));
	}
}