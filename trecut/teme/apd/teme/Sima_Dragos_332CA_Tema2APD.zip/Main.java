import java.io.RandomAccessFile;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Map;
import java.util.StringTokenizer;
/*
 * clasa ce parcurge un numar de fisiere cautand un numar
 * de cuvinte in aceastea si intoarce un numar maxim de
 * documente cu relevanta maxima de cautare
 * */
public class Main 
{
	//date primite in linia de comanda
	public static int NT;				 //numar de thead-uri
	public static RandomAccessFile in;	 //fisier input
	public static RandomAccessFile out;	 //fisier output
	
	//date gasite in fisierul input
	public static int NC;				 //numar de cuvinte de cautat
	public static String[] wordsToSearch;//cuvinte de cautat
	public static int D;				 //dimensiunea unui fragmen
	public static int N;				 //nr de cuvinte retinute per doc
	public static int X;				 //nr max de documente relevante
	public static int ND;				 //numarul de documente
	public static String[] docs;		 //lista cu numele documentelor

	public static MapWorkPool mapWP;	  //mapper de tipul workpool
	public static ReduceWorkPool reduceWP;//reducer de tipul workpool

	public static MapWorker[] mapWs;	  //lista mapper-i de tip worker
	public static ReduceWorker[] reduceWs;//lista reducer-i de tip worker
	
	/*
	 * metoda ce intoarce o lista de cuvinte obtinute dintr-un
	 * string avand ca delimitator spatiul (" ")
	 **/
	public static String[] tokenizeSentence(String str) 
	{
        StringTokenizer tokenizer = new StringTokenizer(str, " ");
        ArrayList<String> tempList = new ArrayList<String>();
        while (tokenizer.hasMoreElements())
        {
            tempList.add(tokenizer.nextElement().toString());
        }
        String[] ret = new String[tempList.size()];
        tempList.toArray(ret);
        return ret;
    }
	/*
	 * metoda main*/
	public static void main(String[] args)
	{
		if (args.length < 3) 
		{
			System.err.println("Not enough arguments in the command line");
			System.exit(1);
		}

		try 
		{
			NT = Integer.parseInt(args[0]);
			RandomAccessFile in = new RandomAccessFile(args[1], "r");
			RandomAccessFile out = new RandomAccessFile(args[2], "rw");

			//declarare workpool-eri
			mapWP = new MapWorkPool(NT);
			reduceWP = new ReduceWorkPool(NT, new Combine()
			{
				public Object combine(Object o1, Object o2)
				{
					return new Integer((Integer) o1 + (Integer) o2);
				}
			});

			//declarare work-eri
			mapWs = new MapWorker[NT];
			reduceWs = new ReduceWorker[NT];

			//initializare work-eri
			for (int i = 0; i < NT; i++) 
			{
				mapWs[i] = new MapWorker(mapWP, reduceWP);
				reduceWs[i] = new ReduceWorker(reduceWP);
			}

			try 
			{
				NC = Integer.parseInt(in.readLine());
				String line = in.readLine();
			    wordsToSearch = tokenizeSentence(line);
			    D = Integer.parseInt(in.readLine());
			    N = Integer.parseInt(in.readLine());
				X = Integer.parseInt(in.readLine());
				ND = Integer.parseInt(in.readLine());
				docs = new String[ND];
				
				//fiecare document va fi impartit in fragmente
				//ce vor fi atribuite mapper-ilor si reducer-ilor
				for (int i = 0; i < ND; i++) 
				{
					
					String fileName = in.readLine();
					RandomAccessFile doc = new RandomAccessFile(fileName, "r");
					docs[i] = fileName;
					long docLen = doc.length();
					long fragments;

					if (docLen % D == 0)
						fragments = docLen / D;
					else
						fragments = docLen / D + 1;
					
					for (int j = 0; j < fragments; j++)
					{
						mapWP.putWork(new MapPartialSolution(fileName, j * D, (j + 1) * D));
						reduceWP.addFileName(fileName);
					}
					doc.close();
				}
				//pornire mapper-i
				for (int i = 0; i < NT; i++) 
					mapWs[i].start();
				//asteptare terminare mapper-i
				for (int i = 0; i < NT; i++) 
					mapWs[i].join();
				//pornire reducer-i
				for (int i = 0; i < NT; i++) 
					reduceWs[i].start();
				//asteptare terminare reducer-i
				for (int i = 0; i < NT; i++) 
					reduceWs[i].join();

				try 
				{
					Hashtable<String, float []> toPrint = new Hashtable<String, float []>();
					Hashtable<Object, Hashtable<Object, Object>> result = reduceWP.getResult();
					Enumeration<Object> keys = result.keys();
					
					out.writeBytes("Rezultate pentru: (");
					for (int i = 0; i < wordsToSearch.length; i++)
					{
						out.writeBytes(wordsToSearch[i]);
						if (i < wordsToSearch.length - 1)
							out.writeBytes(", ");
						else
							out.writeBytes(")");
					}
					out.writeBytes("\n\n");
					
					//pentru fiecare document procesat se verifica
					//daca contine, intre cele N cuvinte retinute in
					//ordine descrescatoare dupa numarul de aparitii,
					while (keys.hasMoreElements()) 
					{
						String _key = (String) keys.nextElement();
						Hashtable<Object, Object> _table = result.get(_key);
						Object[] myArray;

						myArray = _table.entrySet().toArray();
						Arrays.sort(myArray, new Comparator<Object>() {

							public int compare(Object o1, Object o2)
							{
								if (o1 instanceof Map.Entry	&& o2 instanceof Map.Entry)
									try 
									{
										@SuppressWarnings("unchecked")
										Map.Entry<String, Integer> e1 = (Map.Entry<String, Integer>) o1;
										Map.Entry<String, Integer> e2 = (Map.Entry<String, Integer>) o2;

										return e2.getValue() - e1.getValue();
									} 
									catch (Exception e) 
									{

									}
								return 0;
							}
						});
						
						//se numara cuvintele dintr-un document
						int noWords = 0;
						for (int i = 0; i < myArray.length; i++)
							noWords += ((Map.Entry<String, Integer>) myArray[i]).getValue();

						float [] temp = new float[NC];
						int test = 0;
						int y = 0, i = 0;
						float freq = -1;
						while(y < N)
						{
							//se calculeaza frecventa pentru fiecare cuvant
							String word = ((Map.Entry<String, Integer>) myArray[i]).getKey();
							float frecv = (float)(( (Map.Entry<String, Integer>) myArray[i]).getValue()*10000/noWords)/100;
							if (frecv != freq)
							{
								freq = frecv;
								y++;
							}
							
							for(int j = 0; j < NC; j++)
							{
								if(word.compareToIgnoreCase(wordsToSearch[j]) == 0)
								{
									temp[j] = frecv;
									test++;
								}
							}
							i++;
						}
					}
					//dintre fisierele ce indeplinesc cerintele impuse
					//se vor afisa primele X in ordinea citirii lor din
					//fisierul input
					int cnt = 0;
					for (int i = 0; i < ND; i++)
					{
						if (toPrint.containsKey(docs[i]) && cnt < X)
						{
							out.writeBytes(docs[i]+" (");
							float [] tmp = toPrint.get(docs[i]);
							for (int k = 0; k < tmp.length; k++)
							{
								BigDecimal bd = new BigDecimal(tmp[k]);
								bd = bd.setScale(2, BigDecimal.ROUND_HALF_EVEN);
								out.writeBytes("" + bd);
								if (k < NC - 1)
									out.writeBytes(", ");
								else
									out.writeBytes(")\n");
							}
							cnt++;
						}
					}
				} 
				catch (Exception e)
				{
					System.err.println("Could not open a document");
					System.exit(1);
				}
			} 
			catch (Exception e)
			{
				System.err.println("Could not open the input document");
				System.exit(2);
			}
			//se inchid fisierele
			in.close();
			out.close();
		} 
		catch (Exception e) 
		{
			System.err.println("The argumets in the command line are incorrect");
			System.exit(1);
		}
	}
}
