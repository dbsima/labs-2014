/**
 * clasa ce reprezinta un worker de tipul reduce*/
public class ReduceWorker extends Worker {
	public ReduceWorker(WorkPool workpool) {
		super(workpool);
	}
	/*
	 * un reducer va procesa datele obtinute de la mapper-ii
	 * fragmentului respectiv, interclasandu-le
	 * */
	@Override
	void processPartialSolution(PartialSolution ps)
	{
		((ReduceWorkPool) wp).appendSolution((ReducePartialSolution) ps);
	}
}