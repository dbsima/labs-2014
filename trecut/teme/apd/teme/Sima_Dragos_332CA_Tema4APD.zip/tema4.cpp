#include <fstream>
#include <iostream>
#include <vector>
#include <string>
#include <stdio.h>
#include <cstdlib>
#include <cstring>
#include "mpi.h"
#include <algorithm>
#include <sstream>

using namespace std;

int send_req = 0;
int send_echo = 1;
const int send_mssg = 2;
const int done_texting = 3;
const int send_bcast = 4;
const int done_sending = 5;
const int done_voting = 6;
const int vote_again = 7;
const int send_vote = 8;

vector<int> readNeighbours(char *file, int rank)
{
    // Deschidere fisier ce contine topologia
    FILE *in;
    if ((in = fopen(file, "r")) == NULL)
    {
        fprintf(stderr,"can't open topology file\n");
        exit(EXIT_FAILURE);
    }

    // Parcurg fisierul cu topologia pana la linia corespunzatoare rank-ului
    // curent, pentru a extrage vecinii
    char buf[256];
	for(int i = 0; i <= rank; i++)
         fgets(buf, 256, in);

    // S-ar peste primul numar al liniei, deoarece este rank-ul curent
    char *p;
    p = strtok(buf, " ");
    p = strtok(NULL, " ");

    // Retin vecinii rank-ului curent
    vector<int> neighbours;
    while (p != NULL)
    {
        neighbours.push_back(atoi(p));
        p = strtok(NULL, " ");
    }
	return neighbours;
}

// Clasa ce contine parametrii necesari unei actiuni de trimitere a unui mesaj
class Message
{
	public:
		int src;    // nodul care trimite mesajul
		int dst;    // nodul care va primi mesajul
		int bcast;  // mesaj de tip broadcast
		string mssg;// mesajul in sine

        // Constructorul clasei
        Message()
        {}
};

// Clasa ce contine datele unei topologii
class Topology
{
	public:
        int rank;               // nodul ce detine topologia
		int size;               // dimensiunea topologiei
		vector<int> topology;   // topologia in sine
		vector<int> neighbours; // veciniii

        // Constructorul clasei
		Topology()
		{}

        // Metoda ce completeaza topologia curenta pe baza unei alte topologii
		void add(Topology t)
		{
			for(int i = 0; i < t.topology.size(); i++)
				if(t.topology[i] == 1 && topology[i] == 0)
					topology[i] = 1;
		}
};

// Clasa ce contine datele unei tabele de rutare
class Table
{
	public:
		vector<int> table;  // tabela in sine

        // Constructorul clasei
		Table()
		{}

        // Constructorul clasei
		Table(int size, int parent)
		{
			for(int i = 0; i < size; i++)
				table.push_back(parent);
		}
        // Metoda ce adauga rupe pe baza topologiei curente si a unei alta
		void addMultipleRoutes(int node, int size, Topology t, Topology mine)
		{
			for (int i = 0; i < t.topology.size(); i++)
				if (t.topology[i] == 1 && mine.topology[i] == 0)
					table[i/size] = node;
		}
};

// Clasa ce contine datele pentru un nod
class Node
{
	public:
		int rank;               // procesul curent
		int parent;             // parintele nodului
		int size;               // dimensiunea
		Topology top;           // topologia
		Table table;            // tabela
        vector<int> neighbours; // vecinii
		vector<Message> mssgs;  // mesajele
		vector<bool> fin;       // no more data from sender
		vector<bool> ack;       // acknowledgment

        // Constructorul clasei
		Node (int r, int s)
		{
			rank = r;
			size = s;
			mssgs = vector<Message>(0);
			for (int i = 0; i < s; i++)
			{
                ack.push_back(false);
				fin.push_back(false);
			}
            ack[rank] = true;
			fin[rank] = true;
		}
        // Functie ce verifica daca toate s-au trimis toate mesajele
		bool allSent()
		{
			for(int i = 0; i < size; i++)
				if(fin[i] == false)
					return false;
			return true;
		}
        // Functie ce extrage parametrii actiunilor de trimitere a mesajelor
		void getActions(char *file_name)
		{
            // Deschidere fisier cu linii de forma
            // <nod_sursa> <nod_destinatie> mesaj
            FILE *fin;
            if ((fin = fopen(file_name, "r")) == NULL)
            {
                fprintf(stderr,"can't open log file\n");
                exit(EXIT_FAILURE);
            }
            // citire numar de actiuni de efectuat de pe prima linie
            int no_of_mssgs;
            char line1[256];
            fgets(line1, 256, fin);
            no_of_mssgs = atoi(line1);

            // Pentru fiecare urmatoare linie se retin parametrii necesari tri-
            // miterii mesajului de catre procesul care are de trimis un mesaj
            char *p1, *p2, *msg;
            int c = 0;
            char str[256];
            for (int i = 0; i < no_of_mssgs; i++)
            {
                fgets(line1, 256, fin);
                int line_len = sprintf(str, "%s", line1);
                int extra;

                p1 = strtok(line1, " ");
                int src = atoi(p1);

                if (src == rank)
                {
                    Message m1 = Message();
                    m1.src = rank;
                    m1.mssg = "";

                    p2 = strtok(NULL, " ");
                    int dst;
                    if (p2[0] != 'B')
                    {
                        dst = atoi(p2);
                        m1.dst = dst;
                        m1.bcast = false;
                        extra = sprintf(str, "%d %d", src, dst);
                        printf("%d %d ", src, dst);
                    }
                    else
                    {
                        m1.dst = 0;
						m1.bcast = true;
                        extra = sprintf(str, "%d B", src);
                        printf("%d B ", src);
                    }
                    msg = (char*) malloc (line_len - extra + 1);
                    for (int j = extra + 1; j < line_len; j++)
                        msg[c++] = line1[j];
                    msg[c - 1]='\0';
                    printf("?%s?\n", msg);

                    string s(msg);
                    m1.mssg = s;
                    mssgs.push_back(m1);
                    free(msg);
                }
            }
            fclose(fin);
		}
};

Node discovering(Node n)
{
    // Creare fisier pentru afisarea rezultatelor cu un nume de forma
    // bunker_X.log, unde X reprezinta rank-ul procesului
    char file_name [13];
    int m = sprintf (file_name, "bunker_%d.log", n.rank);
    FILE *fout;
    if ((fout = fopen(file_name, "w")) == NULL)
    {
        fprintf(stderr,"can't open log file\n");
        exit(EXIT_FAILURE);
    }
	int s = n.size;
	if(n.rank == 0)
    {
		MPI_Status status;
        int recv_top[n.size * n.size + 1];

		// Descoperirea topologiei incepe cu procesul de rank 0 care trimite ve-
        // cinilor o cerere de trimitere a tabelolor de rutare ale acestora
		for(int i = 0; i < n.neighbours.size(); i++)
			MPI_Send(&send_req, 1, MPI_INT, n.neighbours[i], send_req, MPI_COMM_WORLD);

        // Constructia tabelei de rutare a procesului de rank 0 se face din ta-
        // belele de rutare ale vecinilor acestuia
		n.table = Table(n.size, 0);
        for(int i = 0; i < n.neighbours.size(); i++)
		{
			MPI_Recv(&recv_top, n.size*n.size, MPI_INT, MPI_ANY_SOURCE, send_echo, MPI_COMM_WORLD, &status);
			int neighbour = status.MPI_SOURCE;
			Topology t = Topology();
			for(int i = 0; i < n.size * n.size; i++)
				t.topology.push_back(recv_top[i]);
			n.table.addMultipleRoutes(neighbour, n.size, t, n.top);
			n.top.add(t);
		}
        // Avand tabela de rutare construia, o afisam in fisierul corespunzator
        fprintf(fout, "Tabela de rutare:\n");
        for(int i = 0; i < n.table.table.size(); i++)
            fprintf(fout, "dst %d, next-hop %d\n", i, n.table.table[i]);
	}
	else
	{
		MPI_Status status;
        int recv_req;
        int recv_top[n.size*n.size+1];

		// Un proces diferit de procesul de rank 0 astepta intai cererea de tri-
        // mitere a tabelei de tutare de la parinte
		MPI_Recv(&recv_req, 1, MPI_INT, MPI_ANY_SOURCE, send_req, MPI_COMM_WORLD, &status);

		int parent = status.MPI_SOURCE;
		n.table = Table(n.size, parent);

        // Odata venita cererea de la parinte, se trimite mai departe o cererea
        // de trimitere a tabelei de rutare la vecinii procesului curent (mai
        // putin parintelui)
		for(int i = 0; i < n.neighbours.size(); i++)
			if(n.neighbours[i] != parent)
				MPI_Send(&send_req, 1, MPI_INT, n.neighbours[i], send_req, MPI_COMM_WORLD);

        // Constructia tabelei de rutare a procesului curent se face din tabele-
        // le de rutare ale vecinilor acestuia
		if(n.neighbours.size() > 1)
		{
			for(int i = 0; i < n.neighbours.size() - 1; i++)
			{
				MPI_Recv(&recv_top, n.size*n.size, MPI_INT, MPI_ANY_SOURCE, send_echo, MPI_COMM_WORLD, &status);
				int neigh = status.MPI_SOURCE;

				Topology t = Topology();
				for(int i = 0; i < n.size * n.size; i++)
					t.topology.push_back(recv_top[i]);
				n.table.addMultipleRoutes(neigh, n.size, t, n.top);
				n.top.add(t);
			}
		}
		// Avand tabela de rutare construia, o afisam in fisierul corespunzator
        fprintf(fout, "Tabela de rutare:\n");
        for(int i = 0; i < n.table.table.size(); i++)
            fprintf(fout, "dst %d, next-hop %d\n", i, n.table.table[i]);
		// si o trimitem mai departe parintelui
		MPI_Send(&n.top.topology.front(), n.top.topology.size(), MPI_INT, parent, send_echo, MPI_COMM_WORLD);
	}
    fclose(fout);
	return n;
}
// Metoda ce creaza un string cu parametrii necesari trimiterii unui mesaj
string archiveParamsAction(Message m)
{
    char message[256];
    sprintf(message, "%d %d %d %s\n",m.src, m.dst, m.bcast, m.mssg.c_str());
    string s(message);
	return s;
}

// Metoda care creaza un Message extragand parametrii necesari trimiterii unui
// mesaj dintr-un string creat in prealabil
Message extractParamsAction(string s)
{
	Message m;
	istringstream tmp(s);
	tmp >> m.src;
	tmp >> m.dst;
	tmp >> m.bcast;
	string st;
	while(tmp >> st)
	{
		m.mssg += st;
        m.mssg += " ";
	}
    m.mssg = m.mssg.substr(0, m.mssg.size()-1);
	return m;
}

void sending(Node n, char *file_name)
{
    // Deschidere fisier pentru afisarea rezultatelor cu un nume de forma
    // bunker_X.log, unde X reprezinta rank-ul procesului
    char log_name [13];
    int m = sprintf (log_name, "bunker_%d.log", n.rank);
    FILE *fout;
    if ((fout = fopen(log_name, "a")) == NULL)
    {
        fprintf(stderr,"can't open log file\n");
        exit(EXIT_FAILURE);
    }
    fprintf(fout,"\nSesiunea de mesaje:\n");

	n.getActions(file_name);
	MPI_Request request;

    // Daca sunt mesaje de trimis
	if(n.mssgs.size() > 0)
	{
		for(int i = 0; i < n.mssgs.size(); i++)
		{
			Message current = n.mssgs[i];
			string index1 = archiveParamsAction(current);
            // daca nu este mesaj destinatie de tip broadcast, atunci el este
            // trimis destinatarului
			if(!current.bcast)
			{
                fprintf(fout, "Trimite mesajul \"%s\" catre %d\n", n.mssgs[i].mssg.c_str(), current.dst);
				MPI_Isend(&index1[0], index1.length(), MPI_CHAR, n.table.table[current.dst], send_mssg, MPI_COMM_WORLD, &request);
			}
            // daca este mesaj de broadcast atunci el este trimis tuturor vecinilor
            else
			{
                fprintf(fout, "Trimite mesajul \"%s\" broadcast\n", n.mssgs[i].mssg.c_str());
				for(int i = 0; i < n.neighbours.size(); i++)
					MPI_Isend(&index1[0], index1.length(), MPI_CHAR, n.neighbours[i], send_bcast, MPI_COMM_WORLD, &request);
			}
		}
	}
    // Am terminat de trimis mesajete asa ca se anunta celelalte buncare.
	for(int i = 0; i < n.neighbours.size(); i++)
	{
        char message[256];
        sprintf(message, "%d",n.rank);
        string src(message);
		MPI_Isend(&src[0], src.size(), MPI_CHAR, n.neighbours[i], done_texting, MPI_COMM_WORLD, &request);
	}

	char mssg[256];
	int* flag;
	MPI_Status status;
	string temp, s;
	while (true)
    {
		MPI_Request request, recv_tmp;
		MPI_Status status;

        // Daca singurul vecin este parintele, si s-au terminat de trimis mesa-
        // jele, buncarul curent poate "spune" ca a terminat si el de trimis
		if(n.neighbours.size() == 1 && n.allSent())
        {
			stringstream str;
			str.flush();
			str << n.rank;
			string src = str.str();
			MPI_Isend(&src[0], src.length(), MPI_CHAR, n.neighbours[0], done_sending, MPI_COMM_WORLD, &recv_tmp);
			src = "";
			break;
		}
		for(int i = 0; i < 256; i++)
			mssg[i] = '\0';
		MPI_Irecv(&mssg, 256, MPI_CHAR, MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &request);
		MPI_Wait(&request,&status);

		for(int i=0; i<temp.length(); i++)
			temp[i] = '\0';
		temp.assign(s.c_str());
		s = mssg;
		if(temp == s)
			continue;
		temp = s;
		if(status.MPI_SOURCE == n.rank)
			continue;

		switch (status.MPI_TAG)
        {
			case send_mssg:
            {
				Message m = extractParamsAction(s);
				if(m.dst == n.rank)
                    fprintf(fout, "Am primit un mesaj de la %d cu textul \"%s\".\n", m.src, m.mssg.c_str());
                else
                {
                    fprintf(fout, "Mesajul de la %d catre %d a trecut prin acest buncar.\n", m.src, m.dst);
					MPI_Isend(&s[0], s.length(), MPI_CHAR, n.table.table[m.dst], send_mssg, MPI_COMM_WORLD, &recv_tmp);
				}
				break;
			}
            // Daca am primit un mesaj de tip broadcast trimitem mai departe
            // mesajul vecinilor
			case send_bcast:
            {
				Message m = extractParamsAction(s);
                fprintf(fout, "Am primit un mesaj broadcast de la %d cu textul \"%s\".\n", m.src, m.mssg.c_str());

                for(int i = 0; i < n.neighbours.size(); i++)
					if(status.MPI_SOURCE != n.neighbours[i])
						MPI_Isend(&s[0], s.length(), MPI_CHAR, n.neighbours[i], send_bcast, MPI_COMM_WORLD, &recv_tmp);
				break;
			}
            // Am primit un mesaj cum ca un vecin a terminat de trimis mesaje
            // anunt mai departe restul vecinilor mei in afara de el
			case done_texting:
            {
				stringstream str;
				str.flush();
				str << s;
				int src;
				str >> src;
				if(n.fin[src] == true)
					 break;
				n.fin[src] = true;
				for(int i = 0; i < n.neighbours.size(); i++)
					if(n.neighbours[i] != status.MPI_SOURCE)
						MPI_Isend(&s[0], s.length(), MPI_CHAR, n.neighbours[i], done_texting, MPI_COMM_WORLD, &recv_tmp);
                break;
			}
            // Am primit un mesaj cum ca un vecin a terminat de trimis mesaje
            // iar eu nu mai am vecini carora sa le trimit mesajul mai departe
            case done_sending:
            {
				stringstream str;
				str.flush();
				str << s;
				int src;
				str >> src;
				n.neighbours.erase(std::remove(n.neighbours.begin(), n.neighbours.end(), src), n.neighbours.end());
                break;
			}
			default:
            {
				char message[256];
                sprintf(message, "%d",n.rank);
                string src(message);
				if(n.neighbours.size() == 1 && n.allSent())
					MPI_Isend(&src[0], src.length(), MPI_CHAR, n.neighbours[0], done_sending, MPI_COMM_WORLD, &recv_tmp);
				break;
			}
		}
	}
    fclose(fout);
}
// Metoda care intoarce din lista de posibili candidati doar pe cei cu numarul
// de voturi maxim
vector<int> winners(vector<int> v)
{
	int max = 0;
	for(int i = 0; i < v.size(); i++)
		if(v[i] > max)
			max = v[i];
	vector<int> bunkers;
	for(int i = 0; i < v.size(); i++)
		if(v[i] == max)
			bunkers.push_back(i);
	return bunkers;
}
// Metoda care creaza un string cu listele ce contin candidatii la cele doua
// pozitii vacante
string archiveBunkers(vector<int> l, vector<int> s)
{
		string bunkers;
		stringstream str;
		for(int i = 0; i < l.size(); i++)
			str << l[i]<<" ";
		str << "-1" << " ";
		for(int i = 0; i < s.size(); i++)
			str << s[i] << " ";
		bunkers = str.str();
		return bunkers;
}
// Metoda care creaza listele ce contin candidatii la cele doua pozitii vacante
// dintr-un string
pair < vector <int>, vector <int> > unarchiveBunkers(string mssg)
{
	vector<int> GENs;
	vector<int> LTDs;
	stringstream s;
	s << mssg;
	bool test = false;
	int index;
	while(s >> index)
    {
		if(!test && index!= -1)
			GENs.push_back(index);
		if(test && index!= -1)
			LTDs.push_back(index);
		if(index == -1)
			test = true;
	}
	return make_pair(GENs, LTDs);
}

// Functie care alege un element random din vectorul ce contine candidatii la
// o pozitie vacanta, cu conditia ca acesta sa fie diferit de nodul care voteaza
int vote(int rank, vector<int> s)
{
	srand(time(NULL)*rank);
	int index = rand()/(RAND_MAX / s.size());
	if(s[index] == rank)
		while(s[index] == rank)
			 index = rand()/(RAND_MAX / s.size());
	return s[index];
}

// Functie care stabileste structura de conducere
void voting(Node n)
{
    // Deschidere fisier pentru afisarea rezultatelor cu un nume de forma
    // bunker_X.log, unde X reprezinta rank-ul procesului
    char file_name [13];
    int m = sprintf (file_name, "bunker_%d.log", n.rank);
    FILE *fout;
    // Se va scrie la finalul fisierului deja existent
    if ((fout = fopen(file_name, "a")) == NULL)
    {
        fprintf(stderr,"can't open log file\n");
        exit(EXIT_FAILURE);
    }
    fprintf(fout,"\nSesiunea de votare:\n");

	int GEN;    // Rank-ul buncarului ce va fi ales pt pozitia de lider
    bool chosen_GEN = false;

    int LTG;    // Rank-ul buncarului ce va fi ales pt pozitia de adjunct
    bool chosen_LTG = false;

	MPI_Status status;
	MPI_Request request;
	char msg_to_recv[256];
	string msg_to_send, local;

    // Procesul de rank 0 va fi nodul centralizator care va aduna voturile, le
    // va numara si va anunta restul buncarelor rezultatul votului
	if(n.rank == 0)
    {
		vector<int> possible_GEN;	// Lista posibililor lideri
		vector<int> no_votes_GEN;   // Numarul de voturi posibililor lideri
		vector<int> possible_LTG;   // Lista posibililor adjuncti
		vector<int> no_votes_LTG;   // Numarul de voturi posibililor adjuncti

        // initial niciun buncar nu si-a exprimat votul si orice buncar este un
        // posibil candidat pentru ambele pozitii
        vector<bool> voted;
		for(int i = 0; i < n.size; i++)
        {
			possible_GEN.push_back(i);
			no_votes_GEN.push_back(0);
			possible_LTG.push_back(i);
			no_votes_LTG.push_back(0);

		}
        // Atat timp cat nu s-au ales conducatorii
		while(true)
        {
			for(int i = 0; i < msg_to_send.size(); i++)
				msg_to_send[i] = '\0';
			for(int i = 0; i < 256; i++)
				msg_to_recv[i] = '\0';
            vector<bool> tmp;
	        for(int i = 0; i < n.size; i++)
		        tmp.push_back(false);
			voted = tmp;
			possible_GEN = winners(no_votes_GEN);
            // cand in "urna" liderilor va ramane un singur candidat, el va fi
            // cel castigator
			if(possible_GEN.size() == 1)
            {
				GEN = possible_GEN[0];
                chosen_GEN = true;
			}
            // cand in "urna" adjunctilor va ramane un singur candidat, el va fi
            // cel castigator
			possible_LTG = winners(no_votes_LTG);
			if(possible_LTG.size() == 1)
            {
				LTG = possible_LTG[0];
                chosen_LTG = true;
			}
			no_votes_GEN.clear();
			no_votes_LTG.clear();

			for(int i = 0; i < n.size; i++)
            {
				no_votes_GEN.push_back(0);
				no_votes_LTG.push_back(0);
			}
			string msg_to_send = archiveBunkers(possible_GEN, possible_LTG);

            // Daca s-a ales atat buncarul lider cat si cel adjunct am terminat
            // de votat
			if (chosen_GEN && chosen_LTG)
            {
				for(int i = 0; i < n.neighbours.size(); i++)
					MPI_Isend(&msg_to_send[0], msg_to_send.size(), MPI_CHAR, n.neighbours[i], done_voting, MPI_COMM_WORLD, &request);
                break;
            }

            // Daca nu s-a ales inca, cel putin una dintre cele doua pozitii
            // atunci se repeta votul pentru pozitiile vacante
			if(!chosen_GEN || !chosen_LTG)
				for(int i = 0; i < n.neighbours.size(); i++)
					MPI_Isend(&msg_to_send[0], msg_to_send.size(), MPI_CHAR, n.neighbours[i], vote_again, MPI_COMM_WORLD, &request);

			int index = vote(n.rank, possible_GEN);
			no_votes_GEN[index] ++;
			int index1 = vote(n.rank, possible_LTG);
			no_votes_LTG[index1] ++;
			voted[n.rank] = true;
            fprintf(fout,"Am votat cu %d pentru pozitia de buncar lider si %d pentru cea de adjunct.\n", index, index1);

            // verifica daca mai sunt noduri ce nu au votat
            bool test;
            int c = 0;
            for(int i = 0; i < voted.size(); i++)
		        if(voted[i] == false)
                    c++;
            if (c > 0)
			    test = false;
            else test = true;

            // Daca inca nu au votat toti
			while(!test)
            {
			    for(int i = 0; i < 256; i++)
				    msg_to_recv[i] = '\0';
			    MPI_Irecv(&msg_to_recv, 256, MPI_CHAR, MPI_ANY_SOURCE, send_vote, MPI_COMM_WORLD, &request);
			    MPI_Wait(&request, &status);
			    if(status.MPI_TAG < 5)
				    continue;

                // extrage sursa
                string local = msg_to_recv;
			    stringstream str;
			    str << local;
			    int src, lv, index1;
			    str >> src;
			    voted[src] = true;

                // Daca nu s-a ales inca, atat buncarul lider cat si cel
                // adjunct, se continua votul pentru ambele pozitii
				if(!chosen_GEN && !chosen_LTG)
                {
					str >> lv >> index1;
					no_votes_GEN[lv] ++;
					no_votes_LTG[index1] ++;
                    fprintf(fout,"Buncarul %d a votat cu %d pentru pozitia de buncar lider si %d pentru cea de adjunct.\n", src, lv, index1);
				}
                // Daca nu s-a ales inca buncarul lider se continua votul
                // pentru aceasta pozitie
				if(!chosen_GEN && chosen_LTG)
                {
					str >> lv;
					no_votes_GEN[lv] ++;
                    fprintf(fout,"Buncarul %d a votat cu %d pentru pozitia de buncar lider.\n", src, lv);
				}
                // Daca nu s-a ales inca buncarul adjunct se continua votul
                // pentru aceasta pozitie
				if(chosen_GEN && !chosen_LTG)
                {
					str >> index1;
					no_votes_LTG[index1] ++;
                    fprintf(fout,"Buncarul %d a votat cu %d pentru pozitia de buncar adjunct.\n", src, index1);
				}
                // verifica daca mai sunt noduri ce nu au votat
                c = 0;
                for(int i = 0; i < voted.size(); i++)
		            if(voted[i] == false)
                        c++;
                if (c > 0)
			        test = false;
                else test = true;
			}
		}
	}
    // Restul proceselor (in afara de cel de rank 0) vor trimite voturile aces-
    // tora pana la alegerea celor doi conducatori
    else
    {
		while(true)
        {
			for(int i = 0; i < msg_to_send.size(); i++)
				msg_to_send[i] = '\0';
			for(int i = 0; i < 256; i++)
				msg_to_recv[i] = '\0';
			MPI_Irecv(&msg_to_recv, 256, MPI_CHAR, MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &request);
			MPI_Wait(&request, &status);
			if(status.MPI_TAG < 6)
				continue;
			string msg_to_send = msg_to_recv;
            // Daca s-au ales conducatorii imi anunt vecinii, in afara nodului
            // parinte cu numele celor 2 conducatori
			if(status.MPI_TAG == done_voting)
            {
				stringstream str;
				str << msg_to_send;
				int tmp;
				str >> GEN >> tmp >> LTG;
				for(int i = 0; i < n.neighbours.size(); i++)
					if(status.MPI_SOURCE != n.neighbours[i])
					    MPI_Isend(&msg_to_send[0], msg_to_send.size(), MPI_CHAR, n.neighbours[i], status.MPI_TAG, MPI_COMM_WORLD, &request);
				break;
			}
            // Se voteaza
			if(status.MPI_TAG == send_vote)
				MPI_Isend(&msg_to_send[0], msg_to_send.size(), MPI_CHAR, n.table.table[0], send_vote, MPI_COMM_WORLD, &request);
            else
            {
				for(int i = 0; i < n.neighbours.size(); i++)
					if(status.MPI_SOURCE != n.neighbours[i])
						MPI_Isend(&msg_to_send[0], msg_to_send.size(), MPI_CHAR, n.neighbours[i], status.MPI_TAG, MPI_COMM_WORLD, &request);
				string local = msg_to_recv;
				pair< vector<int>, vector<int> > p = unarchiveBunkers(local);
				vector<int> possible_GEN = p.first;
				vector<int> possible_LTG = p.second;

                // daca in "urna" liderilor a ramas un singur candidat, el va
                // fi cel castigator
                if(possible_GEN.size() == 1)
                {
					chosen_GEN = true;
					GEN = possible_GEN[0];
				}
                // daca in "urna" adjunctilor a ramas un singur candidat, el va
                // fi cel castigator
				if(possible_LTG.size() == 1)
                {
					chosen_LTG = true;
					LTG = possible_LTG[0];
				}

				stringstream str;
				str << n.rank <<" ";
                // Daca nu s-au ales conducatorii atunci votez pentru ambele po-
                // zitii
				if(!chosen_GEN && !chosen_LTG)
                {
					int index = vote(n.rank, possible_GEN);
					str << index << " ";
					int index1 = vote(n.rank, possible_LTG);
					while(index1 == index)
						index1 = vote(n.rank, possible_LTG);
					str << index1;
                    fprintf(fout,"Am votat cu %d pentru pozitia de buncar lider si %d pentru cea de adjunct.\n", index, index1);
				}
                // Daca nu s-a ales buncarul lider atunci votez pentru aceasta
                // pozitie
				if(!chosen_GEN && chosen_LTG)
                {
					int index = vote(n.rank, possible_GEN);
					str << index;
                    fprintf(fout,"Am votat cu %d pentru pozitia de buncar lider.\n", index);
				}
                // Daca nu s-a ales buncarul adjunct atunci votez pentru aceasta
                // pozitie
				if(chosen_GEN && !chosen_LTG)
                {
					int index = vote(n.rank, possible_LTG);
					str << index;
                    fprintf(fout,"Am votat cu %d pentru pozitia de buncar adjunct.\n", index);
				}
                // Daca s-au ales conducatorii nu mai este nevoie de votul meu
				if(chosen_GEN && chosen_LTG)
					break;

				// Trimit votul meu
				string out = str.str();
				MPI_Isend(&out[0], out.size(), MPI_CHAR, n.table.table[0], send_vote, MPI_COMM_WORLD, &request);
			}
		}
	}
    fprintf(fout, "Buncarul lider este %d, iar buncarul adjunct este %d.\n", GEN, LTG);
    fclose(fout);
}
// Functia principala
int main(int argc,char *argv[])
{
	int size, rank;

	MPI_Init(&argc, &argv);
	MPI_Comm_size(MPI_COMM_WORLD, &size);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);

    Node node(rank, size);
    node.top = Topology();

    node.top.rank = rank;
	node.top.size = size;
	for (int i = 0; i < size * size; i++)
		node.top.topology.push_back(0);
	node.top.neighbours = readNeighbours(argv[1], rank);
	int start =  rank * size;
	for(int i = 0; i < node.top.neighbours.size(); i++)
		node.top.topology[start + node.top.neighbours[i]] = 1;

	for(int i = rank * size; i < rank * size + size; i++)
		if(node.top.topology[i] == 1)
			node.neighbours.push_back(i - rank * size);

    // Descoperirea topologiei
   	node = discovering(node);
	MPI_Barrier(MPI_COMM_WORLD);

    // Trimiterea mesajelor
    sending(node, argv[2]);
	MPI_Barrier(MPI_COMM_WORLD);

    // Sesiunea de votare a liderilor
	voting(node);
	MPI_Barrier(MPI_COMM_WORLD);

	MPI_Finalize();
}

