//structura de date ce retine pentru o mutare sursasi destinatia
public class Move {
	int from;	//sursa
	int to;	//destinatia	    
	
	//functie ce creaza o mutare a unei piese
	public Move(int From, int To) {
		from = From;
		to   = To;
	}

	//functie ce intoarce locul de unde pleaca o piesa
	public int FROM(Move move){
		return move.from;
	}

	//functie ce intoarce locul unde ajunge o piesa
	public int TO(Move move){
		return move.to;
	}

	//functie ce verifica daca o mutare este egala cu alta mutare
	public boolean equals(Move move) {
		if (move.from == from && move.to == to)
			return true;
		return false;
	}
  
	//functie ce verifica daca o mutare este mai mica decat alta  
	public boolean smaller(Move move) {
	if (from > move.from)		return false;
	else if (from < move.from)	return true;
	else						return to < move.to;
	}
}

