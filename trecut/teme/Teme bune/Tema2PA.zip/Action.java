import java.util.*;

public class Action implements Cloneable{
	private Vector action;

	//functie ce creaza o actiune vida (fara mutari)
	public Action() {
		action = new Vector();
	}
	
	//functie ce intoarce numarul de mutari dintr-o actiune
	public int getSize() {
		return action.size();
	}
	
	//funcie ce creaza o actiune dintr-o mutare
	public Action(int s1, int d1) {
		action = new Vector();
		action.add(new Move(s1, d1));
	}

	//functie ce adauga o mutare la o actiune
	public void addAction(Move am) {
		action.add(am);
	}
	
	//functie ce intoarce o mutare de pe o anumita pozitie dintr-o actiune
	public Move getAction(int pos) {
		try {
			return (Move) action.elementAt(pos);
		} catch (ArrayIndexOutOfBoundsException e) {
			return null;
		}
	}
	
	//functie ce intoarce iteratorul unei actiuni
	public Iterator getAction() {
		return action.iterator();
	}
		
	//sortare crescatoare 
	public void crescator() {
		for (int i = 0; i < action.size(); i++) {
			int k = i;
			for (int j = i + 1; j < action.size(); j++) {
				if (((Move) action.elementAt(j)).smaller((Move) action.elementAt(k))) {
				    k = j;
				}
			}
			Move move = (Move) action.elementAt(i);
			action.setElementAt(action.elementAt(k), i);
			action.setElementAt(move, k);
		}
	}

	//sortare descrescatoare
	public void descrescator() {
		for (int i = 0; i < action.size(); i++) {
			int k = i;
			for (int j = i + 1; j < action.size(); j++) {
				if (!((Move) action.elementAt(j)).smaller((Move) action.elementAt(k))) {
					k = j;
				}
			}
			Move move = (Move) action.elementAt(i);
			action.setElementAt(action.elementAt(k), i);
			action.setElementAt(move, k);
		}
	}
	
	//functie ce verifica daca doua actiuni sunt egale
	public boolean equals(Object o) {
		if ( this == o ) {
			return true;
		} else if ( !(o instanceof Action) ) {
			return false;
		} else {
			Action cpy = (Action) this.copy();
			cpy.crescator();

			Action act = (Action) ((Action) o).copy();
			act.crescator();
			if (cpy.action.size() != act.action.size())	return false;
			else {
				for (int i = 0; i < cpy.action.size(); i++) {
					if (!((Move) cpy.action.elementAt(i)).equals(act.action.elementAt(i))) {
						return false;
					}
				}
			}
			return true;
		}
	}

	//functie ce creaza o copie a unei actiuni
	protected Object copy() {
		Action m = null;
		try {
			m = (Action) super.clone();
		}
		catch (CloneNotSupportedException e) {
			System.err.println("Error");
		}
		m.action = (Vector)action.clone();
		return m;
	}
}
