//structura de data de tipul pereche key-value
public class Hash {
	private float value;
	private int key;

	//construnctor ce creaza un element perecher (key, value) 
	public Hash(int key, float value) {
		this.key = key;
		this.value = value;
	}
	
	//functie ce returneaza valoarea unui element
	public float getValue() {
		return this.value;
	}

	//functie ce returneaza cheia unui element
	public int getKey() {
		return this.key;
	}
}
