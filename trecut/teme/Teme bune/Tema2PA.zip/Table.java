import java.util.*;

public class Table implements Cloneable {
	//tabla de joc
	int[] tabla;
	//bara
	int[] piese_bara;
	//afara tablei
	int[] piese_scoase;
	//zarurile
	int zar1;
	int zar2;

    //functie ce creaza tabla de inceput joc
	public Table() {
		tabla = new int[24];
		for (int i = 0; i < 24; i ++)
			tabla[i] = 0;
		//piese albe
		tabla[5]  = -5;
		tabla[7]  = -3;
		tabla[12] = -5;
		tabla[23] = -2;
		//piese negre
		tabla[0]  = 2;
		tabla[11] = 5;
		tabla[16] = 3;
		tabla[18] = 5;
		
		//piese pe bar
		piese_bara = new int[2];
		piese_bara[0] = 0;
		piese_bara[1] = 0;

		//piese scoase
		piese_scoase = new int[2];
		piese_scoase[0] = 0;
		piese_scoase[1] = 0;
	}
	
	//functie ce efectueaza mutarile de tip (from, to) pentru un zar
	public Action moveCheckers(int turn, Action m){
		if (m != null) {
			if (turn == 0)	m.descrescator();
			else 		    m.crescator();
			Iterator iter = m.getAction();			
			while (iter.hasNext()) {
				Move am = (Move) iter.next();
				takeAndDrop(turn, am);
			}
		}
		return m;
	}
	
	//functie ce efectueaza o mutare (from, to)
	private void takeAndDrop(int turn, Move move) {
		take(turn, move.from);
		int to = move.to;
		if(move.to < -1) 	to = -1;
		if(move.to > 24)	to = 24;	
		drop(turn, to);
	}
	
	//functie ce spune daca o piesa poate fi mutata de pe o anumita pozitie
	private void take(int turn, int from) {
		if (from == -1 || from == 24)
			piese_bara[turn] --;
		else {
			if(turn == 0 && tabla[from] <= -1) 	tabla[from] += 1;
			else if(turn == 1 && tabla[from] >= 1) 	tabla[from] -= 1;
		}
	}

	//functie ce spune daca o piesa poate fi mutata pe o pozitie anume
	private void drop(int turn, int to) {
		if (to == -1 || to == 24) piese_scoase[turn] ++;
		else if (turn == 0){
			if (tabla[to] <= 0) tabla[to] -= 1;
			else if (tabla[to] == 1) {
				tabla[to] = -1;
				piese_bara[1] ++;
			}
		}
		else if (turn == 1){
			if (tabla[to] >= 0) tabla[to] += 1;
			else if (tabla[to] == -1) {
				tabla[to] = 1;
				piese_bara[0] ++;
			}
		}
	}

	//functie ce intoarce o lista cu posibile mutari de piese pentru un zar
	public Actions possibleActions(int turn) {
		Action action = new Action();
		Actions posibileActiuni = null;
		int[] span;
		int len;
		
		if (zar1 == zar2) {	//daca am dat dubla
			len = 4;
			span = new int[len];
			span[0] = zar1;
			span[1] = zar1;
			span[2] = zar1;
			span[3] = zar1;

		   if (turn == 0)posibileActiuni = dubla(action, turn, len, span, 23);
			else	posibileActiuni = dubla(action, turn, len, span, 0);
			if (posibileActiuni != null)
				posibileActiuni.maxLen();
		} else {	//daca NU am dat dubla
			len = 2;
			span = new int[len];
			span[0] = zar1;
			span[1] = zar2;
			posibileActiuni = nedubla(action, turn, len, span);
			span[0] = zar2;
			span[1] = zar1;
			posibileActiuni.addSet(nedubla(action, turn, len, span));

			if (posibileActiuni != null) {
				posibileActiuni.maxLen();
				posibileActiuni.maxSpan();
			}
		}
		if (posibileActiuni != null) {
			posibileActiuni.removeDuplicate();
			Iterator iter = posibileActiuni.getIterator();
			while (iter.hasNext()){
				if (turn == 0)		((Action) iter.next()).descrescator();
				else				((Action) iter.next()).crescator();
			}
		}
		return posibileActiuni;
	}
	
	//functie ce returneaza posibilele mutari de piese pentru o dubla
private Actions dubla(Action actiune, int turn, int len, int[] span, int start){
		Actions posibileActiuni = new Actions();
		//daca am explorat fiecare numar de pasi returnam posibilele actiuni
		if (len == 0) {
			posibileActiuni.add(actiune);
		//altfel pentru fiecare numar de pasi generam posibile mutari
		} else {
			int steps = span[len - 1];
			boolean test = false;
			int from = start;
			//mutarea trebuie sa fie valida
			while(from < 24 && from >= 0){
				if( testMove(from, steps, turn) &&
					 ((turn == 0 && tabla[from] < 0) ||
									 (turn == 1 && tabla[from] > 0))){
					test = true;
					Action action = (Action) actiune.copy();
					int to;
					if (turn == 0) to = from - steps;
					else			to = from + steps;
					if (to > 24) 		to = 24;
					else if (to < -1) 	to = -1;
					//parcurgerea pasilor se face recursiv
					Move mutare = new Move(from, to);
					action.addAction(mutare);
					Table cpy = (Table) this.copy();
					cpy.takeAndDrop(turn, mutare);
		 posibileActiuni.addSet(cpy.dubla(action, turn, len - 1, span, from));
				}
				if (turn == 0)	from --;
				else			from ++;
			}
			int bar;
			if(turn == 0) 	bar = 24;
			else			bar = -1; 
			//daca sunt piese pe bara adaug mutarile posibile sa le readuc
			//in joc
			if (piese_bara[turn] > 0 && testMove(bar, steps, turn)) {
				test = true;
				Action action = (Action) actiune.copy();
				int to;
				if (turn == 0) to = bar - steps;
				else			to = bar + steps;
				//parcurgerea pasilor se face recursiv
				Move mutare = new Move(bar, to);
				action.addAction(mutare);
				Table cpy = (Table) this.copy();
				cpy.takeAndDrop(turn, mutare);
				Actions act = cpy.dubla(action, turn, len - 1, span,start);
				posibileActiuni.addSet(act);
			}
			//daca nu exista nicio mutare valida atunci returnam ultima 
			//actiune posibila
			if (!test && actiune.getSize() > 0) {
				posibileActiuni.add(actiune);
			}
		}
		return posibileActiuni;
	}
	
	//functie ce returneaza posibilele mutari de piese in cazul in care nu am
	//dat dubla
	private Actions nedubla(Action actiune, int turn, int len, int[] span) {
		Actions posibileActiuni = new Actions();
		//daca am explorat fiecare numar de pasi returnam posibilele actiuni
		if (len == 0) {
			posibileActiuni.add(actiune);
		//altfel pentru fiecare numar de pasi generam posibile mutari
		} else {
			int steps = span[len - 1];
			boolean test = false;
			//mutarea trebuie sa fie valida
			for (int from = 0; from < 24; from++) {
				if ((turn == 0 && tabla[from] < 0 || 
									turn == 1 && tabla[from] > 0) && 
									testMove(from, steps, turn)) {
					test = true;
					Action action = (Action) actiune.copy();
					int to;
					if (turn == 0) to = from - steps;
					else			to = from + steps;
					if (to > 24)		to = 24;
					else if (to < -1)	to = -1;
					Move mutare = new Move(from, to);
					action.addAction(mutare);
					//parcurgerea pasilor se face recursiv
					Table cpy = (Table) this.copy();
					cpy.takeAndDrop(turn, mutare);
					Actions act = cpy.nedubla(action, turn, len - 1, span);

					posibileActiuni.addSet(act);
				}
			}
			int bar;
			if(turn == 0) 	bar = 24;
			else			bar = -1;
			//daca sunt piese pe bara adaug mutarile posibile sa le readuc
			//in joc
			if (piese_bara[turn] > 0 && testMove(bar, steps, turn)) {
				test = true;
				Action action = (Action) actiune.copy();
				int to;	
				if (turn == 0) to = bar - steps;
				else			to = bar + steps;
				//parcurgerea pasilor se face recursiv
				Move mutare = new Move(bar, to);
				action.addAction(mutare);
				Table cpy = (Table) this.copy();
				cpy.takeAndDrop(turn, mutare);
				Actions act = cpy.nedubla(action, turn, len - 1, span);
				posibileActiuni.addSet(act);
			}
			//daca nu exista nicio mutare valida atunci returnam ultima 
			//actiune posibila
			if (!test && actiune.getSize() != 0) {
					posibileActiuni.add(actiune);
			}
		}
		return posibileActiuni;
	}

 	//functie ce spune daca o mutare anume se poate aplica   
	private boolean testMove(int from, int span, int turn) {
		boolean test = true;
		//daca am piesa pe bara ea este prima ce va fi mutata
		if (turn == 0 && from != 24 && piese_bara[turn] > 0) return false;
		if (turn == 1 && from != -1 && piese_bara[turn] > 0) return false;
		//calcul destinatie din plecare + pasi
		int to;
		if (turn == 0)	to = from - span;
		else			to = from + span;
		//daca destinatia inseamna sa scoatem piesa, verificam daca o putem 
		//scoade
		if (to <= -1 || to >= 24) {
			test = pullOut(turn, from, to);
		} else {	//altfel
			int piese_adversar_la_destinatie;
			if (turn == 0) piese_adversar_la_destinatie = tabla[to];
			else			piese_adversar_la_destinatie = -tabla[to];
			//verificam daca destinatia nu contine cel putin doua piese ale
			//adversarului
			if (piese_adversar_la_destinatie >= 2) return false;
		}
		return test;
	}
		
	//functie ce imi spune daca o anumita piesa poate fi scoasa
	private boolean pullOut(int turn, int from, int to) {
		boolean scot = true;
		//daca mai exista piese ale jucatorului in afara casei atunci nu putem
		//incepe scoaterea pieselor
		if (turn == 0) {
			for (int i = 6; i < 24; i++) {
				if (tabla[i] < 0) return false;
			}
		} else {
			for (int i = 0; i < 18; i++) {
					if (tabla[i] > 0) return false;
			}
		}
		//daca nu mai exista piese ale jucatorului in afara casei atunci veri-
		//ficam daca mai exista piese in spatele piesei de scos
		if(scot == true && turn == 0 && to <= -1){
			if (to == -1 || to == 24) return true;
			else {
				for(int i = from + 1; i < 6; i++){
					if(tabla[i] < 0) return false;
				}
			}
		}
		else if(scot == true && turn == 1 && to >= 24){
			if (to == -1 || to == 24) return true;
			else {
				for(int i = 18; i < from; i++){
					if(tabla[i] > 0) return false;
				}
			}
		}
		return true;
	}

	//functie ce creaza o copie a unei table de joc
	//rolul ei este de a fi folosita drept tester	
	protected Object copy() {
		Table cpy = null;
		try {	
			cpy = (Table) super.clone();
		} catch (CloneNotSupportedException e) {
			System.err.println("Error");
		}		
		cpy.tabla        = (int[])tabla.clone();
		cpy.piese_bara   = (int[])piese_bara.clone();
		cpy.piese_scoase = (int[])piese_scoase.clone();
		cpy.zar1 = zar1;
		cpy.zar2 = zar2;
		return cpy;
	}
}
