import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.net.SocketException;
import java.util.Iterator;

public class ClientStub {
    	static Action m;	//mutarea mea
	static Action a;	//mutarea adversar

	//functie ce citeste un mesaj de pe socket
	public static byte[] readMessage(DataInputStream in) {
		byte[] message = null;
		try {
			byte size = in.readByte();
			message   = new byte[size];
			in.readFully(message);
		} catch (EOFException e) {
			return null;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
		return message;
	}
	//functie ce trimite un mesaj pe socket
	public static void sendMessage(final byte[] message, DataOutputStream out) {
		byte size = (byte) message.length;
		try {
			out.writeByte(size);
			out.write(message);
		} catch (SocketException e) {
			return;
		} catch (IOException e) {
			e.printStackTrace();
			return;
		}
	}
	public static void main(String args[]) {
		if (args.length < 4) {
			System.out.println("ERROR PASSING ARGUMENTS");
			return;
		}
		//variabile pentru conexiune
		Socket socket        = null;
		DataOutputStream out = null;
        	DataInputStream in   = null;
        
		int cul = 0;
		Table table = new Table();
        	
		try {
			//conexiune la server
			socket = new Socket(args[0], Integer.parseInt(args[1]));
			// citesc din in de pe socket
		     in = new DataInputStream(socket.getInputStream());
			// scriu in out pe socket
			out = new DataOutputStream(socket.getOutputStream());
		       
		     // trimit primul mesaj - dificulatea adversarului
			byte[] difficulty = new byte[1];
			difficulty[0] = Byte.parseByte(args[2]);
			ClientStub.sendMessage(difficulty, out);

            	// primesc raspuns cu culoarea mea
		   	byte[] colour = new byte[1];
		   	colour = ClientStub.readMessage(in);  
			if (colour[0] == 1) {
				//joc cu negrele, adversarul cu albele
				cul = 1;
			} else if (colour[0] == 0) {
				//joc cu albele, adversarul cu negrele
				cul = 0;
			}
			Player me = new Player(cul);
			
			byte[] moves;
			//cat timp jocul nu s-a terminat
			while (true) {	
				//citire mesaj de la server
				byte size = in.readByte();
				moves     = new byte[size];
				in.readFully(moves);

				//am primit mesaj de tipul winner/looser=>partida se incheie
				if(moves[0] == 87 || moves[0] == 76){
					break;
				}
				//muta adversarul
				if(moves.length > 2){
					a = new Action();
					for (int i = 0; i < moves.length - 3; i += 2){
						//aflu pentru fiecare piesa de unde pleaca si unde
						//ajunge si aplic pe tabla
						int from = (int) moves[i];
						int span = (int) moves[i + 1];
						int dest;
						if (cul == 1 && from == 30){
							from = 24;
							dest = from - span;
						}
						else if (cul == 0 && from == 30){
							from = -1;
							dest  = from + span;
						}
						else {
							from -= 1;
							if(cul == 1)	dest = from - span;
							else			dest = from + span;
						}
						a.addAction(new Move(from, dest));
					}
					table.moveCheckers(1 - cul, a);
			  	}
				//perechea de zaruri va fi gasita intotdeauna pe ultimile  
				//doua pozitii din mesajul primit
				table.zar1 = (int) moves[moves.length - 2];
		    		table.zar2 = (int) moves[moves.length - 1];
			   	int[] spans;
			   	int len;
				//daca nu am dat dubla atunci vor fi maxim 2 mutari
				if (table.zar1 != table.zar2) {
					len = 2;
					spans = new int[len];
					spans[0] = moves[moves.length - 2];
					spans[1] = moves[moves.length - 1];
				}
				else {//daca am dat dubla, vor fi maxim 4 mutari
					len = 4;
					spans = new int[len];
					spans[0] = moves[moves.length - 2];
					spans[1] = moves[moves.length - 2];
					spans[2] = moves[moves.length - 2];
					spans[3] = moves[moves.length - 2];
				}

				//aflu cea mai favorabila actiune pe care pot sa o fac
				//m = (new Minimax(cul)).bestMove(table);
				m = me.bestMove(table);
				//aplic actiunea pe tabla
				m = table.moveCheckers(cul, m);

				//trimit aciunea la server
				if (m == null) m = new Action();
				byte[] toSend = new byte[2 * m.getSize()];
	    			int j = 0;
	    			int i = 0;
	    			while (i < m.getSize()) {
	    				int from = m.getAction(i).FROM(m.getAction(i));
					int dest = m.getAction(i).TO(m.getAction(i));
					int span;
					if (cul == 0){
						span = from - dest;
						if (from >= 24)	from = 30;
						else 			from += 1; 
					}
					else {
						span = dest - from;
						if (from <= -1)	from = 30;
						else				from += 1;
					}
					toSend[j++] = (byte) (from);
					toSend[j++] = (byte) (span);
					i++;
	    			}
				//am grija sa folosesc maxLen si maxSpan
	    			for(int k = 0; k < 2*m.getSize(); k += 2){
	    				int test = 0;
	    				for (int l = 0; l < len; l++)
	    					if (spans[l] != 0) {
							test = 1;
							break;
						}
					if(test == 0)
						break;
	    				else {
	    					int maxSpan    = 0;
	    					int maxSpanPos = 0;
	    					for (int l = 0; l < len; l++) {
	    						if (spans[l] > maxSpan) {
	    							maxSpan    = spans[l];
	    							maxSpanPos = l;
	    						}
	    						if ((byte) spans[l] == toSend[k + 1]) {
								spans[l]   =  0;	    							
								maxSpanPos = -1;
	    							break;
	    						}
	    					}
	    					if (maxSpanPos != -1) {
	    						toSend[k + 1]     = (byte) maxSpan;
	    						spans[maxSpanPos] = 0;
	    					}
	    				}
	    			}
	    			ClientStub.sendMessage(toSend, out);
			}
			socket.close();

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}
}

