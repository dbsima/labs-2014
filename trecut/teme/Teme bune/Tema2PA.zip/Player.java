public class Player {
	//adancimea copacului	
	int depth;
	//jucatorul
	int turn;
	//nod pentru aflare bestCase
	int max1 = 0;
	//nod pentru aflare worstCase
	int min1 = 2;
	//noduri pentru aflsare expectedCase 
	int max2 = 3;
	int min2 = 1;

	//constructor ce creaza un jucator
	public Player (int turn) {
		this.depth = 5;
		this.turn  = turn;
	}

	//functie ce intoarce cea mai favorabila actiune ce o pot face
	public Action bestMove(Table t) {
		Hash best = bestCase(t, this.max1, this.depth);
		return t.possibleActions(this.turn).getActions(best.getKey());
	}
	
	//functie ce genereaza scenariul asteptat
	private Hash expected(Table t, int typeOfNode, int hight) {
		float generate = 0.0F;		
		float[] val = new float[21];
		hight--;
		for(int i = 0; i < 21; i++) {
			Table cpy = (Table) t.copy();
			if (i < 6) {
				cpy.zar1 = 1;
				cpy.zar2 = i + 1;
			}
			else if (i < 11) {
				cpy.zar1 = 2;
				cpy.zar2 = i - 4;
			}
			else if (i < 15) {
				cpy.zar1 = 3;
				cpy.zar2 = i - 8;
			}
			else if (i < 18) {
				cpy.zar1 = 4;
				cpy.zar2 = i - 11;
			}
			else if(i < 20) {
				cpy.zar1 = 5;
				cpy.zar2 = i - 13;
			}
			else	{
				cpy.zar1 = 6;
				cpy.zar2 = 6;                
			}
			int adv = 1 - this.turn;
			//daca partida s-a terminat sau am ajuns la ultimul nivel atunci 
			//evaluam
         if(cpy.piese_scoase[turn]==15 || cpy.piese_scoase[adv]==15 || hight==1)
				val[i] = evaluate(cpy, this.turn);
			//daca se cauta minimul atunci aflam worst scenario
			else if(typeOfNode == this.min2)
				val[i] = worstCase(cpy, this.min1, hight).getValue();
			//daca se cauta maximul atunci aflam best scenario
			else
				val[i] = bestCase(cpy, this.max1, hight).getValue();
			//tinem cont de probabilitatile zarurilor
			if (i == 0 || i == 6 || i == 11 || i == 15 || i == 18 || i == 20)
				generate += val[i]*(1.0F/36.0F);
			else generate += val[i]*(1.0F/18.0F);
		}
		
		return new Hash(0, generate); 
	}
	
	//functie ce arata cel mai bun scenariu pe care il putem intalni din cauza
	//posibilelor actiuni ale mele
	private Hash bestCase(Table t, int typeOfNode, int hight) {
		Actions act = t.possibleActions(this.turn);
		float[] val = new float[act.getSize()];
		hight--;
		//daca adversarul poate executa actiuni atunci pentru fiecare posibila 
		//actiune daca am ajuns in "varful" copacului evaluam, daca nu trecem 
		//la urmatorul nivel
		if (val.length != 0) 
			 for (int i = 0; i < act.getSize(); i++) {
				Table cpy = (Table)t.copy();
				cpy.moveCheckers(this.turn, act.getActions(i));
				if (hight == 1) val[i] = evaluate(cpy, this.turn);
				else	val[i] = expected(cpy, this.min2, hight).getValue();
			}
		//daca adversarul nu are actiuni de facut atunci verificam daca am 
		//ajuns in varf caz in care evaluam, altfel trecem la urmatorul nivel
		else {
			val = new float[1];
			if(hight == 1)	val[0] = evaluate(t, this.turn);
			else	val[0] = expected(t, this.min2, hight).getValue();
		}
		//aflam maximul si pozitia sa
		float max  = val[0];
		int maxPos = 0;
		for(int i = 1; i < val.length; i++) {
			if (max < val[i]){
				max    = val[i];
				maxPos = i;
			}
		}
		return new Hash(maxPos, max);
	}

	//functie ce arata cel mai rau scenariu pe care il putem intalni din cauza
	//posibilelor actiuni ale adversarului
	private Hash worstCase(Table t, int typeOfNode, int hight) {
		int adv = 1 - this.turn;
		Actions act = t.possibleActions(adv);
		float[] val = new float[act.getSize()];
		hight--;
		//daca adversarul poate executa actiuni atunci pentru fiecare posibila 
		//actiune daca am ajuns in "varful" copacului evaluam, daca nu trecem 
		//la urmatorul nivel
		if(val.length != 0)
			for (int i = 0; i < act.getSize(); i++) {
				Table cpy = (Table)t.copy();
				cpy.moveCheckers(adv, act.getActions(i));
				if(hight == 1)	val[i] = evaluate(cpy, this.turn);
				else val[i] = expected(cpy, this.max2, hight).getValue();
			}
		else	{
		//daca adversarul nu are actiuni de facut atunci verificam daca am 
		//ajuns in varf caz in care evaluam, altfel trecem la urmatorul nivel
			val = new float[1];
			if(hight == 1)	val[0] = evaluate(t, this.turn);
			else	val[0] = expected(t, this.max2, hight).getValue();
		}
		//aflam minimul si pozitia sa
		int minPos = 0;
		float min = val[0];
		for(int i = 1; i < val.length; i++) {
			if (min > val[i]){
				min = val[i];
				minPos = i;
			}
		}
		return new Hash(minPos, min); 
	}
   	
	//functie ce evalueaza tabla in fuctie de pozitia pieselor, atat proprii 
	//cat si ale adversarului, dupa o anumita strategie
	public float evaluate(Table t, int turn) {
		int tax = minAndPLus(t, turn);
		int adv = 1 - turn;
		//taxam piesele ce nu formeaza o poarta
		tax -= noGate(t, turn);
		//daca adversarul are piese pe bara atunci sunt necesare porti sa-i
		//impiedice revenirea 
		if (t.piese_bara[adv] > 0)
			tax += noComeBack(t, turn);
		//altfel aduc un + portile una langa cealalta
		else if (t.piese_bara[adv] <=  0 && tax <= 2*24*24)
			tax += gatesAway(t, turn);
		return (float)tax;
	}

	//functie ce acorda + pentru piese in casa si cat mai aproape de casa si pt 
	//piese pe bara ale adversarului si - pentru piese ale adversarului in casa
	//si cat mai aproape de casa sa si piese ale mele pe bara 
	private int minAndPLus(Table t, int turn) {
		int tax = 0;
		int adv = 1 - turn;
		tax -= t.piese_scoase[adv]*24;
		tax -= t.piese_bara[turn]*24;
		tax += t.piese_scoase[turn]*24;
		tax += t.piese_bara[adv]*24*24;
		for (int i = 0; i < 24; i++) {
			if (t.tabla[i] > 0)tax += (turn*t.tabla[i]*i - adv*t.tabla[i]*i);
			else	{
				int pen = 24 - i - 1;
				tax -= (turn*t.tabla[i]*pen + adv*t.tabla[i]*pen);
			}
		}
		return tax;
	}

    //functie ce da - pentru piese ce nu formeaza o poarta
	private int noGate(Table t, int turn) {
		int homeless = 0;
		if (turn == 0) {
			for (int i = 0; i < 24; i++)
				if (t.tabla[i] <= 0) {
					for(int k = i + 1; k < 24; k++) {
						if(t.tabla[k] == -1) homeless ++;
					}
				}
		}
		else {
			for (int i = 23; i >= 0; i--)
				if (t.tabla[i] >= 0) {
					for (int k = 0; k < i; k++) {
						if(t.tabla[k] == 1)	homeless ++;
					}
				}
				else	break;
		}
		return homeless;
	}

	//functie ce da + pentru incomodarea adversarului in a reveni cu piese de
	//pe bara
	private int noComeBack(Table t, int turn) {
		int c = 0;
		int adv = 1 - turn;
		for (int i = adv*23; ; i += 2*turn - 1)
			if((t.tabla[i]*turn + turn - 1 > t.tabla[i]*adv + turn) && (c<7))
				c++;
			else
				break;
		return c*24;
	}

	//functie ce acorda + pentru incomodarea adversarului facand porti cat mai
	//aproape de casa acestuia (porta langa poarta)
	private int gatesAway(Table t, int turn) {
		int gate = 0;
		int tax = 0;
		int adv = 1 - turn;
		for(int i = (turn + 13*adv); i < (11*turn + 23*adv); i++) {
			if( (turn*t.tabla[i] - 1 + turn) > (turn + adv*t.tabla[i]) )
				gate++;
			else {
				if(gate > tax) tax = gate;
				gate = 0;
			}
		}
		if(gate > tax)	tax = gate;
		return tax*24;
	}
}
