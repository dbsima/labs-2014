import java.util.*;

public class Actions {
	private Vector actions;
	
	//functie ce creaza un set de actiuni vid (fara actiuni)
	public Actions() {
		actions = new Vector();
	}
	
	//functie ce intoarce actiunile unui anumit set
	public Action getActions(int pos) {
		try {
			return (Action) actions.elementAt(pos);
		} catch (ArrayIndexOutOfBoundsException e) {
			return null;
		}
	}

	//functie ce adauga o actiune la un set
	public void add(Action action) {
		actions.add(action);
	}

	//functie ce adauga actiunile dintr-un set la un alt set de actiuni
	public void addSet(Actions mset) {
		actions.addAll(mset.actions);
	}
	
	//functie ce intoarce numarul de actiuni dintr-un set de actiuni
	public int getSize() {
		return actions.size();
	}
	
	//functie ce intoarce iteratorul unui set de actiuni
	public Iterator getIterator() {
		return actions.iterator();
	}
	
	//functie ce modifica un set astfel incat actiunile sale sa foloseasca 
	//maximul de numar de pasi
	public void maxLen() {
		int maxLen = 0;
		for (int i = 0; i < actions.size(); i++) {
			int len = ((Action) actions.elementAt(i)).getSize();
			if (len > maxLen) maxLen = len;
		}
		for (int i = actions.size() - 1; i >= 0; i--) {
			int len = ((Action) actions.elementAt(i)).getSize();
			if (len < maxLen) actions.removeElementAt(i);
		}
	}

	//functie ce modifica un set astfel incat actiunile sale sa foloseasca 
	//zarul cel mai mare, in cazul in care ambele zaruri pot fi folosite
	public void maxSpan() {
		if (actions.size() > 0) {
			if (((Action) actions.elementAt(0)).getSize() == 1) {
				int maxSpan = 0;
				for (int i = 0; i < actions.size(); i++) {
					Move move=((Action) actions.elementAt(i)).getAction(0);
					int span = Math.abs(move.from - move.to);
					if (span > maxSpan)	maxSpan = span;
				}
				for (int i = actions.size() - 1; i >= 0; i--) {
					Move move=((Action) actions.elementAt(i)).getAction(0);
					int span = Math.abs(move.from - move.to);
					if (span < maxSpan)	actions.removeElementAt(i);
				}
			}
		}
	}

	//functie ce modifica un set de actiuni astfel incat sa nu aiba doua 
	//actiuni "egale"
	public void removeDuplicate() {
		for (int i = 0; i < actions.size(); i++) {
		  for (int j = actions.size() - 1; j > i; j--) {
			if (((Action) actions.elementAt(i)).equals(actions.elementAt(j)))
					actions.removeElementAt(j);
		  }
	    }
	}
}
