#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h> 
#include <unistd.h>

#define BUFLEN 256

//functie ce afiseaza cauza unei erori si produce oprirea rularii executabilului
void error(char *msg) {
	perror(msg);
	exit(0);
}

//functie ce intoarce maximul dintre doua numere
int max(int a, int b) {
	if (a > b) return a;
	return b;
}
int main(int argc, char *argv[]) {
	//verificare daca au fost trimisi toti parametri necesari pentru client	
	if (argc < 4) {
		fprintf(stderr, "Usage %s nume_client serv_address serv_port\n", argv[0]);
		exit(0);
	}
	
	//deschidere socket server
	int sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd < 0) error("ERROR opening socket");

	//portul pe care clientul asculta eventuale cereri de conexiune
	int portClient;
	while (1) {
		printf("PORT for listening: ");
		scanf("%d", &portClient);
		//in cazul in care clientul alege ca port de ascultat portul cu care
		//s-a conectat la server atunci i se cere introducerea unui alt port
		if (portClient == atoi(argv[3]))	printf("ERROR choosing port\n");
		else break;
	}

	//parametri pentru conexiune client - server
	struct sockaddr_in serv_addr;
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port   = htons(atoi(argv[3]));
	inet_aton(argv[2], &serv_addr.sin_addr);

	//verificare daca conexiunea client-server s-a realizat
	if (connect(sockfd, (struct sockaddr*) &serv_addr, sizeof(struct sockaddr)) < 0) 
		error("ERROR connecting");
	
	//compunere un mesaj ce contine nume_client si port_client 
	char sendPort[BUFLEN];
	sprintf(sendPort, "%s %d\0", argv[1], portClient);
	
	//trimitere mesaj la server
	int n = send(sockfd, sendPort, strlen(sendPort), 0);
	if (n < 0) error("ERROR writing to socket");

	//receptionare mesaj conectare
	char ack;
	n = recv(sockfd, &ack, 1, 0);
	if (n < 0) error("ERROR reading from socket");
	else if (n == 0) error("ERROR server closed");
	else if (ack == 0) printf("Connected\n");
	else error("ERROR passing name and port");
	
	//deschidere socket client
	int sockfdClient = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfdClient < 0) error("ERROR opening socket");

	//parametri pentru conexiune client - client
	struct sockaddr_in client_addr;
	client_addr.sin_family      = AF_INET;
	client_addr.sin_port        = htons(portClient);
	client_addr.sin_addr.s_addr = INADDR_ANY;

	//verificam daca clientul poate realiza conexiuni cu alti clienti
 if(bind(sockfdClient, (struct sockaddr*) &client_addr,sizeof(struct sockaddr))<0) 
		error("ERROR binding");
	
	//ascultam pe port pentru posibile conexiuni (maxim 5)
	listen(sockfdClient, 5);

	//multimea de citire folosita in select()
	fd_set read_fds;
	//golim multimea de descriptori de citire (read_fds) 	
	FD_ZERO(&read_fds);
	//adaugam noul file descriptor (socketul pe care se asculta conexiuni)
	FD_SET(0, &read_fds);
	FD_SET(sockfd, &read_fds);
	FD_SET(sockfdClient, &read_fds);
	
	//aflare valoare maxima file descriptor din multimea read_fds
	int fdmax = max(sockfd, sockfdClient);		
	
	//multime folosita temporar
	fd_set tmp_fds;
	//golim multimea tmp_fds de descriptori	
	FD_ZERO(&tmp_fds);

	//client expeditor
	int newsockfd;
	struct sockaddr_in newaddr;
	//client destinatie
	int destsockfd;
	struct sockaddr_in destaddr;

	//buffere
	char buffer[BUFLEN];
	char message[BUFLEN];
	//pachete de date
	char mes[BUFLEN];
	char toSend[1400];
	char pkg[1400];
	
	//getfile
	FILE *snd, *rcv;
	char **file = (char**) malloc(5 * sizeof(char*));	//numele fisierelor
	int files  = 0;	//numar fisiere
	int fileAt = 0;	//pozitia unui fiser in lista de fisiere
	//nume de fisere
	char fl[BUFLEN];
	char fileSend[BUFLEN];
	char cl[BUFLEN];
	char fileRecv[BUFLEN];
	//pozitia unui octet
	long int at;
	char aT[BUFLEN];
	//dimensiunea unui packet
	int dim;
	char len[BUFLEN];
	
	int i, j;	
	while (1) {
	    tmp_fds = read_fds;
		if (select(fdmax + 1, &tmp_fds, NULL, NULL, NULL) == -1) 
			error("ERROR in select");
		for(i = 0; i <= fdmax; i++) {
			if (FD_ISSET(i, &tmp_fds)) {
				if (i == 0) { //clientul citeste comenzi de la tastatura
					//citire comanda					
					memset(buffer, 0 , BUFLEN);
					fgets(buffer, BUFLEN - 1, stdin);
					buffer[strlen(buffer) - 1] = '\0';
					if (strncmp(buffer, "listclients", 11) == 0) {
						//compunere cerere prin care cere server-ului lista 
						//tuturor clientilor conectati
						char *demand = strdup("1");
						//trimitere cerere
						n = send(sockfd, demand, strlen(demand), 0);
						if (n < 0) error("ERROR writing to socket");
					}
					else if (strncmp(buffer, "infoclient", 10) == 0) {
						//compunere cerere prin care cere server-ului informatii
						//suplimentare despre un anumit client
						char *demand = strtok(buffer, " ");
						char *clnt = strtok(NULL, " ");
						strcpy(cl, clnt);
						memset(message, 0, BUFLEN);
						sprintf(message, "%d%s", 2, cl);
						//trimitere cerere
						n = send(sockfd, message, strlen(message), 0);
						if (n < 0) error("ERROR writing to socket");
					}
					else if (strncmp(buffer, "message", 7) == 0) {
						//compunere cere prin care cere server-ului parametrii
						//necesari pentru a realiza o conexiune cu clientul do-
						//rit in vederea trimiterii unui mesaj
						char *demand = strtok(buffer," ");
						char* dest = strtok(NULL, " ");
						strcpy(cl, dest);
						char *msg = strtok(NULL, "\n");
						strcpy(mes, msg);
						memset(message, 0, BUFLEN);
						sprintf(message, "%d%s", 3, cl);
						//trimitere cerere
						n = send(sockfd, message, strlen(message), 0);
						if (n < 0) error("ERROR writing to socket");
						//primire raspuns
						memset(buffer, 0, BUFLEN);
						n = recv(sockfd, buffer, sizeof(buffer), 0);
						if (n < 0) error("ERROR reading from socket");
						else if (n == 0) error("ERROR server closed");
						//procesare raspuns					
						char *ACK = strtok(buffer, " ");
						if (ACK[0] == '3') { //am primit date despre clientul la care vrem sa trimitem mesaj
							//procesare mesaj
							char *ip = strtok(NULL, " ");
							inet_aton(ip, &destaddr.sin_addr);
							char *port = strtok(NULL, " ");
							destaddr.sin_port = htons(atoi(port));
							char *af = strtok(NULL, " ");
							destaddr.sin_family = (short int) atoi(af);
						
							//deschidere conexiune cu clientul caruia se
							//vrea sa i sa trimita mesaj
							destsockfd = socket(AF_INET, SOCK_STREAM, 0);
							if (connect(destsockfd, (struct sockaddr*) &destaddr, sizeof(struct sockaddr)) < 0) 
								error("ERROR connecting");
							//adaugare noului file descriptor in 
							//multime
							FD_SET(destsockfd, &read_fds);
							//updatare
							fdmax = max(fdmax, destsockfd);
							//compunere mesaj pentru destinatar ce 
							//contine numele expeditorului si mesaj
							memset(buffer, 0, BUFLEN);
							sprintf(buffer, "%d%s: %s", 3, argv[1], mes);
							//trimitere mesaj
							n = send(destsockfd, buffer, strlen(buffer), 0);
							if (n < 0) error("ERROR writing to socket");
							//receptionare mesaj
							int acK;
							n = recv(destsockfd, &acK, sizeof(int), 0);
							if (n < 0) error("ERROR reading from socket");
							else if (n == 0) error("ERROR server closed");
							//verificare daca mesajul a ajuns la 
							//destinatar
							if (acK == 0) {
								FD_CLR(destsockfd, &read_fds);
								close(destsockfd);
							}
						}
					}
					else if (strncmp(buffer, "sharefile", 9) == 0) {
						//compunere mesaj cu numele fisierului de share-uit
						char *demand = strtok(buffer, " ");
						char *fisier = strtok(NULL, " ");
						strcpy(fl, fisier);
						memset(message, 0, BUFLEN);
						sprintf(message, "%d%s", 4, fl);
						//trimitere cerere
						n = send(sockfd, message, strlen(message), 0);
						if (n < 0) error("ERROR writing to socket");
							
					}
					else if (strncmp(buffer,"unsharefile", 11) == 0) {
						//compunere mesaj cu numele fisierului de unshare-uit
						char *demand = strtok(buffer, " ");
						char *fisier = strtok(NULL, " ");
						strcpy(fl, fisier);
						memset(message, 0, BUFLEN);
						sprintf(message, "%d%s", 5, fl);
						//trimitere cerere
						n = send(sockfd, message, strlen(message), 0);
						if (n < 0) error("ERROR writing to socket");
						//cautare fiser din lista cu fisiere partajate
						for (j = 0; j < files; j++)
							if (strcmp(fl, file[j]) == 0) {
								fileAt = j;
								break;
							}
					}
					else if (strncmp(buffer, "getshare", 8) == 0) {
						//compunere mesaj cu numele clientului ale caror infor-
						//matii se doresc aflate
						char *demand = strtok(buffer, " ");
						char *clnt = strtok(NULL, " ");
						strcpy(cl, clnt);
						memset(message, 0, BUFLEN);
						sprintf(message, "%d%s", 6, cl);
						//trimitere mesaj
						n = send(sockfd, message, strlen(message), 0);
						if (n < 0) error("ERROR writing to socket");
					}
					else if (strncmp(buffer, "getfile", 7) == 0) {
						//compunere mesaj cu numele clientului ce detine fisierul
						//dorit si numele fisierui						
						char *demand = strtok(buffer, " ");
						char *clnt = strtok(NULL, " ");
						strcpy(cl, clnt);
						char *fisier = strtok(NULL, " ");
						strcpy(fl, fisier);
						memset(message, 0, BUFLEN);
						sprintf(message, "%c %s %s", '7', cl, fl);
						//trimitere cerere
						n = send(sockfd, message, strlen(message), 0);
						if (n < 0) error("ERROR writing to socket");
						//receptionare raspuns cu datele necesare pentru co-
						//nexiunea cu clientul de la care detine fisierul
						memset(buffer, 0, BUFLEN);
						n = recv(sockfd, buffer, sizeof(buffer), 0);
						if (n < 0) error("ERROR reading from socket");
						else if (n == 0) error("ERROR server closed");
						char *ACK = strtok(buffer, " ");
						if (ACK[0] == '7')	{	
							//procesare date							
							char *ip = strtok(NULL, " ");
							inet_aton(ip, &destaddr.sin_addr);
							char *port = strtok(NULL, " ");
							destaddr.sin_port = htons(atoi(port));
							char *af = strtok(NULL, " ");
							destaddr.sin_family = (short int)atoi(af);
							//deschidere conexiune cu clientul caruia se
							//vrea sa i sa trimita disierul
							destsockfd = socket(AF_INET, SOCK_STREAM, 0);
							if (connect(destsockfd, (struct sockaddr*) &destaddr, sizeof(struct sockaddr)) < 0) 
								error("ERROR connecting");
							//adaugare file descriptor in multime
							FD_SET(destsockfd, &read_fds);
							//updatere
							fdmax = max(fdmax, destsockfd);
							//compunere mesaj in care trimitem catre clientul de
							//la care dorim fisirul, numele acestuia
							memset(message, 0, BUFLEN);
							sprintf(message,"%d %d %s", 7, 0, fl);
							//trimitere demand
							n = send(destsockfd, message, strlen(message), 0);
							if (n < 0) error("ERROR writing to socket");
						}
					}
					else if (strncmp(buffer, "quit", 4) == 0) {
						//compunere mesaj prin care se anunta serverul de para-
						//sirea retelei
						memset(message, 0, BUFLEN);
						sprintf(message, "%d", 8);
						//trimitere mesaj
						n = send(sockfd, message, strlen(message), 0);
						if (n < 0) error("ERROR writing to socket");
						//inchiere socket
						close(sockfdClient);
						close(sockfd);
						exit(0);
					}
				}
				else if (i == sockfd) {	//mesage cu expeditor server-ul
					n = recv(sockfd, &ack, 1, 0);
					if (n < 0) error("ERROR reading from socket");
					else if (n == 0) {
						close(sockfd);
						error("ERROR server closed");
					}
					else { //mesaje primite dupa trimitere comenzi
						if (ack == '1') { //listclients
							//receptare mesaj							
							memset(buffer, 0, BUFLEN);
							n = recv(sockfd, buffer, sizeof(buffer), 0);
							if (n < 0) error("ERROR reading from socket");
							else if (n == 0) error("ERROR server closed");
							//afisare continut mesaj
							char *connect = strtok(buffer, " ");
							printf("Lista clientilor conectati: %s ", connect);
							while ((connect = strtok(NULL, " ")) != NULL ) {
								printf("%s ", connect);
							}
							printf("\n");
						}
						else if (ack == '2') { //infoclient
							//receptare mesaj
							memset(buffer, 0, BUFLEN);
							n = recv(sockfd, buffer, sizeof(buffer), 0);
							if (n < 0) error("ERROR reading from socket");
							else if (n == 0) error("ERROR server closed");
							//afisare continut mesaj
							char *info = strtok(buffer, " ");
							printf("Informatii suplimentare despre %s: ", info);
							while ((info = strtok(NULL, " ")) != NULL ) {
								printf("%s ", info);
							}
							printf("\n");
						}
						else if (ack == '4') { //sharefile
							//updatare lista fisiere
							file[files] = strdup(fl);
							files++;
						}							
						else if (ack == '5') { //unsharefile
							//updatare lista fisiere
							for (j = fileAt; j < files - 1; j++) {
								file[j] = strdup(file[j + 1]);
							}
							free(file[files - 1]);
							files--;
						}
						else if (ack == '6') { //getshare
							//receptare mesaj
							memset(buffer, 0, BUFLEN);
							n = recv(sockfd, buffer, sizeof(buffer), 0);
							if (n < 0) error("ERROR reading from socket");
							else if (n == 0) error("ERROR server closed");
							//afisare continut mesaj
							char* fisier = strtok(buffer, " ");
							printf("Lista fisierelor partajate de catre %s: %s ", cl, fisier);
							while ((fisier = strtok(NULL," ")) != NULL) {
								printf("%s ", fisier);
							}
							printf("\n");
						}		
					}
				}
				
				else if (i == sockfdClient) { //conexiune noua
					int newlen = sizeof(newaddr);
					if ((newsockfd = accept(sockfdClient, (struct sockaddr *)&newaddr, &newlen)) == -1) {
						error("ERROR in accept");
					}
					//adaugare noul file descriptor 
					FD_SET(newsockfd, &read_fds);
					//updatare
					fdmax = max(fdmax, newsockfd);
				}
				else { //primire mesaj de la un alt client 
					memset(toSend, 0, BUFLEN);
					n = recv(i, toSend, sizeof(toSend), 0);
					if (n < 0) error("ERROR reading from socket");
					else if (n == 0) error("ERROR server closed");
				
					if (toSend[0] == '3') { //message
						//afisare mesaj primit
						printf("%s\n", toSend + 1);
						//trimitere confirmarea primirii mesajului
						int ack = 0;
						n = send(i, &ack, sizeof(int), 0);
						if (n < 0) error("ERROR writing to socket");
						//stergere file descriptor din multime 
						FD_CLR(i, &read_fds);
						//inchidere conexiune
						close(i);
					}
					else if (toSend[0] == '7') { //getfile
						//primire cerere de transfer fisier intr-un mesaj ce 
						//contine numele fisierului de trimis si pozitia unde a 
						//ramas de trimis
						char *type = strtok(toSend, " ");
						char *posi = strtok(NULL, " ");
						char *fis  = strtok(NULL, " ");
						strcpy(fileSend, fis);
						//deschidere fisier si cautare pozitie
						snd = fopen(fileSend, "r");
						at = atol(posi);
						fseek(snd, at, SEEK_SET);
						//compunere mesaj cu numele fisierului, pachetul cu date
						//si dimensiunea sa
						memset(pkg, 0, sizeof(pkg));
						dim = fread(pkg, 1, 1024, snd);
						pkg[dim] = '\0';
						
						if (!feof(snd)) {	//daca inca nu am citit tot din fisier
							//trimitere mesaj prin care destinatarul este anun-
							//tat ca mai sunt date de trimis din fisier impreuna
							//cu pachetul de date din fisier
							memset(toSend, 0, sizeof(toSend));
							sprintf(toSend, "%c%d %s %s", '%', dim, fileSend, pkg);
							n = send(i, toSend, strlen(toSend), 0);
							if (n < 0) error("ERROR writing to socket");
						}
						else {	//altfel
							printf("File sent\n");
							//trimitere mesaj prin care destinatarul este anun-
							//tat ca fisierul a fost trimis impreuna cu ultimul
							//pachet de date din fisier
							memset(toSend, 0, sizeof(toSend));
							sprintf(toSend, "%c%d %s %s", '&', dim, fileSend, pkg);
							n = send(i, toSend, strlen(toSend), 0);
							if (n < 0) error("ERROR writing to socket");
							//stergere file descriptor din multime
							FD_CLR(i, &read_fds);
							//inchidere conexiune
							close(i);
						}
						fclose(snd);
					}
					else if (toSend[0] == '&' || toSend[0] == '%') {
						//procesare mesaj cu numele fisier dorit, pachet de date
						//si pozitia din fisier de unde a ramas transferul
						char *type = strtok(toSend, " ");
						char *fisi = strtok(NULL, " ");
						strcpy(fileSend, fisi);
						strcpy(len, type + 1);
						dim = atoi(len);
						//deschidere fiser in care se va copia continutul fisie-
						//rului dorit
						rcv = fopen("received.txt", "a");
						//scriere in fisier
						fwrite(toSend + strlen(len) + strlen(fileSend) + 3, 1, dim, rcv);
						if (toSend[0] == '&') {
							printf("File received\n");
							//stergere file descriptor din multime
							FD_CLR(i, &read_fds);
							//inchidere conexiune
							close(i);
						}
						if (toSend[0] == '%') { //mai sunt date de primit
							//aflare pozitie din fisier ultimului octet trimis
							fseek(rcv, 0, SEEK_END);
							sprintf(aT, "%ld", ftell(rcv));
							//compunere mesaj pentru clientul de la care se do-
							//reste transmitarea integrala a continutului unui
							//fisier in care i se specifica pozitia din fisier a
							//ultimului octet trimis
							memset(toSend, 0, 1024);
							sprintf(toSend, "%c %s %s", '7', aT, fileSend);
							//trimitere mesaj						
							n = send(i, toSend, strlen(toSend), 0);
							if (n < 0) error("ERROR writing to socket");
						}
						//inchidere fisier
						fclose(rcv);
					}
				}
			}
		}
	}
	return 0;
}
