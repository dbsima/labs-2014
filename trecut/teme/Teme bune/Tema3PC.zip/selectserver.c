#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h> 
#include <unistd.h>
#include <arpa/inet.h>
#include <time.h>

#define BUFLEN 256

//strucura ce inglobeaza campurile necesare pentru un client	
struct str {
	char *name;	//client name
	int fd;		//file descriptor
	struct sockaddr_in addr;
	time_t timestamp; //start of connection
	char files;	//number of client's files
	char **file;//client files
};
typedef struct str* struc;

//functie ce returneaza o clona a unui element de tipul structurii client
struc clone(struc client) {
	struc cpy = (struc) malloc(sizeof(struct str));
	strcpy(cpy->name, client->name);
	cpy->fd        = client->fd;
	cpy->addr      = client->addr;
	cpy->timestamp = client->timestamp;
	cpy->files     = client->files;
	int i;
	for (i = 0; i < cpy->files; i++)
		cpy->file[i] = strdup(client->file[i]);
	return cpy;
}

//functie ce afiseaza cauza unei erori si produce oprirea rularii executabilului
void error(char *msg) {
	perror(msg);
	exit(1);
}

//functie ce intoarce maximul dintre doua numere
int max(int a, int b) {
	if (a > b) return a;
	return b;
}

int main(int argc, char *argv[]) {
	//verificare daca au fost trimisi toti parametri necesari pentru server
	if (argc < 2) {
		fprintf(stderr,"Usage : %s port\n", argv[0]);
		exit(1);
	}	

	//deschidere socket server
	int sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd < 0) error("ERROR opening socket");

	//portul pe care server-ul asculta eventuale cereri de conexiune
	int portServer = atoi(argv[1]);

	//parametri pentru conexiune server-client
	struct sockaddr_in serv_addr;
	memset((char *) &serv_addr, 0, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(portServer);
	serv_addr.sin_addr.s_addr = INADDR_ANY;
	
	//verificam daca server-ul poate realiza conexiuni cu eventuali clienti
	if (bind(sockfd,(struct sockaddr *) &serv_addr, sizeof(struct sockaddr))<0) 
		error("ERROR binding");
	
	//ascultam pe port pentru posibile conexiuni
	listen(sockfd, 5);

	//multimea de citire folosita in select()
	fd_set read_fds;	
	//golim multimea de descriptori de citire 
	FD_ZERO(&read_fds);
	//adaugam noul file descriptor (socketul pe care se asculta conexiuni)
	FD_SET(0, &read_fds);
	FD_SET(sockfd, &read_fds);
	
	//valoare maxima file descriptor din multimea read_fds
	int fdmax = sockfd;

	//multime folosita temporar
	fd_set tmp_fds;	
	//golim multimea temporara de descriptori
	FD_ZERO(&tmp_fds);

	int newsockfd, clilen;
	
	struct sockaddr_in cli_addr;
	int n, n1;
	
	struc client[5];	//lista de maxim 5 clienti admisi intr-o retea
	int clients = 0;	//numar clienti
	int clientPos;		//pozitia unui client in lista de clienti 
	
	//buffer	
	char buffer[BUFLEN];

	int i, j, k; 
	while (1) {
		tmp_fds = read_fds; 
		if (select(fdmax + 1, &tmp_fds, NULL, NULL, NULL) == -1) 
			error("ERROR in select");
		for(i = 0; i <= fdmax; i++) {
			if (FD_ISSET(i, &tmp_fds)) {
				if(i == 0) { //serverul citeste comenzi de la tastatura
					memset(buffer, 0 , BUFLEN);
     				fgets(buffer, BUFLEN - 1, stdin);
					buffer[strlen(buffer) - 1] = '\0';
					if (strcmp(buffer, "status") == 0) {	//comanda status
						for (j = 0; j < clients; j++) {
							char *nume = client[j]->name;
							char *ip   = inet_ntoa(client[j]->addr.sin_addr);
							int  port  =  ntohs(client[j]->addr.sin_port);
							printf("%s - %s - %d - ", nume, ip, port);
							for (k = 0; k < client[j]->files; k++)
								printf("%s ", client[j]->file[k]);
							printf("\n");
						}
					}
					else if (strcmp(buffer, "quit") == 0) { //comanda quit
						error("Server went off");
					}
				}
				else if (i == sockfd) { //conexiune noua
					int newsockfd;
					clilen = sizeof(cli_addr);
					if ((newsockfd = accept(sockfd, (struct sockaddr *)&cli_addr, &clilen)) == -1) {
						error("ERROR accepting");
					}
					else {
						//adaugam noul file descriptor
						FD_SET(newsockfd, &read_fds);
						//receptionare mesaj
						memset(buffer, 0, BUFLEN);
						n = recv(newsockfd, buffer, sizeof(buffer), 0);
						if (n < 0) error("ERROR reading from socket");
						else if (n == 0) {
							printf("Socket %d has been closed\n", newsockfd);
							FD_CLR(newsockfd, &read_fds);
							close(newsockfd);
						}
						else { 
							//procesare mesaj
							char *clientName = strtok(buffer, " ");
							char *clientPort = strtok(NULL, " ");
							//trimitere ack
							char ack = 0;
							n1 = send(newsockfd, &ack, 1, 0);
							if (n1 < 0) error("ERROR writting to socket");
							//introducere client in lista ce clienti
							fdmax = max(fdmax, newsockfd);
							cli_addr.sin_port = htons(atoi(clientPort));
							client[clients] = (struc) malloc(sizeof(struct str));
							client[clients]->name      = strdup(buffer);
							client[clients]->fd        = newsockfd;
							client[clients]->addr      = cli_addr;
							client[clients]->timestamp = time(NULL);
							client[clients]->files     = 0;
							client[clients]->file = (char**)malloc(5 * sizeof(char*));
							printf("Client %s has joined\n", client[clients]->name);
							clients++;
						}
					}
				}
				else { //am primit date pe unul din socketii cu care vorbesc cu clientii
					for (j = 0; j < clients; j++) {
						if (client[j]->fd == i) {
							clientPos = j;
							break;
						}
					}
					//receptionare mesaj
					memset(buffer, 0, BUFLEN);
					n = recv(i, buffer, sizeof(buffer), 0);
					if (n < 0) error("ERROR reading from socket");
					else if (n == 0) {
						printf("Client %s has left\n", client[clientPos]->name);
						FD_CLR(i, &read_fds);
						close(i);
						for (j = clientPos; j < clients - 1; j++) {
							client[j] = clone(client[j + 1]);
						}
						free(client[clients - 1]);
						clients--;
					}
					else { //primire comanda de la unul dintre clientii deja
						   //conectati
						char ack = buffer[0];
						if (ack == '1') { // comanda listclients
							//trimitere ack
							n1 = send(i, &buffer[0], 1, 0);
							if (n1 < 0) error("ERROR writting to socket");
							//compunere mesaj cu lista clienti online
							memset(buffer, 0, BUFLEN);
							for (j = 0; j < clients; j++) {
								strcat(strcat(buffer," "), client[j]->name);
							}
							//trimitere mesaj
							n = send(i, buffer, strlen(buffer), 0);
							if (n < 0) error("ERROR writting to socket");
						}
						else if (ack == '2') { //comanda infoclient							
							//cautare client dorit							
							int pos = -1;
							for (j = 0; j < clients; j++) {
								if (strcmp(client[j]->name, buffer + 1) == 0) {
									pos = j;
									break;
								}
							}
							//trimitere ack
							n1 = send(i, &buffer[0], 1, 0);
							if (n1 < 0) error("ERROR writting to socket");
							//compunere mesaj cu nume client dorit,
							//portul pe care asculta si timpul de la
							//conectarea acestuia
							memset(buffer, 0, BUFLEN);
							char *nume = strdup(client[pos]->name);
							int  port  = ntohs(client[pos]->addr.sin_port);
							double t   = difftime(time(NULL), client[pos]->timestamp);
							sprintf(buffer, " %s %d %lf", nume, port, t);
							//trimitere mesaj
							n1 = send(i, buffer, strlen(buffer), 0);
							if (n1 < 0) error("ERROR writting to socket");
						}
						else if (ack == '3') { //comanda message
							//cautare client dorit
							int pos = -1;
							for (j = 0; j < clients; j++)
								if (strcmp(client[j]->name, buffer + 1) == 0) {
									pos = j;
									break;
								}
							//compunere mesaj cu ip-ul clientului destinatie
							//portul sau de conexiune si AF_INET pentru ca
							//clientul care doreste sa trimita un mesaj sa
							//poata sa deschida o conexiune cu clientul ca-
							//ruia doreste sa ii trimita un mesaj 
							memset(buffer, 0, BUFLEN);
							int port = ntohs(client[pos]->addr.sin_port);
							char* ip = strdup(inet_ntoa(client[pos]->addr.sin_addr));
							int af   = client[pos]->addr.sin_family;
							sprintf(buffer,"%d %s %d %d", 3, ip, port, af);
							//trimitere mesaj
							n1 = send(i, buffer, strlen(buffer), 0);
							if (n1 < 0) error("ERROR writting to socket");
						}
						else if (ack == '4') { //comanda sharefile
							//verificare numar fisiere partajate < limita
							if (client[clientPos]->files == 5) {
								char nack = -4;
								n1 = send(i, &nack, 1, 0);
								if (n1 < 0) error("ERROR writting to socket");
							}
							else {
								int filePos = -1;
								for (j = 0; j < client[clientPos]->files; j++)
									if (strcmp(client[clientPos]->file[j], buffer + 1) == 0) {
										filePos = j;
										break;
									}
								n1 = send(i, &buffer[0], 1, 0);
								if (n1 < 0) error("ERROR writting to socket");
								//updatare lista cu fisier partajate
								client[clientPos]->file[client[clientPos]->files] = strdup(buffer + 1);
								client[clientPos]->files++;
							}
						}
						else if (ack == '5') { //comanda unshare
							//cautare fisierul de stergere fisier din lista
							int filePos = -1;
							for (j = 0; j < client[clientPos]->files; j++)
								if (strcmp(client[clientPos]->file[j], buffer + 1) == 0) {
									filePos = j;
									break;
								}
							//trimitere ack
							n1 = send(i, &buffer[0], 1, 0);
							if (n1 < 0) error("ERROR writting to socket");
							//updatare lista de fisiere partajate
							for (j = filePos; j < client[clientPos]->files - 1; j++)
								client[clientPos]->file[j] = strdup(client[clientPos]->file[j + 1]);
							free(client[clientPos]->file[client[clientPos]->files - 1]);
							client[clientPos]->files--;
						}
						else if (ack == '6') { //comanda getshare
							//cautare client de la care se doreste informatia
							int pos = -1;
							for (j = 0; j < clients; j++)
								if (strcmp(client[j]->name, buffer + 1) == 0) {
									pos = j;
									break;
								}
							//trimitere ack
							n1 = send(i, &buffer[0], 1, 0);
							if (n1 < 0) error("ERROR writting to socket");
							//compunere mesaj ce va contine lista fisierelor
							//partajate ale clientului dorit
							memset(buffer, 0, BUFLEN);
							for (j = 0; j < client[pos]->files; j++) {
								strcat(strcat(buffer, " "), client[pos]->file[j]);
							}
							//trimitere mesaj
							n1 = send(i, buffer, strlen(buffer), 0);
							if (n1 < 0) error("ERROR writting to socket");
						}
						else if (ack == '7') { //comanda getfile
							//procesare mesaj
							char *command = strtok(buffer, " ");
							char *nume_client = strtok(NULL, " ");
							char numeClient[BUFLEN];
							strcpy(numeClient, nume_client);
							//cautare client de la care se doreste fisierul
							int posi = -1;
							for (j = 0; j < clients; j++)
								if (strcmp(client[j]->name, numeClient) == 0) {
									posi = j;
									break;
								}
							//procesare mesaj
							char *nume_fisier = strtok(NULL, " ");
							char numeFisier[BUFLEN];
							strcpy(numeFisier, nume_fisier);
							//cautare fisier dorit
							int posit = -1;
							for (j = 0; j < client[posi]->files; j++)
								if (strcmp(client[posi]->file[j], numeFisier) == 0) {
									posit = j;
									break;
								}
							//compunere mesaj cu datele necesare de la 
							//clientul de la care se doreste obtine fi-
							//sierul pentru ca cel care doreste fisierul
							//sa se poata conecta cu acesta
							memset(buffer, 0, BUFLEN);
							int port = ntohs(client[posi]->addr.sin_port);
							char* ip = strdup(inet_ntoa(client[posi]->addr.sin_addr));
							int af   = client[posi]->addr.sin_family;
							sprintf(buffer, "%c %s %d %d", '7', ip, port, af);
							n1 = send(i, buffer, strlen(buffer), 0);
							if (n1 < 0) error("ERROR writting to socket");
						}
						else if (ack == '8') { //comanda quit
							printf("Client %s has left\n", client[clientPos]->name);
							//updatare retea
							if (clientPos == 0){
								free(client[clientPos]);
								clients--;
							}
							else {
								for (j = clientPos; j < clients - 1; j++)
									client[j] = clone(client[j + 1]);
								free(client[clients - 1]);
								clients--;
							}
							//stergere file descriptor din multime
							FD_CLR(i, &read_fds);
							close(i);
						}
					}
				}
			}
		}
	}
	close(sockfd);
	return 0; 
}
